package com.dooyappwork.konveksipro.feature.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.feature.containerFactory
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/**
 * SEMUA angka dashboard berasal dari database (Flow Room) - tidak ada angka statis (Bag. 6A).
 * Tahap 3-4: kartu Pesanan, Produksi, Piutang, Barang Jadi, dan Stok Min. kini hidup
 * dari tabel orders, production_batches, dan materials (migrasi v3/v4).
 */
data class DashboardUiState(
    val isLoading: Boolean = true,
    val businessName: String? = null,
    val businessId: String? = null,
    val totalCustomers: Int = 0,
    val ordersActive: Int = 0,
    val ordersDone: Int = 0,
    val productionActive: Int = 0,
    val receivable: Long = 0,
    val materialsBelowMinimum: Int = 0,
    val recentActivity: List<String> = emptyList(),
    val error: String? = null
)

/** Agregat operasional digabung dulu agar combine utama tetap dalam batas argumen. */
private data class OpsMetrics(
    val ordersActive: Int,
    val ordersDone: Int,
    val productionActive: Int,
    val receivable: Long,
    val materialsBelowMinimum: Int
)

class DashboardViewModel(private val container: AppContainer) : ViewModel() {

    private val ops = combine(
        container.orderRepository.observeActiveCount(),
        container.orderRepository.observeDoneCount(),
        container.productionRepository.observeActiveCount(),
        container.orderRepository.observeReceivable(),
        container.catalogRepository.observeMaterials().map { materials ->
            materials.count { it.stock < it.min_stock }
        }
    ) { active, done, production, receivable, belowMin ->
        OpsMetrics(active, done, production, receivable, belowMin)
    }

    val state: StateFlow<DashboardUiState> =
        combine(
            container.businessProfileRepository.observe(),
            container.customerRepository.observeCount(),
            ops,
            container.auditLogRepository.observeRecent(10).map { logs ->
                logs.map { log -> "${log.action} ${log.entity_type} - ${log.detail ?: ""}".trim() }
            }
        ) { profile, count, opsMetrics, activity ->
            DashboardUiState(
                isLoading = false,
                businessName = profile?.business_name,
                businessId = profile?.id,
                totalCustomers = count,
                ordersActive = opsMetrics.ordersActive,
                ordersDone = opsMetrics.ordersDone,
                productionActive = opsMetrics.productionActive,
                receivable = opsMetrics.receivable,
                materialsBelowMinimum = opsMetrics.materialsBelowMinimum,
                recentActivity = activity
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardUiState())

    companion object {
        fun factory(): ViewModelProvider.Factory = containerFactory { DashboardViewModel(it) }
    }
}
