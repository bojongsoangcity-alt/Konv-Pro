package com.dooyappwork.konveksipro.data.repository

import androidx.room.withTransaction
import com.dooyappwork.konveksipro.data.local.KonveksiDatabase
import com.dooyappwork.konveksipro.data.local.entities.OrderEntity
import com.dooyappwork.konveksipro.data.local.entities.OrderItemEntity
import com.dooyappwork.konveksipro.data.local.entities.ProductionBatchEntity
import com.dooyappwork.konveksipro.data.local.entities.toDomain
import com.dooyappwork.konveksipro.data.preferences.SettingsRepository
import com.dooyappwork.konveksipro.domain.logic.OrderCalculator
import com.dooyappwork.konveksipro.domain.model.Order
import com.dooyappwork.konveksipro.domain.model.OrderStatus
import com.dooyappwork.konveksipro.domain.model.PaymentStatus
import com.dooyappwork.konveksipro.domain.model.ProductionStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

/**
 * Repository Pesanan (Tahap 3) - dibuat di atas repository Stage 1/2, tidak mengubahnya.
 * Semua tulisan data lewat transaksi + audit log (aturan bisnis proyek).
 * Membuat pesanan otomatis membentuk batch produksi (satu per baris produk) dalam
 * transaksi yang sama - tidak ada pesanan tanpa antrean produksi.
 */
class OrderRepository(
    private val db: KonveksiDatabase,
    private val audit: AuditLogRepository,
    private val settings: SettingsRepository
) {
    fun observeOrders(): Flow<List<Order>> =
        db.orderDao().observeAll().map { list -> list.map { it.toDomain() } }

    fun observeById(id: String): Flow<Order?> =
        db.orderDao().observeById(id).map { it?.toDomain() }

    fun observeItems(orderId: String): Flow<List<OrderItemEntity>> = db.orderDao().observeItems(orderId)

    fun observeActiveCount(): Flow<Int> = db.orderDao().observeActiveCount()
    fun observeLateCount(): Flow<Int> = db.orderDao().observeLateCount(System.currentTimeMillis())
    fun observeReceivable(): Flow<Long> = db.orderDao().observeReceivable()

    fun observeDoneCount(): Flow<Int> = db.orderDao().observeDoneCount()

    /** Kode pesanan berurutan ORD-00001; dihitung di dalam transaksi agar tidak dobel. */
    private suspend fun nextOrderCode(): String =
        "ORD-" + (db.orderDao().countAllIncludingDeleted() + 1).toString().padStart(5, '0')

    suspend fun create(
        customerId: String?,
        customerName: String,
        dueDate: Long?,
        notes: String?,
        downPayment: Long,
        lines: List<OrderCalculator.LineInput>
    ): String {
        val total = OrderCalculator.validate(lines, downPayment)
        require(customerName.isNotBlank()) { "Nama pelanggan pesanan wajib diisi" }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        val orderId = UUID.randomUUID().toString()
        db.withTransaction {
            val order = OrderEntity(
                id = orderId,
                order_code = nextOrderCode(),
                customer_id = customerId,
                customer_name = customerName.trim(),
                status = OrderStatus.BARU,
                order_date = now,
                due_date = dueDate,
                total_amount = total,
                down_payment = downPayment,
                paid_amount = 0,
                payment_status = PaymentStatus.BELUM_LUNAS,
                notes = notes?.trim()?.ifBlank { null },
                created_at = now, updated_at = now, device_id = deviceId
            )
            db.orderDao().upsert(order)
            db.orderDao().insertItems(
                lines.map {
                    OrderItemEntity(
                        id = UUID.randomUUID().toString(),
                        order_id = orderId,
                        product_name = it.productName.trim(),
                        qty = it.qty,
                        unit_price = it.unitPrice,
                        note = null,
                        created_at = now
                    )
                }
            )
            // Batch produksi otomatis: satu per baris produk, masih ANTRE.
            db.productionDao().insertBatches(
                lines.map {
                    ProductionBatchEntity(
                        id = UUID.randomUUID().toString(),
                        order_id = orderId,
                        product_id = null,
                        product_name = it.productName.trim(),
                        qty = it.qty,
                        status = ProductionStatus.ANTRE,
                        worker_id = null,
                        due_date = dueDate,
                        started_at = null, finished_at = null,
                        notes = null,
                        created_at = now, updated_at = now, device_id = deviceId
                    )
                }
            )
            audit.log("CREATE", "orders", orderId, order.order_code, deviceId)
        }
        return orderId
    }

    suspend fun updateStatus(id: String, to: String) {
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val order = db.orderDao().getById(id)
                ?: throw IllegalStateException("Pesanan tidak ditemukan")
            check(OrderCalculator.canTransition(order.status, to)) {
                "Perubahan status dari ${OrderStatus.label(order.status)} ke ${OrderStatus.label(to)} tidak diizinkan"
            }
            val rows = db.orderDao().updateStatus(id, to, now)
            check(rows == 1) { "Pesanan tidak ditemukan" }
            audit.log("UPDATE", "orders", id, "status=$to", deviceId)
        }
    }

    /** Catat pembayaran (pelunasan); otomatis menjadi LUNAS bila sisa habis. */
    suspend fun settlePayment(id: String, amount: Long) {
        require(amount > 0) { "Jumlah pembayaran harus lebih dari 0" }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val order = db.orderDao().getById(id)
                ?: throw IllegalStateException("Pesanan tidak ditemukan")
            check(order.payment_status != PaymentStatus.LUNAS) { "Pesanan sudah lunas" }
            val receivable = OrderCalculator.receivable(order.total_amount, order.down_payment, order.paid_amount)
            check(amount <= receivable) { "Pembayaran melebihi sisa tagihan" }
            val newPaid = order.paid_amount + amount
            val newStatus = if (newPaid >= order.total_amount) PaymentStatus.LUNAS else PaymentStatus.BELUM_LUNAS
            db.orderDao().updatePayment(id, newPaid, newStatus, now)
            audit.log("PAYMENT", "orders", id, "pembayaran=$amount", deviceId)
        }
    }

    suspend fun softDelete(id: String) {
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val rows = db.orderDao().softDelete(id, now)
            check(rows == 1) { "Pesanan tidak ditemukan" }
            audit.log("SOFT_DELETE", "orders", id, null, deviceId)
        }
    }
}
