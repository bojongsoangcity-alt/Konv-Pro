package com.dooyappwork.konveksipro.ai.data

import com.dooyappwork.konveksipro.ai.config.AIProviderConfig
import com.dooyappwork.konveksipro.ai.config.AILimitsConfig

/** Keputusan boleh/tidaknya permintaan eksternal dijalankan. */
data class QuotaDecision(
    val allowed: Boolean,
    val reason: String? = null,
    /** true = provider berbayar diblokir karena anggaran harian 0. */
    val paidBlocked: Boolean = false
)

/**
 * Pengendali batas penggunaan internal (Bag. 8).
 * Batas ini milik developer dan TIDAK dapat diubah pengguna dari UI.
 */
class AIQuotaManager(
    private val tracker: AIUsageTracker,
    private val limits: AILimitsConfig
) {
    fun evaluate(): QuotaDecision {
        val today = tracker.today()
        return when {
            limits.maxRequestsPerDay > 0 && today.requests >= limits.maxRequestsPerDay ->
                QuotaDecision(false, "Batas ${limits.maxRequestsPerDay} permintaan/hari tercapai.")
            limits.maxTokensPerDay > 0 && today.tokens >= limits.maxTokensPerDay ->
                QuotaDecision(false, "Batas ${limits.maxTokensPerDay} token/hari tercapai.")
            limits.maxCostUsdPerDay > 0 && today.costUsd >= limits.maxCostUsdPerDay ->
                QuotaDecision(false, "Batas biaya harian tercapai.")
            else -> QuotaDecision(true)
        }
    }

    /**
     * Provider dengan harga > 0 hanya boleh dipakai jika developer mengizinkan
     * anggaran (maxCostUsdPerDay > 0). Tanpa itu, biaya berbayar tidak akan terjadi.
     */
    fun providerBudgetCheck(provider: AIProviderConfig): QuotaDecision {
        val paid = (provider.pricePer1kInputUsd ?: 0.0) > 0.0 || (provider.pricePer1kOutputUsd ?: 0.0) > 0.0
        if (!paid) return QuotaDecision(true)
        if (limits.maxCostUsdPerDay <= 0.0) {
            return QuotaDecision(false, "Provider berbayar diblokir oleh kebijakan biaya developer.", paidBlocked = true)
        }
        val today = tracker.today()
        return if (today.costUsd >= limits.maxCostUsdPerDay) {
            QuotaDecision(false, "Anggaran harian habis.", paidBlocked = true)
        } else {
            QuotaDecision(true)
        }
    }

    fun snapshot(): String {
        val today = tracker.today()
        return "Permintaan hari ini ${today.requests}/${limits.maxRequestsPerDay}, " +
            "token ${today.tokens}/${limits.maxTokensPerDay}, " +
            "estimasi biaya ${"%.4f".format(today.costUsd)} USD / batas ${limits.maxCostUsdPerDay} USD"
    }
}
