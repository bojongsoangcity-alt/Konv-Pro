package com.dooyappwork.konveksipro.ai.local

/**
 * Ringkasan AGREGAT usaha dari database lokal (diperluas Tahap 3-4, 7).
 * Sengaja tidak memuat nama/telepon/alamat pelanggan: data inilah yang boleh
 * dirangkum ke prompt AI eksternal. Nilai default 0 menjaga kompatibilitas
 * pemanggil lama (uji Stage 2 tetap kompilasi tanpa perubahan).
 */
data class BusinessSnapshot(
    val businessName: String?,
    val isProfileConfigured: Boolean,
    val customersTotal: Int,
    val customersWithoutContact: Int,
    val customersAddedLast30Days: Int,
    val activityCountLast30Days: Int,
    // Tahap 3: pesanan & produksi
    val ordersActive: Int = 0,
    val ordersLate: Int = 0,
    val ordersNew: Int = 0,
    val ordersCreatedLast30Days: Int = 0,
    val ordersUnpaid: Int = 0,
    val lastOrderAt: Long = 0,
    val receivable: Long = 0,
    val productionAntre: Int = 0,
    val productionProses: Int = 0,
    val productionFinishedLast30Days: Int = 0,
    val productionWithoutWorker: Int = 0,
    // Tahap 4: katalog & persediaan
    val materialsTotal: Int = 0,
    val materialsBelowMinimum: Int = 0,
    val materialStockValue: Long = 0,
    val materialsWithoutSupplier: Int = 0,
    val productsActive: Int = 0,
    val productsWithoutRecipe: Int = 0,
    val workersTotal: Int = 0,
    val suppliersTotal: Int = 0,
    // Tahap 7: pelengkap HPP
    val productsLaborOverheadValue: Long = 0,
    /** Modul yang datanya sudah tersedia pada tahap ini. */
    val availableModules: Set<String> = setOf("business", "customers")
) {
    companion object {
        val EMPTY = BusinessSnapshot(
            businessName = null,
            isProfileConfigured = false,
            customersTotal = 0,
            customersWithoutContact = 0,
            customersAddedLast30Days = 0,
            activityCountLast30Days = 0
        )
    }
}
