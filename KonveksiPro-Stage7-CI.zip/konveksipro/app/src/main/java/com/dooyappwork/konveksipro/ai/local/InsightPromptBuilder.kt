package com.dooyappwork.konveksipro.ai.local

import com.dooyappwork.konveksipro.ai.model.InsightReport

/**
 * Menyusun prompt HANYA dari fakta yang sudah dihitung lokal.
 * Model tidak diminta mengarang angka; ia hanya menarasikan fakta tersebut.
 */
class InsightPromptBuilder {

    fun build(report: InsightReport): String = buildString {
        appendLine("Anda asisten analisis usaha konveksi di Indonesia. Tugas: menarasikan FAKTA yang diberikan.")
        appendLine("Aturan wajib: jangan menambah angka baru, jangan mengarang data, jangan menyebut merek.")
        appendLine("Jika informasi tidak ada di fakta, tulis bahwa datanya belum tersedia.")
        appendLine("Balas dalam Bahasa Indonesia, maksimal 5 poin singkat, tanpa salam pembuka.")
        appendLine()
        appendLine("Jenis analisis: ${report.kind.title}")
        appendLine("Ringkasan lokal: ${report.headline}")
        if (report.metrics.isNotEmpty()) {
            appendLine("Metrik (sudah dihitung dari database aplikasi):")
            report.metrics.forEach { appendLine("- ${it.label}: ${it.value}") }
        }
        if (report.findings.isNotEmpty()) {
            appendLine("Temuan:")
            report.findings.forEach { appendLine("- $it") }
        }
        if (report.actions.isNotEmpty()) {
            appendLine("Rekomendasi lokal:")
            report.actions.forEach { appendLine("- $it") }
        }
        appendLine()
        append("Tulis 3-5 poin prioritas tindakan praktis berdasarkan fakta di atas.")
    }
}
