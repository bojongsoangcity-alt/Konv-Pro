package com.dooyappwork.konveksipro.ai.data

/** Abstraksi penyimpanan ringan agar logic bisa diuji tanpa Android. */
interface KeyValueStore {
    fun getString(key: String): String?
    fun putString(key: String, value: String)
    fun remove(key: String)
}
