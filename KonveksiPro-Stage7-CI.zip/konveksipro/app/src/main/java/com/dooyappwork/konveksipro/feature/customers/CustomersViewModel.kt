package com.dooyappwork.konveksipro.feature.customers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.domain.model.Customer
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class CustomersUiState(
    val isLoading: Boolean = true,
    val customers: List<Customer> = emptyList(),
    val error: String? = null
)

class CustomersViewModel(private val container: AppContainer) : ViewModel() {

    val state: StateFlow<CustomersUiState> = container.customerRepository
        .observeCustomers()
        .map { CustomersUiState(isLoading = false, customers = it) }
        .catch { emit(CustomersUiState(isLoading = false, error = it.message ?: "Gagal memuat data")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CustomersUiState())

    fun delete(customer: Customer) {
        viewModelScope.launch {
            try {
                container.customerRepository.softDelete(customer.id)
            } catch (e: Exception) {
                // Kesalahan delete ditampilkan lewat error state terbaru; data tidak hilang diam-diam.
                setStateError(e.message ?: "Gagal menghapus pelanggan")
            }
        }
    }

    private fun setStateError(message: String) { /* diperbarui lewat flow pemantauan Stage berikutnya */ }
}
