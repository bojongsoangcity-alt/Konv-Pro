package com.dooyappwork.konveksipro.ai.config

import com.dooyappwork.konveksipro.ai.util.JsonNode
import com.dooyappwork.konveksipro.ai.util.JsonParser
import com.dooyappwork.konveksipro.ai.util.asStringOrNull
import com.dooyappwork.konveksipro.ai.util.path

/**
 * Mengubah string konfigurasi build (JSON flat object dari BuildConfig.AI_CONFIG)
 * menjadi Map untuk [DeveloperAIConfig.fromMap].
 * Tidak disentuh pengguna; nilainya hanya berasal dari build.
 */
object AiConfigLoader {

    fun toMap(rawJson: String?): Map<String, String?> {
        if (rawJson.isNullOrBlank()) return emptyMap()
        val root = JsonParser.parseOrNull(rawJson) as? JsonNode.Obj ?: return emptyMap()
        return root.values.mapValues { (_, value) -> value.asStringOrNull() }
    }

    fun load(rawJson: String?): DeveloperAIConfig = DeveloperAIConfig.fromMap(toMap(rawJson))

    /** Status ringkas untuk UI pengguna - tanpa detail kredensial. */
    fun describe(config: DeveloperAIConfig): String =
        "Mode: Developer-Managed AI • ${config.statusLabel()}"
}
