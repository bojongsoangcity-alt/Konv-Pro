package com.dooyappwork.konveksipro.feature.production

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dooyappwork.konveksipro.core.ui.EmptyState
import com.dooyappwork.konveksipro.core.ui.ErrorState
import com.dooyappwork.konveksipro.core.ui.KonveksiTopBar
import com.dooyappwork.konveksipro.core.ui.LoadingState
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.core.utils.formatDateTime
import com.dooyappwork.konveksipro.data.local.entities.WorkerEntity
import com.dooyappwork.konveksipro.domain.model.ProductionBatch
import com.dooyappwork.konveksipro.domain.model.ProductionStatus
import com.dooyappwork.konveksipro.feature.containerFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProductionUiState(
    val batches: List<ProductionBatch> = emptyList(),
    val workers: List<WorkerEntity> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val message: String? = null
)

class ProductionViewModel(private val container: AppContainer) : ViewModel() {
    private val _state = MutableStateFlow(ProductionUiState())
    val state: StateFlow<ProductionUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            container.productionRepository.observeBatches().collect { batches ->
                _state.update { it.copy(batches = batches, isLoading = false, error = null) }
            }
        }
        viewModelScope.launch {
            container.workersRepository.observeWorkers().collect { workers ->
                _state.update { it.copy(workers = workers) }
            }
        }
    }

    fun start(batchId: String) { tryAction { container.productionRepository.start(batchId) } }
    fun finish(batchId: String) { tryAction { container.productionRepository.finish(batchId) } }
    fun assign(batchId: String, worker: WorkerEntity?) {
        tryAction { container.productionRepository.assignWorker(batchId, worker?.id, worker?.name) }
    }

    fun createInternal(name: String, qty: String, dueDays: String) {
        tryAction {
            val due = dueDays.trim().toLongOrNull()
                ?.let { days -> System.currentTimeMillis() + days * 86_400_000L }
            container.productionRepository.createInternal(
                productName = name,
                qty = qty.toLongOrNull() ?: 0,
                dueDate = due
            )
        }
    }

    private fun tryAction(action: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                action()
                _state.update { it.copy(message = null) }
            } catch (e: Exception) {
                _state.update { it.copy(message = e.message ?: "Aksi gagal") }
            }
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }

    companion object {
        fun factory(): androidx.lifecycle.ViewModelProvider.Factory = containerFactory { ProductionViewModel(it) }
    }
}

@Composable
fun ProductionScreen(
    onBack: () -> Unit,
    viewModel: ProductionViewModel = viewModel(factory = ProductionViewModel.factory())
) {
    val state by viewModel.state.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }
    var assignTarget by remember { mutableStateOf<ProductionBatch?>(null) }

    LaunchedEffect(state.message) {
        if (state.message != null) {
            kotlinx.coroutines.delay(3000)
            viewModel.clearMessage()
        }
    }

    if (showCreateDialog) {
        CreateBatchDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, qty, due ->
                viewModel.createInternal(name, qty, due)
                showCreateDialog = false
            }
        )
    }

    assignTarget?.let { batch ->
        AssignWorkerDialog(
            workers = state.workers,
            currentWorkerId = batch.workerId,
            onDismiss = { assignTarget = null },
            onAssign = { worker ->
                viewModel.assign(batch.id, worker)
                assignTarget = null
            }
        )
    }

    Scaffold(
        topBar = { KonveksiTopBar("Produksi", "Antrean kerja per batch", onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateDialog = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Batch Internal") }
            )
        }
    ) { padding ->
        when {
            state.isLoading -> LoadingState(Modifier.padding(padding))
            state.error != null -> ErrorState(state.error ?: "", Modifier.padding(padding))
            state.batches.isEmpty() -> EmptyState(
                "Belum ada batch produksi.\nBatch otomatis terbentuk saat pesanan dibuat.",
                Modifier.padding(padding)
            )
            else -> LazyColumn(Modifier.padding(padding).fillMaxSize()) {
                item {
                    if (state.message != null) {
                        Text(
                            state.message ?: "",
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                items(state.batches, key = { it.id }) { batch ->
                    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(batch.productName, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                ProductionStatusChip(batch.status)
                            }
                            Text(
                                "Qty ${batch.qty}" +
                                    (if (batch.orderId != null) " • Pesanan" else " • Internal") +
                                    (batch.dueDate?.let { " • Tenggat " + formatDateTime(it) } ?: ""),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "Pekerja: " + (batch.workerId?.let { "ditugaskan" } ?: "belum ada"),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                when (batch.status) {
                                    ProductionStatus.ANTRE -> {
                                        Button(onClick = { viewModel.start(batch.id) }) { Text("Mulai") }
                                    }
                                    ProductionStatus.PROSES -> {
                                        Button(onClick = { viewModel.finish(batch.id) }) { Text("Selesai") }
                                    }
                                }
                                if (batch.status != ProductionStatus.SELESAI) {
                                    OutlinedButton(onClick = { assignTarget = batch }) { Text("Pekerja") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductionStatusChip(status: String) {
    val (fg, bg) = when (status) {
        ProductionStatus.SELESAI ->
            MaterialTheme.colorScheme.primary to MaterialTheme.colorScheme.primaryContainer
        ProductionStatus.PROSES ->
            MaterialTheme.colorScheme.secondary to MaterialTheme.colorScheme.secondaryContainer
        else ->
            MaterialTheme.colorScheme.tertiary to MaterialTheme.colorScheme.tertiaryContainer
    }
    Surface(color = bg, shape = MaterialTheme.shapes.small) {
        Text(
            ProductionStatus.label(status),
            Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = fg
        )
    }
}

@Composable
private fun CreateBatchDialog(onDismiss: () -> Unit, onCreate: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var due by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Batch Produksi Internal") },
        text = {
            Column {
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("Nama produk *") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = qty, onValueChange = { qty = it.filter { c -> c.isDigit() } },
                    label = { Text("Jumlah *") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = due, onValueChange = { due = it.filter { c -> c.isDigit() } },
                    label = { Text("Tenggat (hari, opsional)") }, modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(name, qty, due) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun AssignWorkerDialog(
    workers: List<WorkerEntity>,
    currentWorkerId: String?,
    onDismiss: () -> Unit,
    onAssign: (WorkerEntity?) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tugaskan pekerja") },
        text = {
            Column {
                if (workers.isEmpty()) {
                    Text(
                        "Belum ada pekerja. Tambahkan di Master Data → Pekerja.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                workers.forEach { w ->
                    TextButton(onClick = { onAssign(w) }, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            w.name + (w.role?.let { " - $it" } ?: "") +
                                if (w.id == currentWorkerId) " (saat ini)" else ""
                        )
                    }
                }
                if (currentWorkerId != null) {
                    TextButton(onClick = { onAssign(null) }) { Text("Lepaskan penugasan") }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup") } }
    )
}
