package com.dooyappwork.konveksipro.domain.logic

/**
 * Kalkulasi HPP & margin - murni Kotlin agar bisa diuji tanpa perangkat Android.
 * Tahap 7: HPP = material (BOM x harga beli) + upah per unit + overhead per unit.
 * Upah/overhead bersifat opsional (0 bila belum diisi) dan status ini tetap
 * dinyatakan jujur di layanan Costing - tidak ada angka karangan.
 */
object CostCalculator {

    data class BomRow(val qtyPerUnit: Double, val buyPricePerUnit: Long)

    /** HPP material per unit = sigma (kebutuhan per unit x harga beli per unit), dibulatkan ke rupiah. */
    fun materialCost(bom: List<BomRow>): Long =
        bom.sumOf { Math.round(it.qtyPerUnit * it.buyPricePerUnit) }

    /** HPP total per unit = material + upah + overhead (Tahap 7). */
    fun totalUnitCost(materialCost: Long, laborPerUnit: Long, overheadPerUnit: Long): Long =
        materialCost + laborPerUnit + overheadPerUnit

    /** Margin terhadap HPP total per unit. */
    fun margin(sellPrice: Long, totalUnitCost: Long): Long = sellPrice - totalUnitCost

    /** Margin % dari harga jual; null bila harga jual 0 (tidak terdefinisi, bukan nol). */
    fun marginPercent(sellPrice: Long, totalUnitCost: Long): Double? =
        if (sellPrice <= 0) null else (sellPrice - totalUnitCost) * 100.0 / sellPrice
}
