package com.dooyappwork.konveksipro.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Jejak audit untuk semua transaksi penting (aturan bisnis #13). */
@Entity(tableName = "audit_logs", indices = [Index("created_at"), Index("entity_type")])
data class AuditLogEntity(
    @PrimaryKey val id: String,          // UUID
    val actor: String,
    val action: String,                  // CREATE / UPDATE / SOFT_DELETE / ...
    val entity_type: String,
    val entity_id: String?,
    val detail: String?,
    val device_id: String,
    val created_at: Long
)
