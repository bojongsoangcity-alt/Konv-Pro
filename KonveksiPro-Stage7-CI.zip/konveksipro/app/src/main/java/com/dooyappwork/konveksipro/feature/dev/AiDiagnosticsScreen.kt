package com.dooyappwork.konveksipro.feature.dev

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dooyappwork.konveksipro.core.ui.KonveksiTopBar

/**
 * Halaman diagnostik DEVELOPER.
 * Tidak pernah ditautkan pada UI pengguna normal: rute hanya didaftarkan jika
 * BuildConfig.DEV_DIAGNOSTICS = true. Tidak memuat API key sama sekali -
 * hanya status, urutan provider, dan alasan pengecualian.
 */
@Composable
fun AiDiagnosticsScreen(
    statusLines: List<String>,
    providerLines: List<String>,
    exclusionLines: List<String>,
    quotaLine: String,
    onBack: () -> Unit
) {
    Scaffold(topBar = { KonveksiTopBar("Diagnostik AI", "Khusus developer • tanpa kredensial", onBack) }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DiagnosticsCard("Status", statusLines)
            DiagnosticsCard("Rantai provider (urutan percobaan)", providerLines)
            DiagnosticsCard("Provider tidak dipakai", exclusionLines)
            DiagnosticsCard("Pemakaian hari ini", listOf(quotaLine))
            Text(
                "Halaman ini tidak menampilkan API key dan tidak dapat mengubah konfigurasi. " +
                    "Perubahan provider hanya melalui konfigurasi build.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DiagnosticsCard(title: String, lines: List<String>) {
    Card {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            if (lines.isEmpty()) {
                Text("—", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                lines.forEach { line ->
                    Text(
                        line,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    )
                }
            }
        }
    }
}
