package com.dooyappwork.konveksipro.core.utils

import android.content.Context
import androidx.room.Room
import com.dooyappwork.konveksipro.BuildConfig
import com.dooyappwork.konveksipro.ai.AIRequestManager
import com.dooyappwork.konveksipro.ai.AiEventLogger
import com.dooyappwork.konveksipro.ai.config.AiConfigLoader
import com.dooyappwork.konveksipro.ai.config.DeveloperAIConfig
import com.dooyappwork.konveksipro.ai.data.AIQuotaManager
import com.dooyappwork.konveksipro.ai.data.AIUsageTracker
import com.dooyappwork.konveksipro.ai.data.PrefsKeyValueStore
import com.dooyappwork.konveksipro.ai.provider.ProviderHealthChecker
import com.dooyappwork.konveksipro.ai.provider.ProviderRegistry
import com.dooyappwork.konveksipro.ai.provider.ProviderSelector
import com.dooyappwork.konveksipro.ai.repository.AiInsightRepository
import com.dooyappwork.konveksipro.ai.security.SensitiveDataFilter
import com.dooyappwork.konveksipro.ai.transport.HttpJsonTransport
import com.dooyappwork.konveksipro.data.local.KonveksiDatabase
import com.dooyappwork.konveksipro.data.preferences.SettingsRepository
import com.dooyappwork.konveksipro.data.repository.AuditLogRepository
import com.dooyappwork.konveksipro.data.repository.BusinessProfileRepository
import com.dooyappwork.konveksipro.data.repository.CatalogRepository
import com.dooyappwork.konveksipro.data.repository.CustomerRepository
import com.dooyappwork.konveksipro.data.repository.OrderRepository
import com.dooyappwork.konveksipro.data.repository.ProductionRepository
import com.dooyappwork.konveksipro.data.repository.SuppliersRepository
import com.dooyappwork.konveksipro.data.repository.WorkersRepository

/**
 * Penyedia dependency sederhana (tanpa DI framework).
 * catatan keamanan: kripto lisensi Stage 10 memakai Tink, bukan java.security Ed25519
 * (platform Ed25519 baru tersedia mulai API 33; minSdk proyek = 24).
 *
 * Stage 2: seluruh komponen AI dirakit di sini. Konfigurasi AI berasal dari
 * BuildConfig.AI_CONFIG (diisi Gradle saat build) - TIDAK dapat diubah dari UI pengguna.
 * Tahap 3-4: + repository pesanan, produksi, katalog/persediaan, pekerja.
 */
class AppContainer(context: Context) {
    val database: KonveksiDatabase = Room.databaseBuilder(
        context, KonveksiDatabase::class.java, KonveksiDatabase.DB_NAME
    )
        .addMigrations(
            KonveksiDatabase.MIGRATION_1_2,
            KonveksiDatabase.MIGRATION_2_3,
            KonveksiDatabase.MIGRATION_3_4,
            KonveksiDatabase.MIGRATION_4_5
        )
        .build()

    val settings = SettingsRepository(context)

    val auditLogRepository = AuditLogRepository(database)

    val businessProfileRepository = BusinessProfileRepository(
        db = database, audit = auditLogRepository, settings = settings
    )

    val customerRepository = CustomerRepository(
        db = database, audit = auditLogRepository, settings = settings
    )

    // ---------- Tahap 3: Pesanan & Produksi ----------
    val orderRepository = OrderRepository(
        db = database, audit = auditLogRepository, settings = settings
    )

    val productionRepository = ProductionRepository(
        db = database, audit = auditLogRepository, settings = settings
    )

    // ---------- Tahap 4: Katalog & Persediaan ----------
    val catalogRepository = CatalogRepository(
        db = database, audit = auditLogRepository, settings = settings
    )

    val workersRepository = WorkersRepository(
        db = database, audit = auditLogRepository, settings = settings
    )

    // ---------- Tahap 7: Supplier ----------
    val suppliersRepository = SuppliersRepository(
        db = database, audit = auditLogRepository, settings = settings
    )

    // ---------- AI (Developer-Managed) ----------

    /** Dibaca sekali saat proses start; sumbernya hanya build config. */
    val aiConfig: DeveloperAIConfig = AiConfigLoader.load(BuildConfig.AI_CONFIG)

    private val aiUsagePrefs = context.getSharedPreferences("ai_usage", Context.MODE_PRIVATE)

    val aiUsageTracker = AIUsageTracker(PrefsKeyValueStore(aiUsagePrefs))

    val aiQuotaManager = AIQuotaManager(aiUsageTracker, aiConfig.limits)

    private val aiTransport = HttpJsonTransport()

    val aiRegistry = ProviderRegistry.default(aiTransport)

    val aiSelector = ProviderSelector(aiRegistry)

    val aiHealthChecker = ProviderHealthChecker()

    val aiInsightRepository = AiInsightRepository(database.aiInsightDao(), settings)

    val businessSnapshotRepository = com.dooyappwork.konveksipro.ai.repository.BusinessSnapshotRepository(database)

    val aiRequestManager = AIRequestManager(
        configProvider = { aiConfig },
        registry = aiRegistry,
        selector = aiSelector,
        health = aiHealthChecker,
        filter = SensitiveDataFilter(),
        quota = aiQuotaManager,
        usage = aiUsageTracker,
        logger = AiEventLogger { action, detail ->
            auditLogRepository.log(
                action = action,
                entityType = "ai",
                entityId = null,
                detail = detail,
                deviceId = settings.getInstallationId()
            )
        }
    )
}
