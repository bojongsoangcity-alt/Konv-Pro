package com.dooyappwork.konveksipro.ai.provider

import com.dooyappwork.konveksipro.ai.config.AIProviderConfig
import com.dooyappwork.konveksipro.ai.config.ProviderType
import com.dooyappwork.konveksipro.ai.model.AIRequest
import com.dooyappwork.konveksipro.ai.model.FailureKind
import com.dooyappwork.konveksipro.ai.transport.JsonTransport
import com.dooyappwork.konveksipro.ai.util.JsonParser
import com.dooyappwork.konveksipro.ai.util.JsonWriter
import com.dooyappwork.konveksipro.ai.util.asIntOrNull
import com.dooyappwork.konveksipro.ai.util.asStringOrNull
import com.dooyappwork.konveksipro.ai.util.path

/**
 * Google Gemini - generateContent API.
 * POST {baseUrl}/models/{model}:generateContent?key=...  atau header x-goog-api-key.
 * Body: systemInstruction + contents[].parts[].text, generationConfig.
 * Respons: candidates[0].content.parts[].text, usageMetadata.
 */
class GeminiAdapter(transport: JsonTransport) : BaseHttpProvider(transport) {

    override val type = ProviderType.GEMINI

    override fun buildRequest(config: AIProviderConfig, request: AIRequest): PreparedRequest {
        val action = config.path?.takeIf { it.isNotBlank() } ?: "generateContent"
        val url = "${config.baseUrl.trimEnd('/')}/models/${config.model}:$action"
        val maxTokens = config.maxOutputTokensCap?.let { minOf(it, request.maxOutputTokens) } ?: request.maxOutputTokens

        val parts = listOf(JsonWriter.obj("text" to request.prompt))
        val content = JsonWriter.obj(
            "role" to "user",
            "parts" to parts.joinToString(",", "[", "]")
        )
        val body = JsonWriter.obj(
            "contents" to content,
            "systemInstruction" to request.systemInstruction?.let {
                JsonWriter.obj("parts" to listOf(JsonWriter.obj("text" to it)).joinToString(",", "[", "]"))
            },
            "generationConfig" to JsonWriter.obj(
                "temperature" to request.temperature,
                "maxOutputTokens" to maxTokens,
                "candidateCount" to 1
            )
        )
        // Kunci dikirim lewat header (bukan query string) agar tidak ikut tercatat di URL/log proxy.
        val headers = mapOf("x-goog-api-key" to (config.apiKey ?: ""))
        return PreparedRequest(url, headers, body)
    }

    override fun parseResponse(config: AIProviderConfig, body: String): ParsedResponse? {
        val root = JsonParser.parseOrNull(body) ?: return null
        val candidate = root.path("candidates", 0)
        val parts = candidate.path("content", "parts") as? com.dooyappwork.konveksipro.ai.util.JsonNode.Arr
        val text = parts?.items?.mapNotNull { it.path("text").asStringOrNull() }?.joinToString("") ?: ""
        if (text.isBlank()) return null
        val usage = root.path("usageMetadata")
        return ParsedResponse(
            text = text,
            inputTokens = usage.path("promptTokenCount").asIntOrNull() ?: 0,
            outputTokens = usage.path("candidatesTokenCount").asIntOrNull() ?: 0
        )
    }

    override fun classifyHttpError(status: Int, body: String): FailureKind {
        val message = errorMessage(body).lowercase()
        return when {
            status == 429 || message.contains("resource_exhausted") || message.contains("rate limit") -> FailureKind.RATE_LIMIT
            message.contains("quota") || message.contains("billing") -> FailureKind.QUOTA_EXHAUSTED
            status == 400 && message.contains("api key not valid") -> FailureKind.INVALID_KEY
            status == 403 -> FailureKind.INVALID_KEY
            status in 500..599 -> FailureKind.SERVER_ERROR
            else -> FailureKind.fromHttpCode(status)
        }
    }

    override fun errorDetail(body: String?): String? = errorMessage(body ?: "")

    private fun errorMessage(body: String): String {
        val root = JsonParser.parseOrNull(body) ?: return ""
        return root.path("error", "message").asStringOrNull() ?: ""
    }
}
