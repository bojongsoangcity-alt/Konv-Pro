package com.dooyappwork.konveksipro.ai.security

/** Hasil penyaringan: teks bersih + berapa banyak entitas sensitif yang disensor. */
data class FilterOutcome(
    val text: String,
    val redactions: Map<String, Int>
) {
    val totalRedactions: Int get() = redactions.values.sum()
}

/**
 * Menyaring data sensitif sebelum dikirim ke provider eksternal (Bag. 7).
 * Prinsip: kirim agregat, bukan data pelanggan mentah.
 */
class SensitiveDataFilter {

    private data class Rule(val label: String, val regex: Regex)

    private val rules = listOf(
        Rule("EMAIL", Regex("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}")),
        Rule("TELEPON", Regex("(?<!\\d)(?:\\+?62|0)8[0-9]{7,11}(?!\\d)")),
        Rule("TELEPON", Regex("(?<!\\d)\\+?[0-9]{2,3}[\\s\\-]?[0-9]{3,4}[\\s\\-]?[0-9]{3,4}(?!\\d)")),
        Rule("NIK", Regex("(?<!\\d)[0-9]{16}(?!\\d)")),
        Rule("NPWP", Regex("(?<!\\d)[0-9]{2}\\.[0-9]{3}\\.[0-9]{3}\\.[0-9]-[0-9]{3}\\.[0-9]{3}(?!\\d)")),
        Rule("REKENING", Regex("(?i)(rek(ening)?|no\\.?\\s*akun|norek)\\s*[:#]?\\s*[0-9\\s\\-]{8,}")),
        Rule("KARTU", Regex("(?<!\\d)(?:[0-9]{4}[\\s\\-]?){3}[0-9]{4}(?!\\d)")),
        Rule("KREDENSIAL", Regex("AIza[0-9A-Za-z_\\-]{20,}")),
        Rule("KREDENSIAL", Regex("sk-[A-Za-z0-9_\\-]{16,}"))
    )

    fun filter(input: String): FilterOutcome {
        var text = input
        val counts = LinkedHashMap<String, Int>()
        rules.forEach { rule ->
            var n = 0
            text = rule.regex.replace(text) { _ ->
                n++
                "[${rule.label}]"
            }
            if (n > 0) counts[rule.label] = (counts[rule.label] ?: 0) + n
        }
        return FilterOutcome(text, counts)
    }

    /** true = aman dikirim setelah disaring (tidak ada sisa pola kredensial). */
    fun hasResidualSecret(text: String): Boolean =
        Regex("AIza[0-9A-Za-z_\\-]{20,}").containsMatchIn(text) ||
            Regex("sk-[A-Za-z0-9_\\-]{16,}").containsMatchIn(text)
}
