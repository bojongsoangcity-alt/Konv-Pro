package com.dooyappwork.konveksipro.core.theme

import androidx.compose.material3.Typography

/** Tipografi Material 3 default - mudah dibaca, konsisten antar modul. */
val KonveksiTypography = Typography()
