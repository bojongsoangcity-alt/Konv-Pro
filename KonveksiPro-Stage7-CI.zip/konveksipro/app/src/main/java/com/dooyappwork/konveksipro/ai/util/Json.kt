package com.dooyappwork.konveksipro.ai.util

/**
 * Parser JSON minimal tanpa dependensi (target biaya Rp0, tanpa library tambahan).
 * Mendukung object, array, string, number, boolean, null. Cukup untuk membaca
 * respons API AI dan membangun request body. Tidak untuk parsing data besar.
 */
sealed interface JsonNode {
    data class Obj(val values: Map<String, JsonNode>) : JsonNode {
        operator fun get(key: String): JsonNode? = values[key]
    }
    data class Arr(val items: List<JsonNode>) : JsonNode {
        operator fun get(index: Int): JsonNode? = items.getOrNull(index)
    }
    data class Str(val value: String) : JsonNode
    data class Num(val value: Double) : JsonNode
    data class Bool(val value: Boolean) : JsonNode
    data object Null : JsonNode
}

/** Jalur aman: `root.path("a","b",0)` mengembalikan null jika ada yang hilang. */
fun JsonNode?.path(vararg keys: Any): JsonNode? {
    var current: JsonNode? = this
    for (key in keys) {
        current = when (key) {
            is Int -> (current as? JsonNode.Arr)?.get(key)
            is String -> (current as? JsonNode.Obj)?.get(key)
            else -> null
        }
        if (current == null) return null
    }
    return current
}

fun JsonNode?.asStringOrNull(): String? = when (this) {
    is JsonNode.Str -> value
    is JsonNode.Num -> if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
    is JsonNode.Bool -> value.toString()
    else -> null
}

fun JsonNode?.asIntOrNull(): Int? = when (this) {
    is JsonNode.Num -> value.toInt()
    is JsonNode.Str -> value.toIntOrNull()
    else -> null
}

class JsonParseException(message: String) : Exception(message)

object JsonParser {

    fun parse(text: String): JsonNode {
        val p = Cursor(text)
        p.skipWs()
        val node = p.readValue()
        p.skipWs()
        if (!p.atEnd()) throw JsonParseException("Karakter sisa pada posisi ${p.pos}")
        return node
    }

    /** Coba parse; null jika gagal (dipakai untuk respons tak terduga). */
    fun parseOrNull(text: String?): JsonNode? =
        if (text.isNullOrBlank()) null else runCatching { parse(text) }.getOrNull()

    private class Cursor(private val s: String) {
        var pos = 0
        fun atEnd() = pos >= s.length
        fun skipWs() { while (pos < s.length && s[pos].isWhitespace()) pos++ }

        fun readValue(): JsonNode {
            skipWs()
            if (atEnd()) throw JsonParseException("Input habis")
            return when (val c = s[pos]) {
                '{' -> readObject()
                '[' -> readArray()
                '"' -> JsonNode.Str(readString())
                't', 'f' -> readBool()
                'n' -> { expect("null"); JsonNode.Null }
                else -> if (c == '-' || c.isDigit()) readNumber()
                else throw JsonParseException("Karakter tak terduga '$c' di $pos")
            }
        }

        private fun expect(word: String) {
            if (!s.startsWith(word, pos)) throw JsonParseException("Diharapkan '$word' di $pos")
            pos += word.length
        }

        private fun readBool(): JsonNode = when {
            s.startsWith("true", pos) -> { pos += 4; JsonNode.Bool(true) }
            s.startsWith("false", pos) -> { pos += 5; JsonNode.Bool(false) }
            else -> throw JsonParseException("Boolean tidak valid di $pos")
        }

        private fun readObject(): JsonNode.Obj {
            pos++ // {
            val map = LinkedHashMap<String, JsonNode>()
            skipWs()
            if (!atEnd() && s[pos] == '}') { pos++; return JsonNode.Obj(map) }
            while (true) {
                skipWs()
                if (atEnd() || s[pos] != '"') throw JsonParseException("Key object tidak valid di $pos")
                val key = readString()
                skipWs()
                if (atEnd() || s[pos] != ':') throw JsonParseException("Diharapkan ':' di $pos")
                pos++
                map[key] = readValue()
                skipWs()
                if (atEnd()) throw JsonParseException("Object tidak tertutup")
                when (s[pos]) {
                    ',' -> pos++
                    '}' -> { pos++; return JsonNode.Obj(map) }
                    else -> throw JsonParseException("Diharapkan ',' atau '}' di $pos")
                }
            }
        }

        private fun readArray(): JsonNode.Arr {
            pos++ // [
            val items = ArrayList<JsonNode>()
            skipWs()
            if (!atEnd() && s[pos] == ']') { pos++; return JsonNode.Arr(items) }
            while (true) {
                items.add(readValue())
                skipWs()
                if (atEnd()) throw JsonParseException("Array tidak tertutup")
                when (s[pos]) {
                    ',' -> pos++
                    ']' -> { pos++; return JsonNode.Arr(items) }
                    else -> throw JsonParseException("Diharapkan ',' atau ']' di $pos")
                }
            }
        }

        private fun readString(): String {
            pos++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (atEnd()) throw JsonParseException("String tidak tertutup")
                when (val c = s[pos]) {
                    '"' -> { pos++; return sb.toString() }
                    '\\' -> {
                        pos++
                        if (atEnd()) throw JsonParseException("Escape tidak lengkap")
                        when (val e = s[pos]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 >= s.length) throw JsonParseException("Unicode tidak lengkap")
                                val hex = s.substring(pos + 1, pos + 5)
                                sb.append(hex.toInt(16).toChar())
                                pos += 4
                            }
                            else -> throw JsonParseException("Escape tidak dikenal '\\$e'")
                        }
                        pos++
                    }
                    else -> { sb.append(c); pos++ }
                }
            }
        }

        private fun readNumber(): JsonNode.Num {
            val start = pos
            if (pos < s.length && s[pos] == '-') pos++
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.' || s[pos] == 'e' || s[pos] == 'E' || s[pos] == '+' || s[pos] == '-')) pos++
            val raw = s.substring(start, pos)
            val d = raw.toDoubleOrNull() ?: throw JsonParseException("Angka tidak valid '$raw'")
            return JsonNode.Num(d)
        }
    }
}

object JsonWriter {

    fun escape(value: String): String {
        val sb = StringBuilder(value.length + 8)
        value.forEach { c ->
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else -> if (c < ' ') sb.append("\\u%04x".format(c.code)) else sb.append(c)
            }
        }
        return sb.toString()
    }

    fun quote(value: String): String = "\"${escape(value)}\""

    /** a=1,b="x" -> {"a":1,"b":"x"} */
    fun obj(vararg pairs: Pair<String, Any?>): String =
        pairs.filter { it.second != null }.joinToString(",", "{", "}") { (k, v) ->
            "${quote(k)}:" + when (v) {
                is String -> quote(v)
                is Boolean -> v.toString()
                is Int, is Long -> v.toString()
                is Double -> formatNumber(v)
                else -> quote(v.toString())
            }
        }

    /** Array string -> ["a","b"] */
    fun stringArray(values: List<String>): String =
        values.joinToString(",", "[", "]") { quote(it) }

    fun formatNumber(value: Double): String =
        if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
}
