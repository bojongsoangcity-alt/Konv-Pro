package com.dooyappwork.konveksipro.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dooyappwork.konveksipro.BuildConfig
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.feature.containerFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val consentGiven: Boolean = false,
    val externalAvailable: Boolean = false,
    /** Hanya true pada build yang secara eksplisit mengaktifkan dev.diagnostics. */
    val diagnosticsEnabled: Boolean = BuildConfig.DEV_DIAGNOSTICS
)

class SettingsViewModel(private val container: AppContainer) : ViewModel() {

    private val _state = MutableStateFlow(
        SettingsUiState(
            externalAvailable = container.aiConfig.externalEnabled && container.aiConfig.hasUsableProvider
        )
    )
    val state: StateFlow<SettingsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            runCatching { container.settings.isAiConsentGiven() }
                .onSuccess { consent -> _state.update { it.copy(consentGiven = consent) } }
        }
    }

    fun setConsent(given: Boolean) {
        _state.update { it.copy(consentGiven = given) }
        viewModelScope.launch {
            runCatching { container.settings.setAiConsent(given) }
                .onFailure { _state.update { s -> s.copy(consentGiven = !given) } }
        }
    }

    companion object {
        fun factory(): ViewModelProvider.Factory = containerFactory { SettingsViewModel(it) }
    }
}
