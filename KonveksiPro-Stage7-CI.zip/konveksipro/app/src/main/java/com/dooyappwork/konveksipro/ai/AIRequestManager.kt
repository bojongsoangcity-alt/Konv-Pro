package com.dooyappwork.konveksipro.ai

import com.dooyappwork.konveksipro.ai.config.AIProviderConfig
import com.dooyappwork.konveksipro.ai.config.DeveloperAIConfig
import com.dooyappwork.konveksipro.ai.data.AIQuotaManager
import com.dooyappwork.konveksipro.ai.data.AIUsageTracker
import com.dooyappwork.konveksipro.ai.local.InsightPromptBuilder
import com.dooyappwork.konveksipro.ai.model.AIRequest
import com.dooyappwork.konveksipro.ai.model.FailureKind
import com.dooyappwork.konveksipro.ai.model.InsightReport
import com.dooyappwork.konveksipro.ai.model.ProviderResult
import com.dooyappwork.konveksipro.ai.provider.ProviderHealthChecker
import com.dooyappwork.konveksipro.ai.provider.ProviderRegistry
import com.dooyappwork.konveksipro.ai.provider.ProviderSelector
import com.dooyappwork.konveksipro.ai.security.SensitiveDataFilter
import com.dooyappwork.konveksipro.ai.security.SecretRedactor
import java.util.UUID

/** Hasil akhir: narasi eksternal (jika berhasil) atau alasan fallback ke analisis lokal. */
sealed interface AIOutcome {
    data class External(
        val text: String,
        val providerId: String,
        val tokensIn: Int,
        val tokensOut: Int
    ) : AIOutcome

    data class LocalOnly(
        val reason: FailureKind,
        val message: String,
        val safeDetail: String
    ) : AIOutcome
}

/** Pemanggil provider yang bisa diganti fake saat pengujian. */
fun interface ProviderInvoker {
    suspend fun invoke(provider: AIProviderConfig, request: AIRequest): ProviderResult
}

/** Pencatat peristiwa AI (tanpa kredensial, tanpa isi data pelanggan). */
fun interface AiEventLogger {
    suspend fun log(action: String, detail: String)
}

/**
 * Orkestrator permintaan AI:
 *  1) cek konfigurasi developer & consent pengguna
 *  2) filter data sensitif
 *  3) cek kuota internal
 *  4) coba primary -> fallback (terbatas, tanpa retry tanpa akhir)
 *  5) jika semua gagal: kembalikan LocalOnly (analisis lokal tetap dipakai UI)
 */
class AIRequestManager(
    private val configProvider: () -> DeveloperAIConfig,
    private val registry: ProviderRegistry,
    private val selector: ProviderSelector,
    private val health: ProviderHealthChecker,
    private val filter: SensitiveDataFilter,
    private val quota: AIQuotaManager,
    private val usage: AIUsageTracker,
    private val promptBuilder: InsightPromptBuilder = InsightPromptBuilder(),
    private val logger: AiEventLogger? = null,
    private val invoker: ProviderInvoker? = null,
    private val maxRetriesPerProvider: Int = 1
) {
    val currentConfig: DeveloperAIConfig get() = configProvider()

    suspend fun analyze(report: InsightReport, consentGiven: Boolean): AIOutcome {
        val config = configProvider()

        if (!config.externalEnabled) {
            return localOnly(FailureKind.DISABLED, "Layanan AI eksternal tidak diaktifkan pada build ini.")
        }
        if (config.privacy.requireConsent && !consentGiven) {
            return localOnly(FailureKind.BLOCKED_BY_FILTER, "Persetujuan pengiriman data belum diberikan.")
        }
        val chain = selector.chain(config)
        if (chain.isEmpty()) {
            return localOnly(FailureKind.NOT_CONFIGURED, "Tidak ada provider AI yang siap dipakai.")
        }
        if (!report.dataReady) {
            return localOnly(FailureKind.NOT_CONFIGURED, "Data sumber analisis belum tersedia.")
        }

        val quotaDecision = quota.evaluate()
        if (!quotaDecision.allowed) {
            return localOnly(FailureKind.QUOTA_EXHAUSTED, quotaDecision.reason ?: "Batas penggunaan tercapai.")
        }

        val rawPrompt = promptBuilder.build(report)
        val filtered = filter.filter(rawPrompt)
        if (filter.hasResidualSecret(filtered.text)) {
            return localOnly(FailureKind.BLOCKED_BY_FILTER, "Prompt masih memuat pola kredensial setelah penyaringan.")
        }

        val request = AIRequest(
            purpose = report.kind,
            prompt = filtered.text,
            systemInstruction = SYSTEM_INSTRUCTION,
            maxOutputTokens = 512,
            correlationId = UUID.randomUUID().toString()
        )

        var lastFailure: ProviderResult.Failure? = null
        for (provider in chain) {
            if (health.isUnhealthy(provider)) {
                lastFailure = ProviderResult.Failure(
                    FailureKind.SERVER_ERROR,
                    "provider ${provider.id} dilewati: gagal berulang dalam 5 menit"
                )
                continue
            }
            val budget = quota.providerBudgetCheck(provider)
            if (!budget.allowed) {
                lastFailure = ProviderResult.Failure(FailureKind.QUOTA_EXHAUSTED, budget.reason ?: "anggaran diblokir")
                continue
            }
            val adapter = registry.adapterFor(provider) ?: continue
            val result = invoker?.invoke(provider, request) ?: adapter.execute(provider, request)
            when (result) {
                is ProviderResult.Success -> {
                    health.recordSuccess(provider.id)
                    val cost = usage.estimateCostUsd(
                        result.inputTokens, result.outputTokens,
                        provider.pricePer1kInputUsd, provider.pricePer1kOutputUsd
                    )
                    usage.recordSuccess(provider.id, result.inputTokens, result.outputTokens, cost)
                    logger?.log(
                        "AI_REQUEST",
                        "ok provider=${provider.id} tokens=${result.inputTokens + result.outputTokens} " +
                            "cost=${"%.5f".format(cost)}"
                    )
                    return AIOutcome.External(
                        text = result.text,
                        providerId = provider.id,
                        tokensIn = result.inputTokens,
                        tokensOut = result.outputTokens
                    )
                }

                is ProviderResult.Failure -> {
                    health.record(provider.id, result.kind)
                    usage.recordFailure(provider.id)
                    lastFailure = result
                    logger?.log(
                        "AI_FAIL",
                        "provider=${provider.id} kind=${result.kind.name} detail=${SecretRedactor.safeDetail(result.safeDetail)}"
                    )
                }
            }
        }

        val failure = lastFailure ?: ProviderResult.Failure(FailureKind.SERVER_ERROR, "semua provider gagal")
        return localOnly(failure.kind, failure.kind.userMessage, failure.safeDetail)
    }

    private fun localOnly(kind: FailureKind, message: String, detail: String = ""): AIOutcome.LocalOnly =
        AIOutcome.LocalOnly(kind, message, SecretRedactor.safeDetail(detail))

    companion object {
        private const val SYSTEM_INSTRUCTION =
            "Anda analis operasional konveksi. Gunakan hanya fakta yang diberikan. " +
                "Jangan mengarang angka, nama, atau kebijakan. Bahasa Indonesia, ringkas, tanpa basa-basi."
    }
}
