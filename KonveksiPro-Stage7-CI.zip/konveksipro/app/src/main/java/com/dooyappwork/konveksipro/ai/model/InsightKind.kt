package com.dooyappwork.konveksipro.ai.model

/**
 * Jenis analisis yang boleh dipakai pengguna (Bag. 5 instruksi AI).
 * Setiap jenis punya versi LOKAL berbasis aturan. Versi eksternal hanya
 * menambah narasi di atas fakta lokal - tidak menggantikan perhitungan lokal.
 * Tahap 3-4: seluruh modul kini punya tabel datanya sendiri (dataReady = true).
 */
enum class InsightKind(
    val title: String,
    val subtitle: String,
    /** true jika data untuk analisis ini SUDAH ada di database tahap sekarang. */
    val dataReady: Boolean
) {
    BUSINESS("Analisis Usaha", "Kesehatan usaha & prioritas tindakan", true),
    PRODUCTION("Analisis Produksi", "Beban kerja & hambatan produksi", true),
    INVENTORY("Analisis Persediaan", "Stok bahan & risiko kehabisan", true),
    COSTING("Analisis HPP", "Struktur biaya & margin", true),
    ORDER("Analisis Pesanan", "Antrean pesanan & ketepatan waktu", true),
    MATERIAL("Material Insight", "Ringkasan material", true),
    WORKER("Worker Insight", "Ringkasan tenaga kerja", true);

    companion object {
        fun fromKey(key: String?): InsightKind? = entries.firstOrNull { it.name == key }
    }
}
