package com.dooyappwork.konveksipro.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Katalog & persediaan (Tahap 4): produk, resep bahan (BOM), material,
 * supplier, pekerja. Semua dibuat lewat MIGRATION v4 - tabel lama tidak disentuh.
 */

@Entity(tableName = "products", indices = [Index("name")])
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String?,
    val sell_price: Long,                    // harga jual per unit (rupiah)
    // Tahap 7: upah & overhead per unit (opsional, default 0) - melengkapi HPP
    // yang sebelumnya hanya material. Kolom ditambah lewat MIGRATION_4_5 (ALTER TABLE).
    @ColumnInfo(defaultValue = "0") val labor_cost: Long = 0,
    @ColumnInfo(defaultValue = "0") val overhead_cost: Long = 0,
    val is_active: Boolean = true,
    val notes: String?,
    val created_at: Long,
    val updated_at: Long,
    val deleted_at: Long? = null,
    val device_id: String,
    val sync_status: String = "PENDING"
)

/** Resep bahan per produk: kebutuhan material per 1 unit jadi. */
@Entity(tableName = "recipe_items", indices = [Index("product_id"), Index("material_id")])
data class RecipeItemEntity(
    @PrimaryKey val id: String,
    val product_id: String,
    val material_id: String,
    val qty_per_unit: Double,                // boleh pecahan (mis. 1.5 meter kain)
    val created_at: Long
)

@Entity(tableName = "materials", indices = [Index("name")])
data class MaterialEntity(
    @PrimaryKey val id: String,
    val name: String,
    val unit: String,                        // meter / pcs / kg / roll
    val stock: Double,                       // stok dalam satuan unit
    val min_stock: Double,                   // batas minimum - pemicu peringatan
    val buy_price: Long,                     // harga beli per unit (rupiah)
    val supplier_id: String?,
    val notes: String?,
    val created_at: Long,
    val updated_at: Long,
    val deleted_at: Long? = null,
    val device_id: String,
    val sync_status: String = "PENDING"
)

@Entity(tableName = "suppliers", indices = [Index("name")])
data class SupplierEntity(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String?,
    val address: String?,
    val notes: String?,
    val created_at: Long,
    val updated_at: Long,
    val deleted_at: Long? = null,
    val device_id: String,
    val sync_status: String = "PENDING"
)

@Entity(tableName = "workers", indices = [Index("name")])
data class WorkerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val role: String?,                       // mis. Cutting, Sewing, QC, Packing
    val phone: String?,
    val notes: String?,
    val created_at: Long,
    val updated_at: Long,
    val deleted_at: Long? = null,
    val device_id: String,
    val sync_status: String = "PENDING"
)
