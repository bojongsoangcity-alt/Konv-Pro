package com.dooyappwork.konveksipro.feature.ai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dooyappwork.konveksipro.ai.AIOutcome
import com.dooyappwork.konveksipro.ai.AIResponseParser
import com.dooyappwork.konveksipro.ai.config.DeveloperAIConfig
import com.dooyappwork.konveksipro.ai.data.AiInsightEntity
import com.dooyappwork.konveksipro.ai.local.LocalInsightEngine
import com.dooyappwork.konveksipro.ai.model.InsightKind
import com.dooyappwork.konveksipro.ai.model.InsightReport
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.core.utils.formatRupiah
import com.dooyappwork.konveksipro.feature.containerFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Status narasi eksternal untuk ditampilkan apa adanya (tanpa klaim palsu). */
enum class NarrativeStatus { NONE, LOADING, AVAILABLE, UNAVAILABLE }

data class AiAssistantUiState(
    val isLoading: Boolean = true,
    val selected: InsightKind = InsightKind.BUSINESS,
    val report: InsightReport? = null,
    val narrativeStatus: NarrativeStatus = NarrativeStatus.NONE,
    val narrative: List<String> = emptyList(),
    val narrativeMessage: String? = null,
    val aiStatusLabel: String = "",
    val externalConfigured: Boolean = false,
    val consentGiven: Boolean = false,
    val showConsentDialog: Boolean = false,
    val isSaving: Boolean = false,
    val savedMessage: String? = null,
    val history: List<AiInsightEntity> = emptyList(),
    val error: String? = null
)

class AiAssistantViewModel(private val container: AppContainer) : ViewModel() {

    private val engine = LocalInsightEngine()
    private val parser = AIResponseParser()
    private val _state = MutableStateFlow(AiAssistantUiState())
    val state: StateFlow<AiAssistantUiState> = _state.asStateFlow()

    private val config: DeveloperAIConfig = container.aiConfig

    init {
        _state.update {
            it.copy(
                aiStatusLabel = config.statusLabel(),
                externalConfigured = config.externalEnabled && config.hasUsableProvider
            )
        }
        viewModelScope.launch {
            runCatching { container.settings.isAiConsentGiven() }
                .onSuccess { consent -> _state.update { it.copy(consentGiven = consent) } }
            container.aiInsightRepository.observeRecent(10).collect { history ->
                _state.update { it.copy(history = history) }
            }
        }
        refresh(InsightKind.BUSINESS)
    }

    fun refresh(kind: InsightKind = _state.value.selected) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, selected = kind, error = null, narrativeStatus = NarrativeStatus.NONE, narrative = emptyList(), narrativeMessage = null, savedMessage = null) }
            try {
                val snapshot = container.businessSnapshotRepository.build()
                val report = engine.analyze(kind, snapshot, ::formatRupiah)
                _state.update { it.copy(isLoading = false, report = report) }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message ?: "Gagal menyusun analisis lokal") }
            }
        }
    }

    /** Narasi eksternal hanya ditambahkan bila berhasil; jika tidak, pesan jujur ditampilkan. */
    fun requestNarrative() {
        val report = _state.value.report ?: return
        if (!report.dataReady) return
        if (config.privacy.requireConsent && !_state.value.consentGiven) {
            _state.update { it.copy(showConsentDialog = true) }
            return
        }
        launchNarrative(report)
    }

    fun confirmConsent() {
        viewModelScope.launch {
            runCatching { container.settings.setAiConsent(true) }
            _state.update { it.copy(consentGiven = true, showConsentDialog = false) }
            _state.value.report?.let { launchNarrative(it) }
        }
    }

    fun declineConsent() {
        viewModelScope.launch {
            runCatching { container.settings.setAiConsent(false) }
            _state.update {
                it.copy(
                    consentGiven = false,
                    showConsentDialog = false,
                    narrativeStatus = NarrativeStatus.UNAVAILABLE,
                    narrativeMessage = "Tanpa persetujuan, data tidak dikirim ke layanan AI eksternal. Analisis lokal tetap dipakai."
                )
            }
        }
    }

    fun dismissConsentDialog() = _state.update { it.copy(showConsentDialog = false) }

    private fun launchNarrative(report: InsightReport) {
        viewModelScope.launch {
            _state.update { it.copy(narrativeStatus = NarrativeStatus.LOADING, narrativeMessage = null, isSaving = true) }
            val outcome = container.aiRequestManager.analyze(report, consentGiven = true)
            when (outcome) {
                is AIOutcome.External -> {
                    val bullets = parser.toBullets(outcome.text)
                    _state.update {
                        it.copy(
                            narrativeStatus = if (bullets.isEmpty()) NarrativeStatus.UNAVAILABLE else NarrativeStatus.AVAILABLE,
                            narrative = bullets,
                            narrativeMessage = if (bullets.isEmpty()) "Layanan AI mengirim jawaban kosong. Analisis lokal tetap ditampilkan." else null,
                            isSaving = false,
                            savedMessage = "Narasi AI ditambahkan (${outcome.providerId})."
                        )
                    }
                    container.aiInsightRepository.save(report, bullets.joinToString("\n"), outcome.providerId, outcome.tokensIn + outcome.tokensOut)
                }

                is AIOutcome.LocalOnly -> {
                    _state.update {
                        it.copy(
                            narrativeStatus = NarrativeStatus.UNAVAILABLE,
                            narrative = emptyList(),
                            narrativeMessage = outcome.message,
                            isSaving = false,
                            savedMessage = null
                        )
                    }
                    container.aiInsightRepository.save(report, null, null, 0)
                }
            }
        }
    }

    companion object {
        fun factory(): ViewModelProvider.Factory = containerFactory { AiAssistantViewModel(it) }
    }
}
