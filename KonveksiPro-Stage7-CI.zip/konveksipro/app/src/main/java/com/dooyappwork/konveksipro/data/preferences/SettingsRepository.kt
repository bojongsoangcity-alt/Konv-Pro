package com.dooyappwork.konveksipro.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import java.util.UUID

private val Context.appDataStore by preferencesDataStore(name = "app_settings")

/**
 * Identitas instalasi (UUID, bukan IMEI / nomor telepon) - sesuai kebijakan lisensi Bag. 8D.
 * Dipakai sebagai device_id pada semua record (kesiapan sinkronisasi masa depan).
 */
class SettingsRepository(private val context: Context) {

    private val keyInstallationId = stringPreferencesKey("installation_id")
    /** Persetujuan pengiriman data agregat ke layanan AI eksternal (Stage 2). */
    private val keyAiConsent = stringPreferencesKey("ai_consent")

    suspend fun getInstallationId(): String {
        val existing = context.appDataStore.data.first()[keyInstallationId]
        if (!existing.isNullOrBlank()) return existing
        val newId = UUID.randomUUID().toString()
        context.appDataStore.edit { it[keyInstallationId] = newId }
        return newId
    }

    /** false = pengguna belum/tidak menyetujui pengiriman data ke AI eksternal. */
    suspend fun isAiConsentGiven(): Boolean =
        context.appDataStore.data.first()[keyAiConsent] == "true"

    suspend fun setAiConsent(given: Boolean) {
        context.appDataStore.edit { it[keyAiConsent] = if (given) "true" else "false" }
    }
}
