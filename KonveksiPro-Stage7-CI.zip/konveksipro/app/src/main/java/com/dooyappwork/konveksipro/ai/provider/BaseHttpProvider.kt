package com.dooyappwork.konveksipro.ai.provider

import com.dooyappwork.konveksipro.ai.config.AIProviderConfig
import com.dooyappwork.konveksipro.ai.model.AIRequest
import com.dooyappwork.konveksipro.ai.model.FailureKind
import com.dooyappwork.konveksipro.ai.model.ProviderResult
import com.dooyappwork.konveksipro.ai.security.SecretRedactor
import com.dooyappwork.konveksipro.ai.transport.JsonTransport
import com.dooyappwork.konveksipro.ai.transport.HttpOutcome
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Perilaku bersama adapter: timeout global, retry TERBATAS (maks 1x, hanya untuk
 * kegagalan sementara), dan penyaringan pesan error.
 */
abstract class BaseHttpProvider(
    protected val transport: JsonTransport
) : AIProvider {

    abstract fun classifyHttpError(status: Int, body: String): FailureKind

    abstract fun errorDetail(body: String?): String?

    override suspend fun execute(config: AIProviderConfig, request: AIRequest): ProviderResult {
        val prepared = buildRequest(config, request)
        val started = System.currentTimeMillis()
        var attempt = 0
        var lastFailure: ProviderResult.Failure? = null

        while (attempt <= config.maxRetries) {
            val outcome = withTimeoutOrNull(config.timeoutMs + 2_000) {
                transport.postJson(prepared.url, prepared.headers, prepared.body, config.timeoutMs)
            } ?: HttpOutcome.NetworkError(FailureKind.TIMEOUT, "batas waktu aplikasi tercapai")

            when (outcome) {
                is HttpOutcome.Response -> {
                    if (outcome.status in 200..299) {
                        val parsed = parseResponse(config, outcome.body)
                        if (parsed != null && parsed.text.isNotBlank()) {
                            return ProviderResult.Success(
                                text = parsed.text.trim(),
                                inputTokens = parsed.inputTokens,
                                outputTokens = parsed.outputTokens,
                                latencyMs = System.currentTimeMillis() - started
                            )
                        }
                        lastFailure = ProviderResult.Failure(
                            FailureKind.BAD_RESPONSE,
                            "respons tanpa teks (status ${outcome.status})"
                        )
                        return lastFailure
                    }
                    val kind = classifyHttpError(outcome.status, outcome.body)
                    lastFailure = ProviderResult.Failure(
                        kind,
                        SecretRedactor.safeDetail("HTTP ${outcome.status}: ${errorDetail(outcome.body) ?: outcome.body}")
                    )
                    if (!kind.retryable || attempt >= config.maxRetries) return lastFailure
                }

                is HttpOutcome.NetworkError -> {
                    lastFailure = ProviderResult.Failure(outcome.kind, outcome.safeDetail)
                    if (!outcome.kind.retryable || attempt >= config.maxRetries) return lastFailure
                }
            }
            attempt++
            if (attempt <= config.maxRetries) delay(400L * attempt)
        }
        return lastFailure ?: ProviderResult.Failure(FailureKind.SERVER_ERROR, "gagal tanpa detail")
    }
}
