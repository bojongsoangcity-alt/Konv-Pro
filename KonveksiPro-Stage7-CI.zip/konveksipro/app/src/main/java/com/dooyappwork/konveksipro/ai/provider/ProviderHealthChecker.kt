package com.dooyappwork.konveksipro.ai.provider

import com.dooyappwork.konveksipro.ai.config.AIProviderConfig
import com.dooyappwork.konveksipro.ai.model.FailureKind

/**
 * Penanda kesehatan ringan (in-memory, per proses) agar aplikasi tidak
 * menghantam provider yang baru saja gagal berat. Bukan circuit-breaker persisten.
 */
class ProviderHealthChecker(
    private val holder: MutableMap<String, MutableList<Long>> = mutableMapOf()
) {
    data class Snapshot(val providerId: String, val recentFailures: Int, val lastFailureAt: Long?)

    fun record(providerId: String, kind: FailureKind) {
        if (!kind.retryable) return
        val list = holder.getOrPut(providerId) { mutableListOf() }
        list.add(System.currentTimeMillis())
        if (list.size > 20) list.removeAt(0)
    }

    fun recordSuccess(providerId: String) {
        holder[providerId]?.clear()
    }

    /** true = provider dianggap tidak sehat sementara (>=3 kegagalan dalam 5 menit). */
    fun isUnhealthy(config: AIProviderConfig): Boolean {
        val list = holder[config.id] ?: return false
        val cutoff = System.currentTimeMillis() - 5 * 60_000
        return list.count { it >= cutoff } >= 3
    }

    fun snapshot(config: AIProviderConfig): Snapshot {
        val list = holder[config.id].orEmpty()
        return Snapshot(config.id, list.size, list.lastOrNull())
    }

    fun reset() = holder.clear()
}
