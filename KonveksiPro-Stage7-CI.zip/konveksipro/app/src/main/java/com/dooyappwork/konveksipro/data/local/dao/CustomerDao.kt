package com.dooyappwork.konveksipro.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dooyappwork.konveksipro.data.local.entities.CustomerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers WHERE deleted_at IS NULL ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<CustomerEntity>>

    @Query("SELECT COUNT(*) FROM customers WHERE deleted_at IS NULL")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM customers WHERE deleted_at IS NULL AND name = :name COLLATE NOCASE")
    suspend fun countByName(name: String): Int

    // --- Stage 2: agregat untuk analisis lokal (tidak mengubah query lama) ---
    @Query("SELECT COUNT(*) FROM customers WHERE deleted_at IS NULL AND (phone IS NULL OR phone = '') AND (email IS NULL OR email = '')")
    suspend fun countWithoutContact(): Int

    @Query("SELECT COUNT(*) FROM customers WHERE deleted_at IS NULL AND created_at >= :since")
    suspend fun countCreatedSince(since: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(customer: CustomerEntity)

    @Query("UPDATE customers SET deleted_at = :now, updated_at = :now, sync_status = 'PENDING' WHERE id = :id")
    suspend fun softDelete(id: String, now: Long): Int
}
