package com.dooyappwork.konveksipro.ai.model

/** Hasil satu panggilan provider. `safeDetail` wajib sudah disaring (tanpa API key). */
sealed interface ProviderResult {
    data class Success(
        val text: String,
        val inputTokens: Int,
        val outputTokens: Int,
        val latencyMs: Long
    ) : ProviderResult

    data class Failure(
        val kind: FailureKind,
        val safeDetail: String
    ) : ProviderResult
}
