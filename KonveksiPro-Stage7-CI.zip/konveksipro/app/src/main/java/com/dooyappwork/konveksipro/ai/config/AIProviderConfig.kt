package com.dooyappwork.konveksipro.ai.config

/** Jenis adapter yang benar-benar diimplementasikan + diuji (Bag. 3). */
enum class ProviderType {
    NONE,
    GEMINI,
    OPENAI_COMPATIBLE,
    /** Adapter generik; hanya aktif jika developer menandai `verified=true`. */
    CUSTOM;

    companion object {
        fun from(value: String?): ProviderType =
            entries.firstOrNull { it.name.equals(value?.trim(), ignoreCase = true) } ?: NONE
    }
}

/**
 * Konfigurasi satu provider. Berisi API key, sehingga:
 *  - `toString()` WAJIB disensor (tidak boleh muncul di log/anr/crash report),
 *  - `keyFingerprint()` tidak pernah mengembalikan potongan key asli.
 */
data class AIProviderConfig(
    val id: String,
    val type: ProviderType,
    val baseUrl: String,
    val model: String,
    val apiKey: String?,
    val enabled: Boolean,
    val priority: Int,
    val timeoutMs: Long,
    val maxRetries: Int,
    val pricePer1kInputUsd: Double? = null,
    val pricePer1kOutputUsd: Double? = null,
    val maxOutputTokensCap: Int? = null,
    val verified: Boolean = false,
    val path: String? = null,
    val authHeader: String = "Authorization",
    val authPrefix: String = "Bearer "
) {
    val isConfigured: Boolean
        get() = enabled && type != ProviderType.NONE &&
            apiKey?.isNotBlank() == true && baseUrl.isNotBlank() && model.isNotBlank()

    fun keyFingerprint(): String = if (apiKey.isNullOrBlank()) "tidak ada" else "•••••• (${apiKey.length} karakter)"

    /** Label aman untuk UI/log. */
    fun describe(): String = "provider=$id type=$type model=$model key=${keyFingerprint()}"

    override fun toString(): String = describe()
}
