package com.dooyappwork.konveksipro.core.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Blue800,
    onPrimary = Color.White,                    // 5.75:1 di atas Blue800
    primaryContainer = BlueContainerLight,
    onPrimaryContainer = Navy900,
    secondary = Orange500,
    onSecondary = Navy900,                      // 5.59:1 - BUKAN putih (2.82:1 fail)
    secondaryContainer = OrangeContainerLight,
    onSecondaryContainer = Navy900,
    tertiary = ElectricBlue,
    background = LightBackground,
    onBackground = Navy900,
    surface = LightSurface,
    onSurface = Navy900,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = OnSurfaceVariantLight,
    error = ErrorRed
)

private val DarkColors = darkColorScheme(
    primary = BlueTint,
    onPrimary = Navy900,
    primaryContainer = Navy800,
    onPrimaryContainer = BlueTint,
    secondary = OrangeTint,
    onSecondary = Navy900,
    background = DarkBackground,
    onBackground = TextOnDark,
    surface = DarkSurface,
    onSurface = TextOnDark,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = OnSurfaceVariantDark
)

@Composable
fun KonveksiProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Warna brand dikunci (tanpa dynamic color) agar identitas konsisten antar modul.
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = KonveksiTypography,
        content = content
    )
}
