package com.dooyappwork.konveksipro.ai.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AiInsightDao {
    @Insert
    suspend fun insert(entity: AiInsightEntity)

    @Query("SELECT * FROM ai_insights ORDER BY created_at DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<AiInsightEntity>>

    @Query("SELECT COUNT(*) FROM ai_insights")
    fun observeCount(): Flow<Int>

    @Query("DELETE FROM ai_insights WHERE created_at < :cutoff")
    suspend fun deleteOlderThan(cutoff: Long): Int
}
