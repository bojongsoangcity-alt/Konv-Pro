package com.dooyappwork.konveksipro.feature.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dooyappwork.konveksipro.ai.model.InsightKind
import com.dooyappwork.konveksipro.ai.model.InsightMetric
import com.dooyappwork.konveksipro.core.ui.ErrorState
import com.dooyappwork.konveksipro.core.ui.KonveksiTopBar
import com.dooyappwork.konveksipro.core.ui.LoadingState
import com.dooyappwork.konveksipro.core.utils.formatDateTime

@Composable
fun AiAssistantScreen(
    onBack: () -> Unit,
    viewModel: AiAssistantViewModel = viewModel(factory = AiAssistantViewModel.factory())
) {
    val state by viewModel.state.collectAsState()

    Scaffold(topBar = { KonveksiTopBar("Asisten AI", "Analisis usaha berbasis data toko", onBack) }) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when {
                state.isLoading -> LoadingState()
                state.error != null -> ErrorState(state.error ?: "")
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { AiModeBanner(state) }
                    item { InsightKindSelector(state.selected) { viewModel.refresh(it) } }

                    state.report?.let { report ->
                        item {
                            Column {
                                Text(report.headline, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                report.note?.let {
                                    Spacer(Modifier.height(4.dp))
                                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        if (report.metrics.isNotEmpty()) {
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    report.metrics.chunked(2).forEach { row ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            row.forEach { metric ->
                                                MetricTile(metric, Modifier.weight(1f))
                                            }
                                            if (row.size == 1) Spacer(Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                        if (report.dataReady) {
                            if (report.findings.isNotEmpty()) {
                                item { SectionCard("Temuan", report.findings) }
                            }
                            if (report.actions.isNotEmpty()) {
                                item { SectionCard("Rekomendasi", report.actions) }
                            }
                            item { NarrativeSection(state, onRequest = viewModel::requestNarrative) }
                        }
                    }

                    if (state.history.isNotEmpty()) {
                        item {
                            Text("Riwayat analisis", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        items(state.history) { item ->
                            Card {
                                Column(Modifier.padding(12.dp)) {
                                    Text(item.headline, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "${if (item.source == "EXTERNAL") "Lokal + narasi AI" else "Analisis lokal"} • ${formatDateTime(item.created_at)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    item.narrative?.takeIf { it.isNotBlank() }?.let {
                                        Spacer(Modifier.height(6.dp))
                                        Text(it, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                    item { Spacer(Modifier.height(8.dp)) }
                }
            }
        }
    }

    if (state.showConsentDialog) {
        AlertDialog(
            onDismissRequest = viewModel::dismissConsentDialog,
            icon = { Icon(Icons.Filled.Lock, contentDescription = null) },
            title = { Text("Izinkan analisis lanjutan?") },
            text = {
                Text(
                    "Untuk analisis lanjutan, aplikasi mengirim ringkasan AGREGAT usaha " +
                        "(jumlah pelanggan, jumlah pelanggan tanpa kontak, jumlah aktivitas 30 hari, status profil) " +
                        "ke layanan AI yang dikelola DooY AppWork.\n\n" +
                        "Nama, nomor telepon, alamat, dan data pelanggan per orang TIDAK dikirim. " +
                        "Anda dapat menolak; analisis lokal tetap berfungsi penuh."
                )
            },
            confirmButton = { TextButton(onClick = viewModel::confirmConsent) { Text("Setuju") } },
            dismissButton = { TextButton(onClick = viewModel::declineConsent) { Text("Tetap lokal") } }
        )
    }
}

@Composable
private fun AiModeBanner(state: AiAssistantUiState) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    if (state.externalConfigured) "AI eksternal aktif • dikelola developer"
                    else "Mode lokal (offline)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
                Text(
                    if (state.externalConfigured)
                        "Analisis lanjutan tersedia. Kunci API diatur DooY AppWork, tidak dapat diubah pengguna."
                    else
                        "Analisis berbasis aturan berjalan tanpa internet. Analisis lanjutan berbasis AI eksternal sedang tidak tersedia.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
    }
}

@Composable
private fun InsightKindSelector(selected: InsightKind, onSelect: (InsightKind) -> Unit) {
    Column {
        Text("Jenis analisis", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            InsightKind.entries.forEach { kind ->
                val active = kind == selected
                Card(
                    onClick = { onSelect(kind) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (active) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = if (active) MaterialTheme.colorScheme.onPrimaryContainer
                            else MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(kind.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyLarge)
                            Text(kind.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (!kind.dataReady) {
                            Text("Segera", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricTile(metric: InsightMetric, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(metric.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(metric.value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            metric.hint?.let {
                Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, lines: List<String>) {
    Card {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            lines.forEach { line ->
                Row(Modifier.padding(vertical = 2.dp)) {
                    Text("•  ", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(line, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
private fun NarrativeSection(state: AiAssistantUiState, onRequest: () -> Unit) {
    Card {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Analisis lanjutan (AI eksternal)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (state.narrativeStatus != NarrativeStatus.LOADING) {
                    IconButton(onClick = onRequest) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Minta analisis lanjutan")
                    }
                }
            }
            when (state.narrativeStatus) {
                NarrativeStatus.LOADING -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Meminta analisis lanjutan…", style = MaterialTheme.typography.bodySmall)
                }
                NarrativeStatus.AVAILABLE -> Column {
                    state.narrative.forEach { line ->
                        Row(Modifier.padding(vertical = 2.dp)) {
                            Text("•  ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Text(line, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Dihasilkan model AI dari fakta lokal di atas. Periksa kembali sebelum mengambil keputusan.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                NarrativeStatus.UNAVAILABLE -> Column {
                    Text(state.narrativeMessage ?: "Analisis lanjutan tidak tersedia.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(4.dp))
                    Text("Analisis lokal di atas tetap valid dan dapat digunakan.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                NarrativeStatus.NONE -> Text(
                    "Belum diminta. Analisis lokal di atas sudah dapat dipakai tanpa internet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            state.savedMessage?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
