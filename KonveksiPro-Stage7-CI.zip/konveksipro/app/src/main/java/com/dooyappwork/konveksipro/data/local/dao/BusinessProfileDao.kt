package com.dooyappwork.konveksipro.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dooyappwork.konveksipro.data.local.entities.BusinessProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BusinessProfileDao {
    @Query("SELECT * FROM business_profile WHERE deleted_at IS NULL LIMIT 1")
    fun observe(): Flow<BusinessProfileEntity?>

    @Query("SELECT * FROM business_profile WHERE deleted_at IS NULL LIMIT 1")
    suspend fun getFirst(): BusinessProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: BusinessProfileEntity)
}
