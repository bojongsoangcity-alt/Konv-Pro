package com.dooyappwork.konveksipro.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dooyappwork.konveksipro.data.local.entities.OrderEntity
import com.dooyappwork.konveksipro.data.local.entities.OrderItemEntity
import com.dooyappwork.konveksipro.data.local.entities.ProductionBatchEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders WHERE deleted_at IS NULL ORDER BY created_at DESC")
    fun observeAll(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :id AND deleted_at IS NULL")
    fun observeById(id: String): Flow<OrderEntity?>

    @Query("SELECT * FROM orders WHERE id = :id AND deleted_at IS NULL")
    suspend fun getById(id: String): OrderEntity?

    @Query("SELECT COUNT(*) FROM orders")
    suspend fun countAllIncludingDeleted(): Int

    // --- agregat dashboard & analisis (penambahan, query lama tidak diubah) ---
    @Query("SELECT COUNT(*) FROM orders WHERE deleted_at IS NULL AND status IN ('BARU','DIPRODUKSI')")
    fun observeActiveCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM orders WHERE deleted_at IS NULL AND status IN ('BARU','DIPRODUKSI') AND due_date IS NOT NULL AND due_date < :now")
    fun observeLateCount(now: Long): Flow<Int>

    @Query("SELECT COALESCE(SUM(total_amount - down_payment - paid_amount), 0) FROM orders WHERE deleted_at IS NULL AND status != 'DIBATALKAN' AND payment_status = 'BELUM_LUNAS'")
    fun observeReceivable(): Flow<Long>

    @Query("SELECT COUNT(*) FROM orders WHERE deleted_at IS NULL AND order_date >= :since")
    suspend fun countCreatedSince(since: Long): Int

    @Query("SELECT COUNT(*) FROM orders WHERE deleted_at IS NULL AND status != 'DIBATALKAN' AND payment_status = 'BELUM_LUNAS'")
    suspend fun countUnpaid(): Int

    @Query("SELECT COUNT(*) FROM orders WHERE deleted_at IS NULL AND status = 'SELESAI'")
    fun observeDoneCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM orders WHERE deleted_at IS NULL AND status = 'BARU'")
    suspend fun countNew(): Int

    @Query("SELECT COALESCE(MAX(order_date), 0) FROM orders WHERE deleted_at IS NULL")
    suspend fun lastOrderAt(): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(order: OrderEntity)

    @Query("UPDATE orders SET status = :status, updated_at = :now, sync_status = 'PENDING' WHERE id = :id AND deleted_at IS NULL")
    suspend fun updateStatus(id: String, status: String, now: Long): Int

    @Query("UPDATE orders SET paid_amount = :paid, payment_status = :payStatus, updated_at = :now, sync_status = 'PENDING' WHERE id = :id")
    suspend fun updatePayment(id: String, paid: Long, payStatus: String, now: Long): Int

    @Query("UPDATE orders SET deleted_at = :now, updated_at = :now, sync_status = 'PENDING' WHERE id = :id")
    suspend fun softDelete(id: String, now: Long): Int

    // --- item pesanan ---
    @Query("SELECT * FROM order_items WHERE order_id = :orderId ORDER BY created_at")
    fun observeItems(orderId: String): Flow<List<OrderItemEntity>>

    @Query("SELECT * FROM order_items WHERE order_id = :orderId ORDER BY created_at")
    suspend fun getItems(orderId: String): List<OrderItemEntity>

    @Insert
    suspend fun insertItems(items: List<OrderItemEntity>)
}

@Dao
interface ProductionDao {
    @Query("SELECT * FROM production_batches WHERE deleted_at IS NULL ORDER BY status, created_at DESC")
    fun observeAll(): Flow<List<ProductionBatchEntity>>

    @Query("SELECT * FROM production_batches WHERE order_id = :orderId AND deleted_at IS NULL")
    suspend fun getByOrder(orderId: String): List<ProductionBatchEntity>

    @Query("SELECT COUNT(*) FROM production_batches WHERE deleted_at IS NULL AND status = :status")
    suspend fun countByStatus(status: String): Int

    @Query("SELECT COUNT(*) FROM production_batches WHERE deleted_at IS NULL AND status = 'SELESAI' AND finished_at >= :since")
    suspend fun countFinishedSince(since: Long): Int

    @Query("SELECT COUNT(*) FROM production_batches WHERE deleted_at IS NULL AND status IN ('ANTRE','PROSES') AND worker_id IS NULL")
    suspend fun countWithoutWorker(): Int

    @Query("SELECT COUNT(*) FROM production_batches WHERE deleted_at IS NULL AND status IN ('ANTRE','PROSES') AND due_date IS NOT NULL AND due_date < :now")
    suspend fun countLate(now: Long): Int

    @Query("SELECT COUNT(*) FROM production_batches WHERE deleted_at IS NULL AND status IN ('ANTRE','PROSES')")
    fun observeActiveCount(): Flow<Int>

    @Insert
    suspend fun insertBatches(batches: List<ProductionBatchEntity>)

    /** ANTRE -> PROSES; hanya dari status ANTRE agar urutan kerja tidak bisa dilompati. */
    @Query("UPDATE production_batches SET status = 'PROSES', started_at = :now, updated_at = :now, sync_status = 'PENDING' WHERE id = :id AND status = 'ANTRE' AND deleted_at IS NULL")
    suspend fun markStarted(id: String, now: Long): Int

    /** PROSES -> SELESAI. */
    @Query("UPDATE production_batches SET status = 'SELESAI', finished_at = :now, updated_at = :now, sync_status = 'PENDING' WHERE id = :id AND status = 'PROSES' AND deleted_at IS NULL")
    suspend fun markFinished(id: String, now: Long): Int

    /** Tetapkan pekerja; batch selesai tidak boleh diubah. */
    @Query("UPDATE production_batches SET worker_id = :workerId, updated_at = :now, sync_status = 'PENDING' WHERE id = :id AND status != 'SELESAI' AND deleted_at IS NULL")
    suspend fun assignWorker(id: String, workerId: String?, now: Long): Int

    /** Tutup seluruh batch belum selesai milik satu pesanan. */
    @Query("UPDATE production_batches SET status = 'SELESAI', finished_at = :now, updated_at = :now, sync_status = 'PENDING' WHERE order_id = :orderId AND status != 'SELESAI' AND deleted_at IS NULL")
    suspend fun finishByOrder(orderId: String, now: Long): Int
}
