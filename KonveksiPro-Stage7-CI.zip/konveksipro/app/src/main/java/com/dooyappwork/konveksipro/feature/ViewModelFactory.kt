package com.dooyappwork.konveksipro.feature

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.dooyappwork.konveksipro.KonveksiProApp
import com.dooyappwork.konveksipro.core.utils.AppContainer

/** Factory umum untuk ViewModel yang membutuhkan AppContainer (tanpa DI framework). */
inline fun <reified VM : ViewModel> containerFactory(
    crossinline create: (AppContainer) -> VM
): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        create(KonveksiProApp.instance.container) as T
}
