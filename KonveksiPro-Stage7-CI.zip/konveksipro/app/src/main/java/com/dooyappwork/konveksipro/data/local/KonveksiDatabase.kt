package com.dooyappwork.konveksipro.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.dooyappwork.konveksipro.ai.data.AiInsightDao
import com.dooyappwork.konveksipro.ai.data.AiInsightEntity
import com.dooyappwork.konveksipro.data.local.dao.AuditLogDao
import com.dooyappwork.konveksipro.data.local.dao.BusinessProfileDao
import com.dooyappwork.konveksipro.data.local.dao.MaterialDao
import com.dooyappwork.konveksipro.data.local.dao.ProductDao
import com.dooyappwork.konveksipro.data.local.dao.SupplierDao
import com.dooyappwork.konveksipro.data.local.dao.WorkerDao
import com.dooyappwork.konveksipro.data.local.dao.CustomerDao
import com.dooyappwork.konveksipro.data.local.dao.OrderDao
import com.dooyappwork.konveksipro.data.local.dao.ProductionDao
import com.dooyappwork.konveksipro.data.local.dao.RecipeDao
import com.dooyappwork.konveksipro.data.local.entities.AuditLogEntity
import com.dooyappwork.konveksipro.data.local.entities.BusinessProfileEntity
import com.dooyappwork.konveksipro.data.local.entities.CustomerEntity
import com.dooyappwork.konveksipro.data.local.entities.MaterialEntity
import com.dooyappwork.konveksipro.data.local.entities.MaterialMovementEntity
import com.dooyappwork.konveksipro.data.local.entities.OrderEntity
import com.dooyappwork.konveksipro.data.local.entities.OrderItemEntity
import com.dooyappwork.konveksipro.data.local.entities.ProductEntity
import com.dooyappwork.konveksipro.data.local.entities.ProductionBatchEntity
import com.dooyappwork.konveksipro.data.local.entities.RecipeItemEntity
import com.dooyappwork.konveksipro.data.local.entities.SupplierEntity
import com.dooyappwork.konveksipro.data.local.entities.WorkerEntity

/**
 * Database KonveksiPro.
 * v1 (Stage 1): business_profile, customers, audit_logs
 * v2 (Stage 2): + ai_insights (MIGRATION_1_2, hanya menambah tabel)
 * v3 (Tahap 3): + orders, order_items, production_batches (MIGRATION_2_3, hanya menambah tabel)
 * v4 (Tahap 4): + products, recipe_items, materials, suppliers, workers (MIGRATION_3_4, hanya menambah tabel)
 * Tabel & data lama tidak pernah disentuh. Tidak ada destructive fallback.
 * exportSchema dimatikan sejak v1; skema didokumentasikan di docs/SCHEMA.md.
 */
@Database(
    entities = [
        BusinessProfileEntity::class,
        CustomerEntity::class,
        AuditLogEntity::class,
        AiInsightEntity::class,
        OrderEntity::class,
        OrderItemEntity::class,
        ProductionBatchEntity::class,
        ProductEntity::class,
        RecipeItemEntity::class,
        MaterialEntity::class,
        SupplierEntity::class,
        WorkerEntity::class,
        MaterialMovementEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class KonveksiDatabase : RoomDatabase() {
    abstract fun businessProfileDao(): BusinessProfileDao
    abstract fun customerDao(): CustomerDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun aiInsightDao(): AiInsightDao
    abstract fun orderDao(): OrderDao
    abstract fun productionDao(): ProductionDao
    abstract fun productDao(): ProductDao
    abstract fun recipeDao(): RecipeDao
    abstract fun materialDao(): MaterialDao
    abstract fun supplierDao(): SupplierDao
    abstract fun workerDao(): WorkerDao
    abstract fun materialMovementDao(): com.dooyappwork.konveksipro.data.local.dao.MaterialMovementDao

    companion object {
        const val DB_NAME = "konveksipro.db"

        /** v1 -> v2: hanya menambah tabel ai_insights. Data lama utuh. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `ai_insights` (" +
                        "`id` TEXT NOT NULL, `kind` TEXT NOT NULL, `source` TEXT NOT NULL, " +
                        "`provider_id` TEXT, `headline` TEXT NOT NULL, `narrative` TEXT, " +
                        "`metrics_json` TEXT NOT NULL, `tokens` INTEGER NOT NULL, " +
                        "`created_at` INTEGER NOT NULL, `device_id` TEXT NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_ai_insights_created_at` ON `ai_insights` (`created_at`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_ai_insights_kind` ON `ai_insights` (`kind`)")
            }
        }

        /** v2 -> v3 (Tahap 3): hanya menambah tabel pesanan & produksi. Tidak ada DROP. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `orders` (" +
                        "`id` TEXT NOT NULL, `order_code` TEXT NOT NULL, `customer_id` TEXT, " +
                        "`customer_name` TEXT NOT NULL, `status` TEXT NOT NULL, " +
                        "`order_date` INTEGER NOT NULL, `due_date` INTEGER, " +
                        "`total_amount` INTEGER NOT NULL, `down_payment` INTEGER NOT NULL, " +
                        "`paid_amount` INTEGER NOT NULL, `payment_status` TEXT NOT NULL, " +
                        "`notes` TEXT, `created_at` INTEGER NOT NULL, `updated_at` INTEGER NOT NULL, " +
                        "`deleted_at` INTEGER, `device_id` TEXT NOT NULL, `sync_status` TEXT NOT NULL, " +
                        "PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_orders_order_code` ON `orders` (`order_code`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_orders_customer_id` ON `orders` (`customer_id`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_orders_status` ON `orders` (`status`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_orders_due_date` ON `orders` (`due_date`)")

                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `order_items` (" +
                        "`id` TEXT NOT NULL, `order_id` TEXT NOT NULL, `product_name` TEXT NOT NULL, " +
                        "`qty` INTEGER NOT NULL, `unit_price` INTEGER NOT NULL, `note` TEXT, " +
                        "`created_at` INTEGER NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_order_items_order_id` ON `order_items` (`order_id`)")

                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `production_batches` (" +
                        "`id` TEXT NOT NULL, `order_id` TEXT, `product_id` TEXT, " +
                        "`product_name` TEXT NOT NULL, `qty` INTEGER NOT NULL, `status` TEXT NOT NULL, " +
                        "`worker_id` TEXT, `due_date` INTEGER, `started_at` INTEGER, " +
                        "`finished_at` INTEGER, `notes` TEXT, `created_at` INTEGER NOT NULL, " +
                        "`updated_at` INTEGER NOT NULL, `deleted_at` INTEGER, " +
                        "`device_id` TEXT NOT NULL, `sync_status` TEXT NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_production_batches_order_id` ON `production_batches` (`order_id`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_production_batches_status` ON `production_batches` (`status`)")
            }
        }

        /** v3 -> v4 (Tahap 4): hanya menambah tabel katalog & persediaan. Tidak ada DROP. */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `products` (" +
                        "`id` TEXT NOT NULL, `name` TEXT NOT NULL, `category` TEXT, " +
                        "`sell_price` INTEGER NOT NULL, `is_active` INTEGER NOT NULL, `notes` TEXT, " +
                        "`created_at` INTEGER NOT NULL, `updated_at` INTEGER NOT NULL, " +
                        "`deleted_at` INTEGER, `device_id` TEXT NOT NULL, `sync_status` TEXT NOT NULL, " +
                        "PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_products_name` ON `products` (`name`)")

                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `recipe_items` (" +
                        "`id` TEXT NOT NULL, `product_id` TEXT NOT NULL, `material_id` TEXT NOT NULL, " +
                        "`qty_per_unit` REAL NOT NULL, `created_at` INTEGER NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_recipe_items_product_id` ON `recipe_items` (`product_id`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_recipe_items_material_id` ON `recipe_items` (`material_id`)")

                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `materials` (" +
                        "`id` TEXT NOT NULL, `name` TEXT NOT NULL, `unit` TEXT NOT NULL, " +
                        "`stock` REAL NOT NULL, `min_stock` REAL NOT NULL, `buy_price` INTEGER NOT NULL, " +
                        "`supplier_id` TEXT, `notes` TEXT, `created_at` INTEGER NOT NULL, " +
                        "`updated_at` INTEGER NOT NULL, `deleted_at` INTEGER, " +
                        "`device_id` TEXT NOT NULL, `sync_status` TEXT NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_materials_name` ON `materials` (`name`)")

                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `suppliers` (" +
                        "`id` TEXT NOT NULL, `name` TEXT NOT NULL, `phone` TEXT, `address` TEXT, " +
                        "`notes` TEXT, `created_at` INTEGER NOT NULL, `updated_at` INTEGER NOT NULL, " +
                        "`deleted_at` INTEGER, `device_id` TEXT NOT NULL, `sync_status` TEXT NOT NULL, " +
                        "PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_suppliers_name` ON `suppliers` (`name`)")

                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `workers` (" +
                        "`id` TEXT NOT NULL, `name` TEXT NOT NULL, `role` TEXT, `phone` TEXT, " +
                        "`notes` TEXT, `created_at` INTEGER NOT NULL, `updated_at` INTEGER NOT NULL, " +
                        "`deleted_at` INTEGER, `device_id` TEXT NOT NULL, `sync_status` TEXT NOT NULL, " +
                        "PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_workers_name` ON `workers` (`name`)")
            }
        }

        /** v4 -> v5 (Tahap 7): buku besar stok + kolom upah/overhead produk. Tanpa DROP. */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `material_movements` (" +
                        "`id` TEXT NOT NULL, `material_id` TEXT NOT NULL, `qty_delta` REAL NOT NULL, " +
                        "`reason` TEXT NOT NULL, `note` TEXT, `batch_id` TEXT, `order_id` TEXT, " +
                        "`created_at` INTEGER NOT NULL, `device_id` TEXT NOT NULL, " +
                        "`sync_status` TEXT NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_material_movements_material_id` ON `material_movements` (`material_id`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_material_movements_created_at` ON `material_movements` (`created_at`)")
                // ALTER TABLE ADD COLUMN dengan default: baris lama dapat 0 (HPP material-only).
                db.execSQL("ALTER TABLE `products` ADD COLUMN `labor_cost` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `products` ADD COLUMN `overhead_cost` INTEGER NOT NULL DEFAULT 0")
            }
        }
    }
}
