package com.dooyappwork.konveksipro.feature.dev

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.feature.containerFactory

data class DiagnosticsUiState(
    val statusLines: List<String> = emptyList(),
    val providerLines: List<String> = emptyList(),
    val exclusionLines: List<String> = emptyList(),
    val quotaLine: String = ""
)

class AiDiagnosticsViewModel(private val container: AppContainer) : ViewModel() {

    val state: DiagnosticsUiState = buildState()

    private fun buildState(): DiagnosticsUiState {
        val config = container.aiConfig
        val chain = container.aiSelector.chain(config)

        val status = listOf(
            "versi: 0.6.1-stage7",
            "AI eksternal: ${if (config.externalEnabled) "aktif" else "nonaktif"}",
            "provider siap: ${config.usableProviders().size}",
            "adapter terdaftar: ${container.aiRegistry.registeredTypes().joinToString(",")}",
            "batas permintaan/hari: ${config.limits.maxRequestsPerDay}",
            "batas token/hari: ${config.limits.maxTokensPerDay}",
            "anggaran biaya/hari: ${config.limits.maxCostUsdPerDay} USD"
        )

        val providers = chain.mapIndexed { index, p ->
            "${index + 1}. ${p.id} • tipe=${p.type} • model=${p.model} • key=${p.keyFingerprint()}"
        }

        return DiagnosticsUiState(
            statusLines = status,
            providerLines = providers.ifEmpty { listOf("tidak ada provider yang akan dicoba") },
            exclusionLines = container.aiSelector.excludedReasons(config).ifEmpty { listOf("tidak ada") },
            quotaLine = container.aiQuotaManager.snapshot()
        )
    }

    companion object {
        fun factory(): ViewModelProvider.Factory = containerFactory { AiDiagnosticsViewModel(it) }
    }
}
