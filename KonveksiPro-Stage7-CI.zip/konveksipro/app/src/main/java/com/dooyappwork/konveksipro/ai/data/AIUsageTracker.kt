package com.dooyappwork.konveksipro.ai.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Agregat pemakaian satu hari. Tidak memuat konten percakapan maupun kredensial. */
data class UsageDay(
    val day: String,
    val requests: Int = 0,
    val tokensIn: Int = 0,
    val tokensOut: Int = 0,
    val costUsd: Double = 0.0,
    val failures: Int = 0
) {
    val tokens: Int get() = tokensIn + tokensOut
}

/**
 * Pencatat penggunaan: jumlah permintaan, token, estimasi biaya, kegagalan.
 * Sengaja TIDAK menyimpan prompt atau jawaban AI di sini.
 */
class AIUsageTracker(
    private val store: KeyValueStore,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    fun dayKey(epochMillis: Long = clock()): String = dateFormat.format(Date(epochMillis))

    fun today(): UsageDay = forDay(dayKey())

    fun forDay(day: String): UsageDay {
        fun int(suffix: String): Int = store.getString("usage.$day.$suffix")?.toIntOrNull() ?: 0
        return UsageDay(
            day = day,
            requests = int("requests"),
            tokensIn = int("tokens_in"),
            tokensOut = int("tokens_out"),
            costUsd = store.getString("usage.$day.cost")?.toDoubleOrNull() ?: 0.0,
            failures = int("failures")
        )
    }

    fun recordSuccess(providerId: String, tokensIn: Int, tokensOut: Int, costUsd: Double) {
        val day = dayKey()
        bump("usage.$day.requests", 1)
        bump("usage.$day.tokens_in", tokensIn)
        bump("usage.$day.tokens_out", tokensOut)
        bump("usage.$day.p.$providerId.requests", 1)
        val currentCost = store.getString("usage.$day.cost")?.toDoubleOrNull() ?: 0.0
        store.putString("usage.$day.cost", (currentCost + costUsd).toString())
    }

    fun recordFailure(providerId: String) {
        val day = dayKey()
        bump("usage.$day.failures", 1)
        bump("usage.$day.p.$providerId.failures", 1)
    }

    /** Estimasi biaya berdasarkan harga per 1k token milik provider (jika developer mengisi). */
    fun estimateCostUsd(tokensIn: Int, tokensOut: Int, priceInPer1k: Double?, priceOutPer1k: Double?): Double {
        val inCost = (tokensIn / 1000.0) * (priceInPer1k ?: 0.0)
        val outCost = (tokensOut / 1000.0) * (priceOutPer1k ?: 0.0)
        return inCost + outCost
    }

    fun recentDays(count: Int = 7): List<UsageDay> {
        val now = clock()
        return (0 until count).map { offset ->
            val day = dayKey(now - offset * 86_400_000L)
            forDay(day)
        }
    }

    private fun bump(key: String, delta: Int) {
        val current = store.getString(key)?.toIntOrNull() ?: 0
        store.putString(key, (current + delta).toString())
    }
}
