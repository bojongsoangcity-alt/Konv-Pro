package com.dooyappwork.konveksipro.ai.provider

import com.dooyappwork.konveksipro.ai.config.AIProviderConfig
import com.dooyappwork.konveksipro.ai.config.ProviderType
import com.dooyappwork.konveksipro.ai.model.AIRequest
import com.dooyappwork.konveksipro.ai.model.FailureKind
import com.dooyappwork.konveksipro.ai.transport.JsonTransport
import com.dooyappwork.konveksipro.ai.util.JsonParser
import com.dooyappwork.konveksipro.ai.util.JsonWriter
import com.dooyappwork.konveksipro.ai.util.asStringOrNull
import com.dooyappwork.konveksipro.ai.util.path

/**
 * Adapter generik untuk endpoint yang formatnya mendekati kontrak sederhana:
 * request {"model","prompt","maxTokens"}, respons {"text":"..."} atau {"output_text":"..."}.
 *
 * PENTING: adapter ini TIDAK dianggap terverifikasi. `ProviderRegistry` hanya
 * mengaktifkannya jika developer menandai provider `verified=true` DAN sudah
 * menjalankan uji nyata (Bag. 3: jangan aktifkan provider yang belum diuji).
 */
class CustomProviderAdapter(transport: JsonTransport) : BaseHttpProvider(transport) {

    override val type = ProviderType.CUSTOM

    override fun buildRequest(config: AIProviderConfig, request: AIRequest): PreparedRequest {
        val url = config.baseUrl.trimEnd('/') + (config.path?.let { if (it.startsWith("/")) it else "/$it" } ?: "")
        val body = JsonWriter.obj(
            "model" to config.model,
            "prompt" to request.prompt,
            "maxTokens" to request.maxOutputTokens
        )
        val headers = mapOf(config.authHeader to (config.authPrefix + (config.apiKey ?: "")))
        return PreparedRequest(url, headers, body)
    }

    override fun parseResponse(config: AIProviderConfig, body: String): ParsedResponse? {
        val root = JsonParser.parseOrNull(body) ?: return null
        val text = root.path("text").asStringOrNull()
            ?: root.path("output_text").asStringOrNull()
            ?: root.path("result", "text").asStringOrNull()
            ?: return null
        if (text.isBlank()) return null
        return ParsedResponse(
            text = text,
            inputTokens = root.path("usage", "input_tokens").asStringOrNull()?.toIntOrNull() ?: 0,
            outputTokens = root.path("usage", "output_tokens").asStringOrNull()?.toIntOrNull() ?: 0
        )
    }

    override fun classifyHttpError(status: Int, body: String): FailureKind = FailureKind.fromHttpCode(status)

    override fun errorDetail(body: String?): String? {
        val root = JsonParser.parseOrNull(body ?: "") ?: return null
        return root.path("error").asStringOrNull() ?: root.path("error", "message").asStringOrNull()
    }
}
