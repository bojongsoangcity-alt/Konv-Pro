package com.dooyappwork.konveksipro.ai.data

/** Implementasi in-memory: dipakai unit test dan pratinjau tanpa Android. */
class InMemoryKeyValueStore(initial: Map<String, String> = emptyMap()) : KeyValueStore {
    private val map = HashMap<String, String>(initial)
    override fun getString(key: String): String? = map[key]
    override fun putString(key: String, value: String) { map[key] = value }
    override fun remove(key: String) { map.remove(key) }
    fun snapshot(): Map<String, String> = map.toMap()
}
