package com.dooyappwork.konveksipro.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Buku besar mutasi stok material (Tahap 7, migrasi v4 -> v5).
 * Setiap perubahan stok (masuk/keluar) kini tercatat sebagai baris ledger -
 *materials.stock tetap sumber kebenaran, tabel ini jejak auditnya yang bisa ditampilkan.
 * Tidak mengubah tabel lama sama sekali.
 */
@Entity(
    tableName = "material_movements",
    indices = [Index("material_id"), Index("created_at")]
)
data class MaterialMovementEntity(
    @PrimaryKey val id: String,              // UUID
    val material_id: String,
    val qty_delta: Double,                   // positif = masuk, negatif = keluar
    val reason: String,                      // MANUAL / PRODUCTION / KOREKSI
    val note: String?,
    val batch_id: String?,                   // referensi batch produksi (jika ada)
    val order_id: String?,                   // referensi pesanan (jika ada)
    val created_at: Long,
    val device_id: String,
    val sync_status: String = "PENDING"
)
