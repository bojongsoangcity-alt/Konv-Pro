package com.dooyappwork.konveksipro.feature.customers

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dooyappwork.konveksipro.core.ui.KonveksiTopBar
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.feature.containerFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class CustomerFormState(
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val notes: String = "",
    val saving: Boolean = false,
    val validationError: String? = null
)

class CustomerFormViewModel(private val container: AppContainer) : ViewModel() {
    private val _state = MutableStateFlow(CustomerFormState())
    val state: StateFlow<CustomerFormState> = _state

    fun update(transform: (CustomerFormState) -> CustomerFormState) {
        _state.value = transform(_state.value).copy(validationError = null)
    }

    fun save(onSuccess: () -> Unit) {
        val s = _state.value
        if (s.name.isBlank()) {
            _state.value = s.copy(validationError = "Nama pelanggan wajib diisi")
            return
        }
        _state.value = s.copy(saving = true)
        viewModelScope.launch {
            try {
                container.customerRepository.add(
                    name = s.name, phone = s.phone, email = s.email,
                    address = s.address, notes = s.notes
                )
                onSuccess()
            } catch (e: Exception) {
                _state.value = s.copy(saving = false, validationError = e.message)
            }
        }
    }
}

@Composable
fun CustomerFormScreen(
    customerId: String?,
    onDone: () -> Unit,
    viewModel: CustomerFormViewModel = viewModel(factory = containerFactory { CustomerFormViewModel(it) })
) {
    val state by viewModel.state.collectAsState()

    Scaffold(topBar = { KonveksiTopBar("Tambah Pelanggan", "Data dasar - dapat diedit kapan saja", onBack = onDone) }) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = state.name,
                onValueChange = { v -> viewModel.update { it.copy(name = v) } },
                label = { Text("Nama pelanggan *") },
                isError = state.validationError != null && state.name.isBlank(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = state.phone,
                onValueChange = { v -> viewModel.update { it.copy(phone = v) } },
                label = { Text("Nomor telepon") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = state.email,
                onValueChange = { v -> viewModel.update { it.copy(email = v) } },
                label = { Text("Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = state.address,
                onValueChange = { v -> viewModel.update { it.copy(address = v) } },
                label = { Text("Alamat") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = state.notes,
                onValueChange = { v -> viewModel.update { it.copy(notes = v) } },
                label = { Text("Catatan") },
                modifier = Modifier.fillMaxWidth()
            )

            state.validationError?.let { err ->
                Spacer(Modifier.height(8.dp))
                Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { viewModel.save(onDone) },
                enabled = !state.saving,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (state.saving) "Menyimpan..." else "Simpan Pelanggan")
            }
        }
    }
}
