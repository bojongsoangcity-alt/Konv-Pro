package com.dooyappwork.konveksipro.ai.model

/** Satu angka yang benar-benar dihitung dari database lokal. */
data class InsightMetric(val label: String, val value: String, val hint: String? = null)

/**
 * Hasil analisis LOKAL berbasis aturan. Selalu tersedia tanpa internet/API.
 * Label sumber (local/external) wajib ditampilkan agar pengguna tidak salah paham
 * bahwa ini generative AI.
 */
data class InsightReport(
    val kind: InsightKind,
    val headline: String,
    val metrics: List<InsightMetric> = emptyList(),
    val findings: List<String> = emptyList(),
    val actions: List<String> = emptyList(),
    val score: Int? = null,
    val dataReady: Boolean = true,
    val note: String? = null
)
