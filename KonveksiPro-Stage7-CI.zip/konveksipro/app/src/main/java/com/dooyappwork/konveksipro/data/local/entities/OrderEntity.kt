package com.dooyappwork.konveksipro.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.dooyappwork.konveksipro.domain.model.Order

/**
 * Pesanan (Tahap 3) - dibuat lewat MIGRATION v3, tabel lama tidak disentuh.
 * Uang = Long rupiah. Soft delete dipakai agar histori produksi tetap konsisten.
 */
@Entity(
    tableName = "orders",
    indices = [Index("order_code"), Index("customer_id"), Index("status"), Index("due_date")]
)
data class OrderEntity(
    @PrimaryKey val id: String,              // UUID
    val order_code: String,                  // ORD-00001 (berurutan, unik per instalasi)
    val customer_id: String?,                // boleh null untuk pembeli walk-in
    val customer_name: String,               // snapshot nama saat order dibuat
    val status: String,                      // BARU / DIPRODUKSI / SELESAI / DIBATALKAN
    val order_date: Long,
    val due_date: Long?,                     // deadline selesai
    val total_amount: Long,                  // hasil kalkulasi OrderCalculator
    val down_payment: Long,                  // uang muka (DP)
    val paid_amount: Long = 0,               // pelunasan
    val payment_status: String,              // BELUM_LUNAS / LUNAS
    val notes: String?,
    val created_at: Long,
    val updated_at: Long,
    val deleted_at: Long? = null,
    val device_id: String,
    val sync_status: String = "PENDING"
)

fun OrderEntity.toDomain() = Order(
    id = id, orderCode = order_code, customerId = customer_id, customerName = customer_name,
    status = status, orderDate = order_date, dueDate = due_date, totalAmount = total_amount,
    downPayment = down_payment, paidAmount = paid_amount, paymentStatus = payment_status,
    notes = notes, createdAt = created_at, updatedAt = updated_at
)
