package com.dooyappwork.konveksipro.feature.orders

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dooyappwork.konveksipro.core.ui.KonveksiTopBar
import com.dooyappwork.konveksipro.core.ui.LoadingState
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.core.utils.formatDateTime
import com.dooyappwork.konveksipro.core.utils.formatRupiah
import com.dooyappwork.konveksipro.data.local.entities.toDomain
import com.dooyappwork.konveksipro.domain.logic.OrderCalculator
import com.dooyappwork.konveksipro.domain.model.Order
import com.dooyappwork.konveksipro.domain.model.OrderItem
import com.dooyappwork.konveksipro.domain.model.OrderStatus
import com.dooyappwork.konveksipro.domain.model.PaymentStatus
import com.dooyappwork.konveksipro.feature.containerFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OrderDetailState(
    val order: Order? = null,
    val items: List<OrderItem> = emptyList(),
    val busy: Boolean = false,
    val message: String? = null,
    val finished: Boolean = false
)

class OrderDetailViewModel(private val container: AppContainer, private val orderId: String) : ViewModel() {
    private val _state = MutableStateFlow(OrderDetailState())
    val state: StateFlow<OrderDetailState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            container.orderRepository.observeById(orderId).collect { o ->
                _state.update { it.copy(order = o) }
            }
        }
        viewModelScope.launch {
            container.orderRepository.observeItems(orderId).collect { rows ->
                _state.update { it.copy(items = rows.map { e -> e.toDomain() }) }
            }
        }
    }

    fun setStatus(to: String) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true, message = null) }
            try {
                container.orderRepository.updateStatus(orderId, to)
                if (to == OrderStatus.DIPRODUKSI) {
                    _state.update { it.copy(busy = false) }
                }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, message = e.message) }
            }
        }
    }

    /** Naikkan ke DIPRODUKSI lalu tutup seluruh batch (tombol Selesaikan Produksi). */
    fun finishProduction() {
        viewModelScope.launch {
            _state.update { it.copy(busy = true, message = null) }
            try {
                val order = _state.value.order
                if (order != null && order.status == OrderStatus.BARU) {
                    container.orderRepository.updateStatus(orderId, OrderStatus.DIPRODUKSI)
                }
                container.productionRepository.finishOrder(orderId)
                _state.update { it.copy(busy = false, finished = true) }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, message = e.message) }
            }
        }
    }

    fun pay(amountText: String) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true, message = null) }
            try {
                container.orderRepository.settlePayment(orderId, amountText.toLongOrNull() ?: 0)
                _state.update { it.copy(busy = false, message = "Pembayaran tercatat") }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, message = e.message) }
            }
        }
    }

    fun deleteOrder() {
        viewModelScope.launch {
            _state.update { it.copy(busy = true, message = null) }
            try {
                container.orderRepository.softDelete(orderId)
                _state.update { it.copy(busy = false, finished = true) }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, message = e.message) }
            }
        }
    }

    companion object {
        fun factory(orderId: String): androidx.lifecycle.ViewModelProvider.Factory =
            containerFactory { OrderDetailViewModel(it, orderId) }
    }
}

@Composable
fun OrderDetailScreen(
    orderId: String,
    onDone: () -> Unit,
    viewModel: OrderDetailViewModel = viewModel(factory = OrderDetailViewModel.factory(orderId))
) {
    val state by viewModel.state.collectAsState()
    var showPayDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    LaunchedEffect(state.finished) { if (state.finished) onDone() }

    if (showPayDialog) {
        var amount by remember { mutableStateOf("") }
        val order = state.order
        val receivable = if (order == null) 0L else OrderCalculator.receivable(
            order.totalAmount, order.downPayment, order.paidAmount
        )
        AlertDialog(
            onDismissRequest = { showPayDialog = false },
            title = { Text("Catat pembayaran") },
            text = {
                Column {
                    Text("Sisa tagihan: " + formatRupiah(receivable))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it.filter { c -> c.isDigit() } },
                        label = { Text("Jumlah (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.pay(amount)
                    showPayDialog = false
                }) { Text("Simpan") }
            },
            dismissButton = {
                TextButton(onClick = { showPayDialog = false }) { Text("Batal") }
            }
        )
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Hapus pesanan?") },
            text = { Text("Pesanan diarsipkan (soft delete). Riwayat produksi tetap konsisten.") },
            confirmButton = {
                TextButton(onClick = { viewModel.deleteOrder(); showDeleteDialog = false }) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = false }) { Text("Batal") } }
        )
    }

    val order = state.order
    Scaffold(topBar = { KonveksiTopBar(order?.orderCode ?: "Detail", "Detail pesanan", onDone) }) { padding ->
        if (order == null) {
            LoadingState(Modifier.padding(padding))
            return@Scaffold
        }
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(order.customerName, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                StatusChip(order.status)
            }
            Text(
                "Tanggal: " + formatDateTime(order.orderDate) +
                    (order.dueDate?.let { "\nTenggat: " + formatDateTime(it) } ?: ""),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(12.dp))
            Card {
                Column(Modifier.padding(14.dp)) {
                    state.items.forEach { item ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text(
                                "${item.productName} x${item.qty}",
                                Modifier.weight(1f),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(formatRupiah(item.qty * item.unitPrice), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    HorizontalDivider()
                    KeyValue("Total", formatRupiah(order.totalAmount), bold = true)
                    KeyValue("DP", formatRupiah(order.downPayment))
                    KeyValue("Dibayar", formatRupiah(order.paidAmount))
                    KeyValue("Sisa", formatRupiah(OrderCalculator.receivable(order.totalAmount, order.downPayment, order.paidAmount)), bold = true)
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text("Status bayar", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        StatusChip(order.paymentStatus)
                    }
                }
            }

            state.message?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { viewModel.finishProduction() },
                enabled = !state.busy && (order.status == OrderStatus.BARU || order.status == OrderStatus.DIPRODUKSI),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    when (order.status) {
                        OrderStatus.BARU -> "Proses ke Produksi"
                        OrderStatus.DIPRODUKSI -> "Selesaikan Produksi"
                        else -> "Produksi selesai"
                    }
                )
            }
            if (order.status != OrderStatus.SELESAI && order.status != OrderStatus.DIBATALKAN) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { viewModel.setStatus(OrderStatus.DIBATALKAN) },
                    enabled = !state.busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Batalkan Pesanan") }
            }
            if (order.paymentStatus != PaymentStatus.LUNAS && order.status != OrderStatus.DIBATALKAN) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { showPayDialog = true },
                    enabled = !state.busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Catat Pembayaran") }
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { showDeleteDialog = true }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) {
                Text("Hapus Pesanan", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun KeyValue(label: String, value: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        )
    }
}
