package com.dooyappwork.konveksipro.core.navigation

/** Rute navigasi terpusat agar tidak ada string rute tersebar. */
object Routes {
    const val DASHBOARD = "dashboard"
    const val MASTER = "master"
    const val CUSTOMERS = "customers"
    const val AI_ASSISTANT = "ai_assistant"
    const val SETTINGS = "settings"
    const val AI_DIAGNOSTICS = "ai_diagnostics"

    // Tahap 3: pesanan & produksi
    const val ORDERS = "orders"
    const val ORDER_FORM = "order_form"
    const val ORDER_DETAIL = "order_detail/{orderId}"
    const val ARG_ORDER_ID = "orderId"
    const val PRODUCTION = "production"

    // Tahap 4: katalog & persediaan
    const val PRODUCTS = "products"
    const val MATERIALS = "materials"
    const val WORKERS = "workers"
    // Tahap 7: supplier
    const val SUPPLIERS = "suppliers"
    const val BUSINESS_PROFILE = "business_profile"

    const val ARG_CUSTOMER_ID = "customerId"
    const val CUSTOMER_FORM = "customer_form?customerId={customerId}"

    fun orderDetail(id: String) = "order_detail/$id"
}
