package com.dooyappwork.konveksipro.domain.model

data class BusinessProfile(
    val id: String,               // Business ID (UUID)
    val businessName: String,
    val ownerName: String?,
    val phone: String?,
    val address: String?,
    val isConfigured: Boolean
)
