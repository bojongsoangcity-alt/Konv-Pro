package com.dooyappwork.konveksipro.ai.model

/**
 * Klasifikasi kegagalan permintaan AI. Dipakai untuk fallback, quota, dan UI.
 * Pesan pengguna TIDAK memuat detail teknis/kredensial.
 */
enum class FailureKind(val retryable: Boolean, val userMessage: String) {
    NOT_CONFIGURED(false, "Layanan AI eksternal belum dikonfigurasi developer."),
    DISABLED(false, "Layanan AI eksternal sedang dinonaktifkan."),
    NO_NETWORK(true, "Tidak ada koneksi internet. Analisis lokal tetap berjalan."),
    INVALID_KEY(false, "Kredensial layanan AI ditolak penyedia. Hubungi developer DooY AppWork."),
    RATE_LIMIT(true, "Permintaan terlalu sering (rate limit). Coba lagi beberapa saat."),
    QUOTA_EXHAUSTED(false, "Kuota layanan AI habis. Analisis lokal tetap tersedia."),
    SERVER_ERROR(true, "Server layanan AI sedang bermasalah."),
    TIMEOUT(true, "Permintaan ke layanan AI melebihi batas waktu."),
    BAD_RESPONSE(false, "Respons layanan AI tidak dapat dibaca."),
    BLOCKED_BY_FILTER(false, "Permintaan dihentikan filter data sensitif."),
    CANCELLED(false, "Permintaan dibatalkan.");

    companion object {
        /** Pemetaan HTTP generik; adapter menyempurnakan (mis. 403 kuota vs kunci). */
        fun fromHttpCode(code: Int): FailureKind = when (code) {
            400, 404, 422 -> BAD_RESPONSE
            401, 403 -> INVALID_KEY
            402 -> QUOTA_EXHAUSTED
            408 -> TIMEOUT
            429 -> RATE_LIMIT
            in 500..599 -> SERVER_ERROR
            else -> SERVER_ERROR
        }
    }
}
