package com.dooyappwork.konveksipro.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.dooyappwork.konveksipro.data.local.entities.AuditLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AuditLogDao {
    @Insert
    suspend fun insert(log: AuditLogEntity)

    @Query("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<AuditLogEntity>>

    // --- Stage 2: hitungan aktivitas untuk analisis lokal ---
    @Query("SELECT COUNT(*) FROM audit_logs WHERE created_at >= :since")
    suspend fun countSince(since: Long): Int
}
