package com.dooyappwork.konveksipro.ai.security

/**
 * Sensor kredensial pada teks yang akan dicatat atau ditampilkan.
 * Wajib dipakai sebelum menulis log, safeDetail, dan pesan error.
 */
object SecretRedactor {

    private val patterns: List<Pair<Regex, String>> = listOf(
        Regex("AIza[0-9A-Za-z_\\-]{20,}") to "[REDACTED_KEY]",
        Regex("sk-[A-Za-z0-9_\\-]{16,}") to "[REDACTED_KEY]",
        Regex("(?i)bearer\\s+[A-Za-z0-9._\\-]{10,}") to "Bearer [REDACTED]",
        Regex("(?i)(x-goog-api-key|api[_-]?key|authorization)\\s*[:=]\\s*[^\\s,;\"']+") to "$1=[REDACTED]",
        Regex("(?i)(token|secret|passwd|password)\\s*[:=]\\s*[^\\s,;\"']+") to "$1=[REDACTED]"
    )

    fun redact(input: String?): String {
        if (input.isNullOrEmpty()) return ""
        var out: String = input
        patterns.forEach { (regex, replacement) -> out = regex.replace(out, replacement) }
        return out
    }

    /** Detail teknis dibatasi panjangnya agar tidak membanjiri log. */
    fun safeDetail(input: String?, maxLength: Int = 200): String =
        redact(input).replace('\n', ' ').trim().take(maxLength)
}
