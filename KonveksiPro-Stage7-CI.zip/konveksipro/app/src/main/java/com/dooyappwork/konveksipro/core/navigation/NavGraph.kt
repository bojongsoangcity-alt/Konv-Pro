package com.dooyappwork.konveksipro.core.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.dooyappwork.konveksipro.BuildConfig
import com.dooyappwork.konveksipro.feature.ai.AiAssistantScreen
import com.dooyappwork.konveksipro.feature.catalog.BusinessProfileScreen
import com.dooyappwork.konveksipro.feature.catalog.MaterialsScreen
import com.dooyappwork.konveksipro.feature.catalog.ProductsScreen
import com.dooyappwork.konveksipro.feature.catalog.SuppliersScreen
import com.dooyappwork.konveksipro.feature.catalog.WorkersScreen
import com.dooyappwork.konveksipro.feature.customers.CustomerFormScreen
import com.dooyappwork.konveksipro.feature.customers.CustomersScreen
import com.dooyappwork.konveksipro.feature.dashboard.DashboardScreen
import com.dooyappwork.konveksipro.feature.dev.AiDiagnosticsScreen
import com.dooyappwork.konveksipro.feature.dev.AiDiagnosticsViewModel
import com.dooyappwork.konveksipro.feature.master.MasterDataScreen
import com.dooyappwork.konveksipro.feature.orders.OrderFormScreen
import com.dooyappwork.konveksipro.feature.orders.OrderDetailScreen
import com.dooyappwork.konveksipro.feature.orders.OrdersScreen
import com.dooyappwork.konveksipro.feature.production.ProductionScreen
import com.dooyappwork.konveksipro.feature.settings.SettingsScreen

@Composable
fun KonveksiNavGraph(navController: NavHostController) {
    // Rute diagnostik hanya terdaftar pada build developer, bukan sekadar disembunyikan.
    val diagnosticsEnabled = BuildConfig.DEV_DIAGNOSTICS

    NavHost(navController = navController, startDestination = Routes.DASHBOARD) {
        composable(Routes.DASHBOARD) {
            DashboardScreen(
                onOpenMasterData = { navController.navigate(Routes.MASTER) },
                onOpenCustomers = { navController.navigate(Routes.CUSTOMERS) },
                onOpenAiAssistant = { navController.navigate(Routes.AI_ASSISTANT) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.MASTER) {
            MasterDataScreen(
                onOpenCustomers = { navController.navigate(Routes.CUSTOMERS) },
                onOpenProducts = { navController.navigate(Routes.PRODUCTS) },
                onOpenMaterials = { navController.navigate(Routes.MATERIALS) },
                onOpenWorkers = { navController.navigate(Routes.WORKERS) },
                onOpenSuppliers = { navController.navigate(Routes.SUPPLIERS) },
                onOpenBusinessProfile = { navController.navigate(Routes.BUSINESS_PROFILE) },
                onOpenOrders = { navController.navigate(Routes.ORDERS) },
                onOpenProduction = { navController.navigate(Routes.PRODUCTION) },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.CUSTOMERS) {
            CustomersScreen(
                onAddCustomer = { navController.navigate(Routes.CUSTOMER_FORM) },
                onBack = { navController.popBackStack() }
            )
        }
        composable(route = Routes.CUSTOMER_FORM) { entry ->
            CustomerFormScreen(
                customerId = entry.arguments?.getString(Routes.ARG_CUSTOMER_ID),
                onDone = { navController.popBackStack() }
            )
        }

        // Tahap 3: Pesanan & Produksi
        composable(Routes.ORDERS) {
            OrdersScreen(
                onAddOrder = { navController.navigate(Routes.ORDER_FORM) },
                onOpenOrder = { id -> navController.navigate(Routes.orderDetail(id)) },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.ORDER_FORM) {
            OrderFormScreen(onDone = { navController.popBackStack() })
        }
        composable(Routes.ORDER_DETAIL) { entry ->
            OrderDetailScreen(
                orderId = entry.arguments?.getString(Routes.ARG_ORDER_ID) ?: "",
                onDone = { navController.popBackStack() }
            )
        }
        composable(Routes.PRODUCTION) {
            ProductionScreen(onBack = { navController.popBackStack() })
        }

        // Tahap 4: Katalog & Persediaan
        composable(Routes.PRODUCTS) {
            ProductsScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.MATERIALS) {
            MaterialsScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.WORKERS) {
            WorkersScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.SUPPLIERS) {
            SuppliersScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.BUSINESS_PROFILE) {
            BusinessProfileScreen(onDone = { navController.popBackStack() })
        }

        composable(Routes.AI_ASSISTANT) {
            AiAssistantScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onOpenDiagnostics = {
                    if (BuildConfig.DEV_DIAGNOSTICS) navController.navigate(Routes.AI_DIAGNOSTICS)
                }
            )
        }
        if (diagnosticsEnabled) {
            composable(Routes.AI_DIAGNOSTICS) {
                val vm: AiDiagnosticsViewModel = viewModel(factory = AiDiagnosticsViewModel.factory())
                val state = remember(vm) { vm.state }
                AiDiagnosticsScreen(
                    statusLines = state.statusLines,
                    providerLines = state.providerLines,
                    exclusionLines = state.exclusionLines,
                    quotaLine = state.quotaLine,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
