package com.dooyappwork.konveksipro.feature.catalog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.data.local.entities.BusinessProfileEntity
import com.dooyappwork.konveksipro.data.local.entities.MaterialEntity
import com.dooyappwork.konveksipro.data.local.entities.MaterialMovementEntity
import com.dooyappwork.konveksipro.data.local.entities.ProductEntity
import com.dooyappwork.konveksipro.data.local.entities.SupplierEntity
import com.dooyappwork.konveksipro.data.local.entities.WorkerEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * ViewModel bersama untuk katalog & persediaan (Tahap 4).
 * Semua tulisan lewat repository (validasi + audit log); UI hanya meneruskan input.
 */
class CatalogViewModel(private val container: AppContainer) : androidx.lifecycle.ViewModel() {

    val products: StateFlow<List<ProductEntity>> = container.catalogRepository
        .observeProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val materials: StateFlow<List<MaterialEntity>> = container.catalogRepository
        .observeMaterials()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val workers: StateFlow<List<WorkerEntity>> = container.workersRepository
        .observeWorkers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Profil bisnis tersimpan (pre-fill form Profil Bisnis). */
    val profile: StateFlow<BusinessProfileEntity?> = container.businessProfileRepository
        .observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /** Supplier (Tahap 7). */
    val suppliers: StateFlow<List<SupplierEntity>> = container.suppliersRepository
        .observeSuppliers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Buku besar mutasi stok terbaru (Tahap 7) - untuk dialog Buku Stok. */
    val movements: StateFlow<List<MaterialMovementEntity>> = container.database
        .materialMovementDao().observeRecent(50)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private fun action(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
                _message.update { null }
            } catch (e: Exception) {
                _message.update { e.message ?: "Aksi gagal" }
            }
        }
    }

    // Produk (Tahap 7: + upah & overhead per unit)
    fun saveProduct(
        id: String?, name: String, category: String, price: String, notes: String,
        labor: String, overhead: String
    ) = action {
        container.catalogRepository.saveProduct(
            id, name, category, price.toLongOrNull() ?: 0, notes,
            labor.toLongOrNull() ?: 0, overhead.toLongOrNull() ?: 0
        )
    }
    fun deleteProduct(p: ProductEntity) = action({ container.catalogRepository.deleteProduct(p.id) })

    // Material
    fun saveMaterial(
        id: String?, name: String, unit: String, stock: String, minStock: String,
        buyPrice: String, notes: String
    ) = action {
        container.catalogRepository.saveMaterial(
            id, name, unit,
            stock.toDoubleOrNull() ?: 0.0, minStock.toDoubleOrNull() ?: 0.0,
            buyPrice.toLongOrNull() ?: 0, null, notes
        )
    }
    fun deleteMaterial(m: MaterialEntity) = action({ container.catalogRepository.deleteMaterial(m.id) })

    /** Mutasi stok manual: positif = masuk, negatif = keluar. */
    fun addStock(m: MaterialEntity, amountText: String, isIncome: Boolean) = action {
        val amount = amountText.toDoubleOrNull() ?: 0.0
        container.catalogRepository.addStock(m.id, if (isIncome) amount else -amount)
    }

    // Pekerja
    fun saveWorker(id: String?, name: String, role: String, phone: String, notes: String) = action {
        container.workersRepository.saveWorker(id, name, role, phone, notes)
    }
    fun deleteWorker(w: WorkerEntity) = action({ container.workersRepository.deleteWorker(w.id) })

    // Supplier (Tahap 7)
    fun saveSupplier(id: String?, name: String, phone: String, address: String, notes: String) = action {
        container.suppliersRepository.saveSupplier(id, name, phone, address, notes)
    }
    fun deleteSupplier(s: SupplierEntity) = action({ container.suppliersRepository.deleteSupplier(s.id) })

    // Profil bisnis
    fun saveProfile(name: String, owner: String, phone: String, address: String) = action {
        container.businessProfileRepository.saveProfile(name, owner, phone, address)
    }

    fun clearMessage() = _message.update { null }

    companion object {
        fun factory(): androidx.lifecycle.ViewModelProvider.Factory =
            com.dooyappwork.konveksipro.feature.containerFactory { CatalogViewModel(it) }
    }
}
