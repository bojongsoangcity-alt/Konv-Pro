package com.dooyappwork.konveksipro.ai.config

/** Batas penggunaan internal - pengganti kontrol biaya (Bag. 8). */
data class AILimitsConfig(
    val maxRequestsPerDay: Int = 40,
    val maxTokensPerDay: Int = 60_000,
    /** 0.0 = hanya provider gratis; biaya berbayar apa pun diblokir. */
    val maxCostUsdPerDay: Double = 0.0,
    val globalTimeoutMs: Long = 20_000,
    val maxFallbackAttempts: Int = 3,
    val retryBackoffMs: Long = 400
)

data class AIPrivacyConfig(
    val requireConsent: Boolean = true,
    val sendOnlyAggregates: Boolean = true
)

/**
 * Konfigurasi AI milik DEVELOPER (bukan pengguna).
 * Dibangun dari map yang berasal dari BuildConfig (diisi Gradle saat build).
 * Tidak ada jalur runtime untuk mengubahnya dari UI pengguna.
 */
data class DeveloperAIConfig(
    val providers: List<AIProviderConfig>,
    val primaryProviderId: String?,
    val fallbackProviderIds: List<String>,
    val limits: AILimitsConfig = AILimitsConfig(),
    val privacy: AIPrivacyConfig = AIPrivacyConfig(),
    val externalEnabled: Boolean = false
) {
    fun find(id: String): AIProviderConfig? = providers.firstOrNull { it.id == id }

    /** Provider yang layak dipakai: enabled + terkonfigurasi penuh. */
    fun usableProviders(): List<AIProviderConfig> = providers.filter { it.isConfigured }

    val hasUsableProvider: Boolean get() = usableProviders().isNotEmpty()

    fun statusLabel(): String = when {
        !externalEnabled -> "Nonaktif (developer)"
        !hasUsableProvider -> "Belum dikonfigurasi"
        else -> "Siap (${usableProviders().size} provider)"
    }

    companion object {
        val EMPTY = DeveloperAIConfig(
            providers = emptyList(),
            primaryProviderId = null,
            fallbackProviderIds = emptyList(),
            externalEnabled = false
        )

        private const val PREFIX = "ai.provider."

        /**
         * Membaca konfigurasi dari pasangan key/value build-time.
         * Format:
         *   ai.externalEnabled, ai.primary, ai.fallback
         *   ai.limits.maxRequestsPerDay | maxTokensPerDay | maxCostUsdPerDay | globalTimeoutMs | maxFallbackAttempts
         *   ai.privacy.requireConsent
         *   ai.provider.<id>.type|baseUrl|model|key|enabled|priority|timeoutMs|maxRetries|priceIn|priceOut|tokenCap|verified|path
         */
        fun fromMap(values: Map<String, String?>): DeveloperAIConfig {
            fun raw(key: String): String? = values[key]?.trim()?.takeIf { it.isNotEmpty() }

            val ids = values.keys
                .filter { it.startsWith(PREFIX) }
                .map { it.removePrefix(PREFIX).substringBefore('.') }
                .filter { it.isNotBlank() }
                .distinct()
                .sorted()

            val providers = ids.map { id ->
                val p = "$PREFIX$id."
                AIProviderConfig(
                    id = id,
                    type = ProviderType.from(raw(p + "type")),
                    baseUrl = raw(p + "baseUrl") ?: "",
                    model = raw(p + "model") ?: "",
                    apiKey = raw(p + "key"),
                    enabled = (raw(p + "enabled") ?: "true").toBooleanStrictOrNull() ?: true,
                    priority = raw(p + "priority")?.toIntOrNull() ?: 100,
                    timeoutMs = raw(p + "timeoutMs")?.toLongOrNull() ?: 15_000L,
                    maxRetries = (raw(p + "maxRetries")?.toIntOrNull() ?: 0).coerceIn(0, 1),
                    pricePer1kInputUsd = raw(p + "priceIn")?.toDoubleOrNull(),
                    pricePer1kOutputUsd = raw(p + "priceOut")?.toDoubleOrNull(),
                    maxOutputTokensCap = raw(p + "tokenCap")?.toIntOrNull(),
                    verified = (raw(p + "verified") ?: "false").toBooleanStrictOrNull() ?: false,
                    path = raw(p + "path"),
                    authHeader = raw(p + "authHeader") ?: "Authorization",
                    authPrefix = raw(p + "authPrefix") ?: "Bearer "
                )
            }

            val primary = raw("ai.primary")
            val fallback = raw("ai.fallback")
                ?.split(',', ';')
                ?.map { it.trim() }
                ?.filter { it.isNotEmpty() }
                ?: emptyList()

            return DeveloperAIConfig(
                providers = providers,
                primaryProviderId = primary,
                fallbackProviderIds = fallback.filter { it != primary },
                limits = AILimitsConfig(
                    maxRequestsPerDay = raw("ai.limits.maxRequestsPerDay")?.toIntOrNull() ?: 40,
                    maxTokensPerDay = raw("ai.limits.maxTokensPerDay")?.toIntOrNull() ?: 60_000,
                    maxCostUsdPerDay = raw("ai.limits.maxCostUsdPerDay")?.toDoubleOrNull() ?: 0.0,
                    globalTimeoutMs = raw("ai.limits.globalTimeoutMs")?.toLongOrNull() ?: 20_000L,
                    maxFallbackAttempts = (raw("ai.limits.maxFallbackAttempts")?.toIntOrNull() ?: 3).coerceIn(1, 5),
                    retryBackoffMs = raw("ai.limits.retryBackoffMs")?.toLongOrNull() ?: 400L
                ),
                privacy = AIPrivacyConfig(
                    requireConsent = (raw("ai.privacy.requireConsent") ?: "true").toBooleanStrictOrNull() ?: true
                ),
                externalEnabled = (raw("ai.externalEnabled") ?: "false").toBooleanStrictOrNull() ?: false
            )
        }
    }
}
