package com.dooyappwork.konveksipro.feature.orders

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.domain.model.Order
import com.dooyappwork.konveksipro.feature.containerFactory
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class OrdersUiState(
    val isLoading: Boolean = true,
    val orders: List<Order> = emptyList(),
    val error: String? = null
)

class OrdersViewModel(private val container: AppContainer) : ViewModel() {

    val state: StateFlow<OrdersUiState> = container.orderRepository
        .observeOrders()
        .map { OrdersUiState(isLoading = false, orders = it) }
        .catch { emit(OrdersUiState(isLoading = false, error = it.message ?: "Gagal memuat pesanan")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), OrdersUiState())

    companion object {
        fun factory(): ViewModelProvider.Factory = containerFactory { OrdersViewModel(it) }
    }
}
