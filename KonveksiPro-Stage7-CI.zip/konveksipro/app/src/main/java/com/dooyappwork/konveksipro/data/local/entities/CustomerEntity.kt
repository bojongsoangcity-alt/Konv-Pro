package com.dooyappwork.konveksipro.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.dooyappwork.konveksipro.domain.model.Customer

@Entity(tableName = "customers", indices = [Index("name")])
data class CustomerEntity(
    @PrimaryKey val id: String,          // UUID
    val name: String,
    val phone: String?,
    val email: String?,
    val address: String?,
    val notes: String?,
    val created_at: Long,
    val updated_at: Long,
    val deleted_at: Long? = null,        // Soft delete - histori transaksi tidak boleh rusak
    val device_id: String,
    val sync_status: String = "PENDING"
)

fun CustomerEntity.toDomain() = Customer(
    id = id, name = name, phone = phone, email = email,
    address = address, notes = notes, createdAt = created_at, updatedAt = updated_at
)
