package com.dooyappwork.konveksipro.data.repository

import androidx.room.withTransaction
import com.dooyappwork.konveksipro.data.local.KonveksiDatabase
import com.dooyappwork.konveksipro.data.local.entities.toDomain
import com.dooyappwork.konveksipro.data.local.entities.CustomerEntity
import com.dooyappwork.konveksipro.data.preferences.SettingsRepository
import com.dooyappwork.konveksipro.domain.model.Customer
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class CustomerRepository(
    private val db: KonveksiDatabase,
    private val audit: AuditLogRepository,
    private val settings: SettingsRepository
) {
    fun observeCustomers(): Flow<List<Customer>> =
        db.customerDao().observeAll().map { list -> list.map { it.toDomain() } }

    fun observeCount(): Flow<Int> = db.customerDao().observeCount()

    suspend fun add(name: String, phone: String?, email: String?, address: String?, notes: String?) {
        require(name.isNotBlank()) { "Nama pelanggan wajib diisi" }
        val trimmed = name.trim()
        require(db.customerDao().countByName(trimmed) == 0) { "Pelanggan dengan nama itu sudah ada" }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        val entity = CustomerEntity(
            id = UUID.randomUUID().toString(),
            name = trimmed,
            phone = phone?.trim()?.ifBlank { null },
            email = email?.trim()?.ifBlank { null },
            address = address?.trim()?.ifBlank { null },
            notes = notes?.trim()?.ifBlank { null },
            created_at = now, updated_at = now, device_id = deviceId
        )
        db.withTransaction {
            db.customerDao().upsert(entity)
            audit.log("CREATE", "customers", entity.id, entity.name, deviceId)
        }
    }

    suspend fun softDelete(id: String) {
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val rows = db.customerDao().softDelete(id, System.currentTimeMillis())
            check(rows == 1) { "Pelanggan tidak ditemukan" }
            audit.log("SOFT_DELETE", "customers", id, null, deviceId)
        }
    }
}
