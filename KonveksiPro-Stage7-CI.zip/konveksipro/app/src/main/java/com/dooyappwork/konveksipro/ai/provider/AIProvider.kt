package com.dooyappwork.konveksipro.ai.provider

import com.dooyappwork.konveksipro.ai.config.AIProviderConfig
import com.dooyappwork.konveksipro.ai.model.AIRequest
import com.dooyappwork.konveksipro.ai.model.ProviderResult

/**
 * Kontrak adapter provider. Setiap provider WAJIB punya implementasi sesuai
 * dokumentasi resminya: endpoint, header autentikasi, body, dan bentuk respons
 * berbeda - jangan dipukul rata (Bag. 3).
 */
interface AIProvider {
    val type: com.dooyappwork.konveksipro.ai.config.ProviderType

    /** Body + header request siap kirim (dipakai transport & unit test). */
    fun buildRequest(config: AIProviderConfig, request: AIRequest): PreparedRequest

    /** Mengekstrak teks jawaban dari body respons. null = format tidak dikenali. */
    fun parseResponse(config: AIProviderConfig, body: String): ParsedResponse?

    /** Jalankan permintaan lengkap (build -> transport -> parse). */
    suspend fun execute(config: AIProviderConfig, request: AIRequest): ProviderResult
}

data class PreparedRequest(
    val url: String,
    val headers: Map<String, String>,
    val body: String
)

data class ParsedResponse(
    val text: String,
    val inputTokens: Int,
    val outputTokens: Int
)
