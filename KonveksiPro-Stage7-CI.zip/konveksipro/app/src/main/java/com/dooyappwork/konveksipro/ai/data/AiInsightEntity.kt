package com.dooyappwork.konveksipro.ai.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Riwayat hasil analisis (lokal + narasi eksternal jika ada).
 * Tidak menyimpan API key, prompt mentah, atau data pelanggan.
 */
@Entity(tableName = "ai_insights", indices = [Index("created_at"), Index("kind")])
data class AiInsightEntity(
    @PrimaryKey val id: String,
    val kind: String,
    val source: String,             // LOCAL / EXTERNAL
    val provider_id: String?,
    val headline: String,
    val narrative: String?,
    val metrics_json: String,
    val tokens: Int,
    val created_at: Long,
    val device_id: String
)
