package com.dooyappwork.konveksipro.ai.repository

import com.dooyappwork.konveksipro.ai.local.BusinessSnapshot
import com.dooyappwork.konveksipro.data.local.KonveksiDatabase
import kotlinx.coroutines.flow.first

/**
 * Menyusun [BusinessSnapshot] dari database lokal: AGREGAT saja.
 * Nama/telepon/alamat pelanggan tidak pernah dimasukkan ke snapshot,
 * sehingga tidak mungkin ikut terkirim ke provider eksternal.
 * Tahap 3-4: menambah agregat pesanan, produksi, persediaan, katalog, pekerja.
 */
class BusinessSnapshotRepository(private val db: KonveksiDatabase) {

    suspend fun build(): BusinessSnapshot {
        val now = System.currentTimeMillis()
        val since30 = now - 30L * 86_400_000L
        val profile = db.businessProfileDao().getFirst()

        return BusinessSnapshot(
            businessName = profile?.business_name,
            isProfileConfigured = profile?.is_configured == true,
            customersTotal = db.customerDao().observeCount().first(),
            customersWithoutContact = db.customerDao().countWithoutContact(),
            customersAddedLast30Days = db.customerDao().countCreatedSince(since30),
            activityCountLast30Days = db.auditLogDao().countSince(since30),

            ordersActive = db.orderDao().observeActiveCount().first(),
            ordersLate = db.orderDao().observeLateCount(now).first(),
            ordersNew = db.orderDao().countNew(),
            ordersCreatedLast30Days = db.orderDao().countCreatedSince(since30),
            ordersUnpaid = db.orderDao().countUnpaid(),
            lastOrderAt = db.orderDao().lastOrderAt(),
            receivable = db.orderDao().observeReceivable().first(),

            productionAntre = db.productionDao().countByStatus("ANTRE"),
            productionProses = db.productionDao().countByStatus("PROSES"),
            productionFinishedLast30Days = db.productionDao().countFinishedSince(since30),
            productionWithoutWorker = db.productionDao().countWithoutWorker(),

            materialsTotal = db.materialDao().countActive(),
            materialsBelowMinimum = db.materialDao().countBelowMinimum(),
            materialStockValue = db.materialDao().sumStockValue(),
            materialsWithoutSupplier = db.materialDao().countWithoutSupplier(),
            productsActive = db.productDao().countActive(),
            productsWithoutRecipe = db.productDao().countWithoutRecipe(),
            productsLaborOverheadValue = db.productDao().sumActiveLaborOverhead(),
            workersTotal = db.workerDao().countActive(),
            suppliersTotal = db.supplierDao().countActive(),

            availableModules = setOf(
                "business", "customers", "orders", "production", "inventory", "costing", "material", "worker"
            )
        )
    }
}
