package com.dooyappwork.konveksipro.feature.orders

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dooyappwork.konveksipro.core.ui.*
import com.dooyappwork.konveksipro.core.utils.formatRupiah
import com.dooyappwork.konveksipro.core.utils.formatDateTime
import com.dooyappwork.konveksipro.domain.model.OrderStatus
import com.dooyappwork.konveksipro.domain.model.PaymentStatus

@Composable
fun OrdersScreen(
    onAddOrder: () -> Unit,
    onOpenOrder: (String) -> Unit,
    onBack: () -> Unit,
    viewModel: OrdersViewModel = viewModel(factory = OrdersViewModel.factory())
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = { KonveksiTopBar("Pesanan", "Pesanan jahit & cetir", onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddOrder,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Pesanan Baru") }
            )
        }
    ) { padding ->
        when {
            state.isLoading -> LoadingState(Modifier.padding(padding))
            state.error != null -> ErrorState(state.error ?: "", Modifier.padding(padding))
            state.orders.isEmpty() -> EmptyState(
                "Belum ada pesanan.\nKetuk Pesanan Baru untuk membuat pesanan pertama.",
                Modifier.padding(padding)
            )
            else -> LazyColumn(Modifier.padding(padding).fillMaxSize()) {
                items(state.orders, key = { it.id }) { order ->
                    Card(
                        onClick = { onOpenOrder(order.id) },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    order.orderCode,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                StatusChip(order.status)
                            }
                            Text(
                                order.customerName,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                formatRupiah(order.totalAmount) + " • " +
                                    (order.dueDate?.let { "Tenggat " + formatDateTime(it) } ?: "Tanpa tenggat"),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (order.paymentStatus == PaymentStatus.LUNAS) {
                                Text(
                                    "Lunas",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Chip status dengan warna bermakna (hijau selesai, oranye diproses, merah bermasalah). */
@Composable
fun StatusChip(status: String) {
    val (color, container) = when (status) {
        OrderStatus.SELESAI, "LUNAS" ->
            MaterialTheme.colorScheme.primary to MaterialTheme.colorScheme.primaryContainer
        OrderStatus.DIPRODUKSI, OrderStatus.BARU ->
            MaterialTheme.colorScheme.secondary to MaterialTheme.colorScheme.secondaryContainer
        else ->
            MaterialTheme.colorScheme.error to MaterialTheme.colorScheme.errorContainer
    }
    Surface(color = container, shape = MaterialTheme.shapes.small) {
        Text(
            if (status == "LUNAS") "Lunas" else OrderStatus.label(status),
            Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}
