package com.dooyappwork.konveksipro.ai.local

import com.dooyappwork.konveksipro.ai.model.InsightKind
import com.dooyappwork.konveksipro.ai.model.InsightMetric
import com.dooyappwork.konveksipro.ai.model.InsightReport

/**
 * Mesin analisis LOKAL berbasis aturan bisnis + statistik sederhana.
 * Ini BUKAN generative AI dan tidak boleh disebut sebagai AI generatif.
 * Seluruh angka berasal dari database; tidak ada angka contoh.
 * Tahap 3-4: seluruh jenis analisis kini memakai data pesanan, produksi,
 * persediaan, HPP material, material, dan pekerja yang benar-benar ada.
 */
class LocalInsightEngine {

    fun analyze(kind: InsightKind, snapshot: BusinessSnapshot, rupiah: (Long) -> String): InsightReport =
        when (kind) {
            InsightKind.BUSINESS -> business(snapshot, rupiah)
            InsightKind.ORDER -> order(snapshot, rupiah)
            InsightKind.PRODUCTION -> production(snapshot)
            InsightKind.INVENTORY -> inventory(snapshot, rupiah)
            InsightKind.COSTING -> costing(snapshot, rupiah)
            InsightKind.MATERIAL -> material(snapshot, rupiah)
            InsightKind.WORKER -> worker(snapshot)
        }

    private fun business(s: BusinessSnapshot, rupiah: (Long) -> String): InsightReport {
        val findings = mutableListOf<String>()
        val actions = mutableListOf<String>()
        var score = 100

        if (!s.isProfileConfigured) {
            score -= 30
            findings += "Profil bisnis belum diatur, sehingga laporan dan identitas dokumen belum lengkap."
            actions += "Lengkapi profil bisnis (nama usaha, pemilik, kontak) di Master Data."
        } else {
            findings += "Profil bisnis sudah terisi: ${s.businessName ?: "tanpa nama"}."
        }

        when {
            s.customersTotal == 0 -> {
                score -= 25
                findings += "Belum ada pelanggan tercatat, sehingga riwayat pesanan tidak bisa ditelusuri."
                actions += "Tambahkan minimal 3 pelanggan tetap untuk mulai membangun riwayat."
            }
            s.customersTotal < 5 -> {
                score -= 10
                findings += "Baru ${s.customersTotal} pelanggan terdaftar; basis pelanggan masih tipis."
                actions += "Targetkan penambahan pelanggan tetap agar produksi lebih stabil."
            }
            else -> findings += "${s.customersTotal} pelanggan aktif tercatat di database."
        }

        if (s.customersWithoutContact > 0) {
            score -= minOf(15, s.customersWithoutContact * 3)
            findings += "${s.customersWithoutContact} pelanggan belum punya nomor telepon/email, " +
                "sehingga konfirmasi pesanan dan penagihan berisiko gagal."
            actions += "Lengkapi kontak pelanggan yang masih kosong."
        }

        if (s.customersAddedLast30Days == 0 && s.customersTotal > 0) {
            findings += "Tidak ada pelanggan baru dalam 30 hari terakhir."
            actions += "Evaluasi kanal pemasaran yang berjalan saat ini."
        } else if (s.customersAddedLast30Days > 0) {
            findings += "${s.customersAddedLast30Days} pelanggan baru masuk dalam 30 hari terakhir."
        }

        // Tahap 3: sinyal operasional nyata
        if (s.ordersActive > 0) {
            findings += "${s.ordersActive} pesanan sedang berjalan (baru/diproduksi); piutang ${rupiah(s.receivable)}."
            if (s.ordersUnpaid > 0) {
                score -= minOf(10, s.ordersUnpaid * 2)
                actions += "Tagih pelunasan ${s.ordersUnpaid} pesanan yang belum lunas."
            }
        }
        if (s.ordersLate > 0) {
            score -= 15
            findings += "${s.ordersLate} pesanan melewati tenggat - risiko kepercayaan pelanggan."
            actions += "Prioritaskan pesanan yang melewati tenggat sebelum menerima pesanan baru."
        }
        if (s.materialsBelowMinimum > 0) {
            score -= minOf(10, s.materialsBelowMinimum * 2)
            findings += "${s.materialsBelowMinimum} material di bawah stok minimum."
            actions += "Pesan ulang material yang menipis sebelum mengganggu produksi."
        }

        if (s.activityCountLast30Days == 0) {
            score -= 10
            findings += "Belum ada aktivitas tercatat dalam 30 hari terakhir."
        } else {
            findings += "${s.activityCountLast30Days} aktivitas tercatat dalam 30 hari terakhir."
        }

        val label = when {
            score >= 80 -> "Sehat"
            score >= 60 -> "Perlu perhatian"
            else -> "Berisiko"
        }

        return InsightReport(
            kind = InsightKind.BUSINESS,
            headline = "Kesehatan usaha: $label (${score.coerceIn(0, 100)}/100)",
            metrics = listOf(
                InsightMetric("Pelanggan aktif", s.customersTotal.toString()),
                InsightMetric("Pesanan berjalan", s.ordersActive.toString()),
                InsightMetric("Pesanan telat", s.ordersLate.toString(), "Melewati tenggat"),
                InsightMetric("Tanpa kontak", s.customersWithoutContact.toString(), "Risiko follow-up"),
                InsightMetric("Piutang", rupiah(s.receivable)),
                InsightMetric("Material di bawah minimum", s.materialsBelowMinimum.toString())
            ),
            findings = findings,
            actions = actions.ifEmpty { listOf("Tidak ada tindakan mendesak; pertahankan pencatatan harian.") },
            score = score.coerceIn(0, 100),
            dataReady = true,
            note = "Analisis berbasis aturan dan data lokal. Bukan generative AI."
        )
    }

    private fun order(s: BusinessSnapshot, rupiah: (Long) -> String): InsightReport {
        val findings = mutableListOf<String>()
        val actions = mutableListOf<String>()
        var score = 100

        when {
            s.ordersActive == 0 && s.ordersNew == 0 -> {
                score -= 20
                findings += "Tidak ada pesanan berjalan. Kapasitas produksi menganggur."
                actions += "Aktifkan promosi atau hubungi pelanggan tetap untuk pesanan baru."
            }
            else -> findings += "${s.ordersActive} pesanan berjalan, ${s.ordersNew} masih berstatus baru."
        }

        if (s.ordersLate > 0) {
            score -= 25
            findings += "${s.ordersLate} pesanan melewati tenggat."
            actions += "Kerjakan pesanan telat lebih dulu dan beri tahu pelanggannya."
        } else if (s.ordersActive > 0) {
            findings += "Tidak ada pesanan yang melewati tenggat."
        }

        if (s.ordersUnpaid > 0) {
            score -= minOf(20, s.ordersUnpaid * 5)
            findings += "${s.ordersUnpaid} pesanan belum lunas; piutang total ${rupiah(s.receivable)}."
            actions += "Catat pembayaran saat pengambilan barang agar kas sehat."
        } else if (s.receivable <= 0) {
            findings += "Tidak ada piutang tertunda."
        }

        if (s.ordersCreatedLast30Days > 0) {
            findings += "${s.ordersCreatedLast30Days} pesanan dibuat dalam 30 hari terakhir."
        } else {
            score -= 10
            findings += "Tidak ada pesanan baru dalam 30 hari terakhir."
        }

        val label = when {
            score >= 80 -> "Terkendali"
            score >= 60 -> "Perlu perhatian"
            else -> "Berisiko"
        }
        return InsightReport(
            kind = InsightKind.ORDER,
            headline = "Pesanan: $label (${score.coerceIn(0, 100)}/100)",
            metrics = listOf(
                InsightMetric("Berjalan", s.ordersActive.toString()),
                InsightMetric("Status baru", s.ordersNew.toString()),
                InsightMetric("Telat", s.ordersLate.toString()),
                InsightMetric("Belum lunas", s.ordersUnpaid.toString()),
                InsightMetric("Piutang", rupiah(s.receivable)),
                InsightMetric("Baru 30 hari", s.ordersCreatedLast30Days.toString())
            ),
            findings = findings,
            actions = actions.ifEmpty { listOf("Pertahankan ketepatan tenggat dan pencatatan pembayaran.") },
            score = score.coerceIn(0, 100),
            dataReady = true,
            note = "Analisis berbasis aturan dan data lokal. Bukan generative AI."
        )
    }

    private fun production(s: BusinessSnapshot): InsightReport {
        val findings = mutableListOf<String>()
        val actions = mutableListOf<String>()
        var score = 100
        val load = s.productionAntre + s.productionProses

        when {
            load == 0 -> {
                score -= 15
                findings += "Tidak ada batch produksi berjalan. Tenaga kerja menganggur."
                actions += "Isi kapasitas dengan produksi internal atau pesanan baru."
            }
            else -> findings += "Beban kerja: ${s.productionAntre} antre, ${s.productionProses} sedang proses."
        }

        if (s.productionWithoutWorker > 0) {
            score -= minOf(20, s.productionWithoutWorker * 5)
            findings += "${s.productionWithoutWorker} batch belum diberi pekerja - berisiko menganggur tanpa terlihat."
            actions += "Tugaskan pekerja pada setiap batch sebelum memulai."
        }

        if (s.productionFinishedLast30Days > 0) {
            findings += "${s.productionFinishedLast30Days} batch selesai dalam 30 hari terakhir."
        } else if (load > 0) {
            findings += "Belum ada batch selesai dalam 30 hari terakhir."
            actions += "Periksa hambatan alur kerja (bahan, alat, atau tenaga)."
        }

        val label = when {
            score >= 80 -> "Mengalir"
            score >= 60 -> "Perlu perhatian"
            else -> "Tersumbat"
        }
        return InsightReport(
            kind = InsightKind.PRODUCTION,
            headline = "Produksi: $label (${score.coerceIn(0, 100)}/100)",
            metrics = listOf(
                InsightMetric("Antre", s.productionAntre.toString()),
                InsightMetric("Proses", s.productionProses.toString()),
                InsightMetric("Tanpa pekerja", s.productionWithoutWorker.toString()),
                InsightMetric("Selesai 30 hari", s.productionFinishedLast30Days.toString())
            ),
            findings = findings,
            actions = actions.ifEmpty { listOf("Pertahankan ritme produksi harian.") },
            score = score.coerceIn(0, 100),
            dataReady = true,
            note = "Analisis berbasis aturan dan data lokal. Bukan generative AI."
        )
    }

    private fun inventory(s: BusinessSnapshot, rupiah: (Long) -> String): InsightReport {
        val findings = mutableListOf<String>()
        val actions = mutableListOf<String>()
        var score = 100

        when {
            s.materialsTotal == 0 -> {
                score -= 30
                findings += "Belum ada material tercatat - HPP material tidak bisa dihitung."
                actions += "Daftarkan material utama (kain, aksesoris) dan stoknya."
            }
            else -> {
                findings += "${s.materialsTotal} material tercatat, nilai stok ${rupiah(s.materialStockValue)}."
                if (s.materialsBelowMinimum > 0) {
                    score -= minOf(30, s.materialsBelowMinimum * 10)
                    findings += "${s.materialsBelowMinimum} material di bawah stok minimum - produksi bisa berhenti mendadak."
                    actions += "Buat pesanan pembelian ke supplier untuk material kritis."
                } else {
                    findings += "Semua material berada di atas stok minimum."
                }
                if (s.materialsWithoutSupplier > 0) {
                    score -= minOf(10, s.materialsWithoutSupplier * 2)
                    findings += "${s.materialsWithoutSupplier} material belum punya supplier tetap."
                    actions += "Tetapkan supplier utama agar pengadaan lebih cepat."
                }
            }
        }

        val label = when {
            score >= 80 -> "Aman"
            score >= 60 -> "Perlu perhatian"
            else -> "Kritis"
        }
        return InsightReport(
            kind = InsightKind.INVENTORY,
            headline = "Persediaan: $label (${score.coerceIn(0, 100)}/100)",
            metrics = listOf(
                InsightMetric("Jenis material", s.materialsTotal.toString()),
                InsightMetric("Di bawah minimum", s.materialsBelowMinimum.toString(), "Risiko berhenti produksi"),
                InsightMetric("Nilai stok", rupiah(s.materialStockValue)),
                InsightMetric("Tanpa supplier", s.materialsWithoutSupplier.toString())
            ),
            findings = findings,
            actions = actions.ifEmpty { listOf("Pertahankan disiplin pencatatan stok masuk/keluar.") },
            score = score.coerceIn(0, 100),
            dataReady = true,
            note = "Analisis berbasis aturan dan data lokal. Bukan generative AI."
        )
    }

    private fun costing(s: BusinessSnapshot, rupiah: (Long) -> String): InsightReport {
        val findings = mutableListOf<String>()
        val actions = mutableListOf<String>()
        var score = 100

        if (s.productsActive == 0) {
            score -= 30
            findings += "Belum ada produk terdaftar, sehingga struktur HPP belum bisa dianalisis."
            actions += "Daftarkan produk utama beserta resep bahannya."
        } else {
            findings += "${s.productsActive} produk aktif tercatat."
            if (s.productsWithoutRecipe > 0) {
                score -= minOf(25, s.productsWithoutRecipe * 5)
                findings += "${s.productsWithoutRecipe} produk belum punya resep bahan (BOM) - HPP-nya belum bisa dihitung."
                actions += "Lengkapi resep bahan produk agar margin terlihat."
            } else {
                findings += "Semua produk aktif sudah punya resep bahan."
            }
            // Tahap 7: upah & overhead opsional - dilaporkan apa adanya.
            if (s.productsLaborOverheadValue > 0) {
                findings += "Upah + overhead per unit sudah diisi untuk sebagian produk (total ${rupiah(s.productsLaborOverheadValue)})."
            } else {
                findings += "Upah dan overhead per unit belum diisi pada satu produk pun - HPP baru mencakup material."
                actions += "Isi upah/overhead per unit di data produk agar HPP lebih akurat."
            }
        }

        return InsightReport(
            kind = InsightKind.COSTING,
            headline = "HPP: ${if (score >= 80) "Terukur" else "Perlu dilengkapi"} (${score.coerceIn(0, 100)}/100)",
            metrics = listOf(
                InsightMetric("Produk aktif", s.productsActive.toString()),
                InsightMetric("Tanpa resep BOM", s.productsWithoutRecipe.toString()),
                InsightMetric("Nilai stok bahan", rupiah(s.materialStockValue)),
                InsightMetric("Upah+overhead portofolio", rupiah(s.productsLaborOverheadValue))
            ),
            findings = findings,
            actions = actions.ifEmpty { listOf("Tinjau harga jual bila harga bahan atau upah berubah.") },
            score = score.coerceIn(0, 100),
            dataReady = true,
            note = "HPP = material (BOM x harga beli) + upah/overhead per unit untuk produk yang mengisinya. Nilai 0 berarti belum diisi - tidak ada angka karangan."
        )
    }

    private fun material(s: BusinessSnapshot, rupiah: (Long) -> String): InsightReport {
        val findings = mutableListOf<String>()
        val actions = mutableListOf<String>()
        var score = 100

        if (s.materialsTotal == 0) {
            score -= 30
            findings += "Belum ada material tercatat."
            actions += "Daftarkan material beserta stok dan harga belinya."
        } else {
            findings += "${s.materialsTotal} material dengan nilai stok ${rupiah(s.materialStockValue)}."
            if (s.materialsBelowMinimum > 0) {
                score -= 20
                findings += "${s.materialsBelowMinimum} material perlu segera dipesan ulang."
                actions += "Prioritaskan pembelian material yang paling menipis."
            }
            if (s.suppliersTotal == 0) {
                score -= 10
                findings += "Belum ada supplier terdaftar."
                actions += "Daftarkan supplier tetap untuk mempercepat pengadaan."
            }
        }

        return InsightReport(
            kind = InsightKind.MATERIAL,
            headline = "Material: ${if (score >= 80) "Terkendali" else "Perlu tindakan"} (${score.coerceIn(0, 100)}/100)",
            metrics = listOf(
                InsightMetric("Jenis material", s.materialsTotal.toString()),
                InsightMetric("Di bawah minimum", s.materialsBelowMinimum.toString()),
                InsightMetric("Nilai stok", rupiah(s.materialStockValue)),
                InsightMetric("Supplier aktif", s.suppliersTotal.toString())
            ),
            findings = findings,
            actions = actions.ifEmpty { listOf("Stok material terkendali.") },
            score = score.coerceIn(0, 100),
            dataReady = true,
            note = "Analisis berbasis aturan dan data lokal. Bukan generative AI."
        )
    }

    private fun worker(s: BusinessSnapshot): InsightReport {
        val findings = mutableListOf<String>()
        val actions = mutableListOf<String>()
        var score = 100
        val load = s.productionAntre + s.productionProses

        if (s.workersTotal == 0) {
            score -= 25
            findings += "Belum ada pekerja terdaftar."
            actions += "Daftarkan tenaga kerja agar beban bisa dibagi per batch."
        } else {
            findings += "${s.workersTotal} pekerja aktif tercatat."
            if (s.productionWithoutWorker > 0) {
                score -= minOf(25, s.productionWithoutWorker * 5)
                findings += "${s.productionWithoutWorker} batch belum ditugaskan ke pekerja mana pun."
                actions += "Bagi batch yang belum bertugas agar tidak menumpuk di satu orang."
            } else if (load > 0) {
                findings += "Semua batch berjalan sudah punya pekerja."
            }
            if (load > s.workersTotal * 3 && s.workersTotal > 0) {
                score -= 10
                findings += "Beban kerja (${load} batch) jauh di atas jumlah pekerja - waspadai lembur berlebih."
                actions += "Pertimbangkan menambah tenaga atau merentang tenggat pesanan baru."
            }
        }

        return InsightReport(
            kind = InsightKind.WORKER,
            headline = "Tenaga kerja: ${if (score >= 80) "Seimbang" else "Perlu penataan"} (${score.coerceIn(0, 100)}/100)",
            metrics = listOf(
                InsightMetric("Pekerja aktif", s.workersTotal.toString()),
                InsightMetric("Batch tanpa pekerja", s.productionWithoutWorker.toString()),
                InsightMetric("Batch berjalan", load.toString())
            ),
            findings = findings,
            actions = actions.ifEmpty { listOf("Pembagian kerja sudah rapi.") },
            score = score.coerceIn(0, 100),
            dataReady = true,
            note = "Analisis berbasis aturan dan data lokal. Bukan generative AI."
        )
    }
}
