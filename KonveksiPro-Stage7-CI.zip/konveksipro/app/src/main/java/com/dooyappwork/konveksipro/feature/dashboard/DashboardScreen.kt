package com.dooyappwork.konveksipro.feature.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dooyappwork.konveksipro.core.ui.*

@Composable
fun DashboardScreen(
    onOpenMasterData: () -> Unit,
    onOpenCustomers: () -> Unit,
    onOpenAiAssistant: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    viewModel: DashboardViewModel = viewModel(factory = DashboardViewModel.factory())
) {
    val state by viewModel.state.collectAsState()

    Scaffold { padding ->
        when {
            state.isLoading -> LoadingState(Modifier.padding(padding))
            state.error != null -> ErrorState(state.error ?: "", Modifier.padding(padding))
            else -> Column(
                Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Text(
                    state.businessName ?: "KonveksiPro",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    state.businessId?.let { "Business ID: $it" } ?: "Profil bisnis belum diatur",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MetricCard("Pelanggan", state.totalCustomers.toString(), Modifier.weight(1f))
                    MetricCard("Pesanan", state.ordersActive.toString(), Modifier.weight(1f))
                    MetricCard("Produksi", state.productionActive.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                // Tahap 3-4: kartu terisi dari tabel orders / production_batches / materials
                // lewat Flow Room - bukan angka statis.
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MetricCard("Piutang", com.dooyappwork.konveksipro.core.utils.formatRupiah(state.receivable), Modifier.weight(1f))
                    MetricCard("Barang Jadi", state.ordersDone.toString(), Modifier.weight(1f))
                    MetricCard("Stok Min.", state.materialsBelowMinimum.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = onOpenMasterData, modifier = Modifier.weight(1f)) {
                        Text("Master Data")
                    }
                    OutlinedButton(onClick = onOpenCustomers, modifier = Modifier.weight(1f)) {
                        Text("Pelanggan")
                    }
                }
                Spacer(Modifier.height(12.dp))
                // Stage 2: akses Asisten AI (analisis lokal + narasi eksternal) dan Pengaturan.
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = onOpenAiAssistant, modifier = Modifier.weight(1f)) {
                        Icon(
                            Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Asisten AI")
                    }
                    OutlinedButton(onClick = onOpenSettings, modifier = Modifier.weight(1f)) {
                        Text("Pengaturan")
                    }
                }
                Spacer(Modifier.height(16.dp))

                Text("Aktivitas Terakhir", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (state.recentActivity.isEmpty()) {
                    Card {
                        Text(
                            "Belum ada aktivitas. Mulai dari mengatur profil bisnis dan menambah pelanggan.",
                            Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                } else {
                    state.recentActivity.forEach { entry ->
                        Card(Modifier.padding(vertical = 4.dp)) {
                            Text(entry, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
