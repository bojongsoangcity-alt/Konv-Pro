package com.dooyappwork.konveksipro.domain.model

data class Customer(
    val id: String,
    val name: String,
    val phone: String?,
    val email: String?,
    val address: String?,
    val notes: String?,
    val createdAt: Long,
    val updatedAt: Long
)
