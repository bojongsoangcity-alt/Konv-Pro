package com.dooyappwork.konveksipro.ai.provider

import com.dooyappwork.konveksipro.ai.config.AIProviderConfig
import com.dooyappwork.konveksipro.ai.config.DeveloperAIConfig

/**
 * Urutan percobaan provider: primary dulu, lalu fallback sesuai konfigurasi developer.
 * Tidak pernah menambah provider di luar daftar yang disetujui developer.
 */
class ProviderSelector(private val registry: ProviderRegistry) {

    fun chain(config: DeveloperAIConfig): List<AIProviderConfig> {
        if (!config.externalEnabled) return emptyList()
        val ordered = buildList {
            config.primaryProviderId?.let { id -> config.find(id)?.let { add(it) } }
            config.fallbackProviderIds.forEach { id -> config.find(id)?.let { add(it) } }
        }
        return ordered
            .filter { it.isConfigured && registry.hasAdapter(it) }
            .distinctBy { it.id }
            .take(config.limits.maxFallbackAttempts.coerceAtLeast(1))
    }

    /** Alasan provider tidak dipakai - untuk diagnostik developer (tanpa kredensial). */
    fun excludedReasons(config: DeveloperAIConfig): List<String> {
        val reason = mutableListOf<String>()
        if (!config.externalEnabled) reason += "AI eksternal dinonaktifkan pada konfigurasi build (ai.externalEnabled=false)"
        config.providers.forEach { p ->
            when {
                !p.enabled -> reason += "${p.id}: dinonaktifkan"
                p.type == com.dooyappwork.konveksipro.ai.config.ProviderType.CUSTOM && !p.verified ->
                    reason += "${p.id}: adapter CUSTOM belum diverifikasi developer"
                p.type == com.dooyappwork.konveksipro.ai.config.ProviderType.NONE ->
                    reason += "${p.id}: tipe provider tidak dikenali"
                p.apiKey.isNullOrBlank() -> reason += "${p.id}: API key build tidak tersedia"
                !registry.hasAdapter(p) -> reason += "${p.id}: tidak ada adapter untuk ${p.type}"
            }
        }
        if (config.primaryProviderId == null) reason += "ai.primary belum diatur"
        return reason
    }
}
