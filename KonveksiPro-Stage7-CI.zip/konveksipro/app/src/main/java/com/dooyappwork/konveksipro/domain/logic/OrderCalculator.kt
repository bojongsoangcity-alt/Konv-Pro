package com.dooyappwork.konveksipro.domain.logic

import com.dooyappwork.konveksipro.domain.model.OrderStatus

/**
 * Kalkulasi & aturan status pesanan - murni Kotlin agar bisa diuji tanpa perangkat Android.
 * Semua angka uang = Long rupiah (keputusan desain database Stage 1).
 */
object OrderCalculator {

    data class LineInput(val productName: String, val qty: Long, val unitPrice: Long)

    fun lineTotal(qty: Long, unitPrice: Long): Long = qty * unitPrice

    fun total(items: List<LineInput>): Long = items.sumOf { lineTotal(it.qty, it.unitPrice) }

    /**
     * Validasi seluruh baris + uang muka. Mengembalikan total pesanan bila valid,
     * melempar IllegalArgumentException dengan pesan siap-tampilkan bila tidak.
     */
    fun validate(items: List<LineInput>, downPayment: Long): Long {
        require(items.isNotEmpty()) { "Minimal satu baris produk harus diisi" }
        items.forEachIndexed { i, it ->
            require(it.productName.isNotBlank()) { "Nama produk pada baris ${i + 1} wajib diisi" }
            require(it.qty > 0) { "Jumlah pada baris ${i + 1} harus lebih dari 0" }
            require(it.unitPrice >= 0) { "Harga pada baris ${i + 1} tidak boleh negatif" }
        }
        val total = total(items)
        require(downPayment >= 0) { "Uang muka tidak boleh negatif" }
        require(downPayment <= total) { "Uang muka melebihi total pesanan" }
        return total
    }

    /** Sisa tagihan = total - DP - pelunasan; tidak pernah negatif. */
    fun receivable(totalAmount: Long, downPayment: Long, paidAmount: Long): Long =
        (totalAmount - downPayment - paidAmount).coerceAtLeast(0)

    /** Transisi status yang sah; selain daftar ini repository menolak perubahan. */
    fun canTransition(from: String, to: String): Boolean = when (from) {
        OrderStatus.BARU -> to == OrderStatus.DIPRODUKSI || to == OrderStatus.DIBATALKAN
        OrderStatus.DIPRODUKSI -> to == OrderStatus.SELESAI || to == OrderStatus.DIBATALKAN
        else -> false
    }
}
