package com.dooyappwork.konveksipro.feature.master

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dooyappwork.konveksipro.core.ui.KonveksiTopBar

private data class MasterMenu(val title: String, val icon: ImageVector, val available: Boolean, val badge: String? = null)

/**
 * Master Data (Tahap 3-4): seluruh modul data dasar aktif.
 * Supplier masih dinonaktifkan (tanpa layar khusus) - kartu tidak bisa diketuk,
 * jadi tidak ada tombol pajangan.
 */
@Composable
fun MasterDataScreen(
    onOpenCustomers: () -> Unit,
    onOpenProducts: () -> Unit,
    onOpenMaterials: () -> Unit,
    onOpenWorkers: () -> Unit,
    onOpenSuppliers: () -> Unit = {},
    onOpenBusinessProfile: () -> Unit,
    onOpenOrders: () -> Unit,
    onOpenProduction: () -> Unit,
    onBack: () -> Unit
) {
    val menus = listOf(
        // Hanya ikon dari material-icons-core (dijamin ada di semua versi BOM).
        MasterMenu("Pelanggan", Icons.Filled.Person, available = true),
        MasterMenu("Produk", Icons.Filled.Star, available = true),
        MasterMenu("Material", Icons.Filled.Build, available = true),
        MasterMenu("Pekerja", Icons.Filled.List, available = true),
        MasterMenu("Profil Bisnis", Icons.Filled.Home, available = true),
        MasterMenu("Pesanan", Icons.Filled.CheckCircle, available = true),
        MasterMenu("Produksi", Icons.Filled.Refresh, available = true),
        MasterMenu("Supplier", Icons.Filled.Place, available = true)
    )

    Scaffold(topBar = { KonveksiTopBar("Master Data", "Kelola data dasar usaha", onBack) }) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(menus) { menu ->
                Card(
                    onClick = {
                        when (menu.title) {
                            "Pelanggan" -> onOpenCustomers()
                            "Produk" -> onOpenProducts()
                            "Material" -> onOpenMaterials()
                            "Pekerja" -> onOpenWorkers()
                            "Supplier" -> onOpenSuppliers()
                            "Profil Bisnis" -> onOpenBusinessProfile()
                            "Pesanan" -> onOpenOrders()
                            "Produksi" -> onOpenProduction()
                        }
                    },
                    enabled = menu.available
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            menu.icon,
                            contentDescription = menu.title,
                            tint = if (menu.available) MaterialTheme.colorScheme.primary
                                   else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            menu.title,
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        if (!menu.available) {
                            Text(
                                menu.badge ?: "Belum aktif",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
