package com.dooyappwork.konveksipro.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Profil bisnis - dasar pengikatan Business ID pada lisensi (Stage 10). */
@Entity(tableName = "business_profile")
data class BusinessProfileEntity(
    @PrimaryKey val id: String,          // UUID - menjadi Business ID
    val business_name: String,
    val owner_name: String?,
    val phone: String?,
    val address: String?,
    val is_configured: Boolean,
    val created_at: Long,
    val updated_at: Long,
    val deleted_at: Long? = null,
    val device_id: String,
    val sync_status: String = "PENDING"  // Kesiapan sinkronisasi masa depan (Bag. 14)
)
