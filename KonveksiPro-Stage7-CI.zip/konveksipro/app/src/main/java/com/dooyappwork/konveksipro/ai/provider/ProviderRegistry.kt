package com.dooyappwork.konveksipro.ai.provider

import com.dooyappwork.konveksipro.ai.config.AIProviderConfig
import com.dooyappwork.konveksipro.ai.config.ProviderType

/**
 * Memetakan tipe provider ke adapter nyata.
 * Provider bertipe yang belum punya adapter TIDAK akan pernah dipakai.
 */
class ProviderRegistry(adapters: List<AIProvider>) {

    private val byType: Map<ProviderType, AIProvider> = adapters.associateBy { it.type }

    fun adapterFor(config: AIProviderConfig): AIProvider? {
        if (config.type == ProviderType.CUSTOM && !config.verified) return null
        if (config.type == ProviderType.NONE) return null
        return byType[config.type]
    }

    fun hasAdapter(config: AIProviderConfig): Boolean = adapterFor(config) != null

    fun registeredTypes(): List<ProviderType> = byType.keys.sortedBy { it.ordinal }

    companion object {
        /** Daftar adapter yang benar-benar diimplementasikan pada tahap ini. */
        fun default(transport: com.dooyappwork.konveksipro.ai.transport.JsonTransport): ProviderRegistry =
            ProviderRegistry(
                listOf(
                    GeminiAdapter(transport),
                    OpenAICompatibleAdapter(transport),
                    CustomProviderAdapter(transport)
                )
            )
    }
}
