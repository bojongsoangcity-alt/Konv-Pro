package com.dooyappwork.konveksipro.domain.model

/** Pesanan (Tahap 3). Uang = Long rupiah sesuai keputusan desain database. */
data class Order(
    val id: String,
    val orderCode: String,
    val customerId: String?,
    val customerName: String,
    val status: String,
    val orderDate: Long,
    val dueDate: Long?,
    val totalAmount: Long,
    val downPayment: Long,
    val paidAmount: Long,
    val paymentStatus: String,
    val notes: String?,
    val createdAt: Long,
    val updatedAt: Long
)

/** Baris produk pada pesanan. Nama produk disimpan sebagai teks (snapshot) agar histori tidak berubah saat master produk diedit. */
data class OrderItem(
    val id: String,
    val orderId: String,
    val productName: String,
    val qty: Long,
    val unitPrice: Long,
    val note: String?,
    val createdAt: Long
)

/** Batch pekerjaan produksi (Tahap 3). Satu pesanan dapat menghasilkan beberapa batch (satu per baris produk). */
data class ProductionBatch(
    val id: String,
    val orderId: String?,
    val orderCode: String?,
    val productId: String?,
    val productName: String,
    val qty: Long,
    val status: String,
    val workerId: String?,
    val workerName: String?,
    val dueDate: Long?,
    val startedAt: Long?,
    val finishedAt: Long?,
    val notes: String?,
    val createdAt: Long,
    val updatedAt: Long
)
