package com.dooyappwork.konveksipro.ai.provider

import com.dooyappwork.konveksipro.ai.config.AIProviderConfig
import com.dooyappwork.konveksipro.ai.config.ProviderType
import com.dooyappwork.konveksipro.ai.model.AIRequest
import com.dooyappwork.konveksipro.ai.model.FailureKind
import com.dooyappwork.konveksipro.ai.transport.JsonTransport
import com.dooyappwork.konveksipro.ai.util.JsonParser
import com.dooyappwork.konveksipro.ai.util.JsonWriter
import com.dooyappwork.konveksipro.ai.util.asIntOrNull
import com.dooyappwork.konveksipro.ai.util.asStringOrNull
import com.dooyappwork.konveksipro.ai.util.path

/**
 * Adapter kompatibel OpenAI: POST {baseUrl}/chat/completions
 * auth: Authorization: Bearer <key>, body messages[], respons choices[0].message.content.
 * Cocok untuk endpoint yang benar-benar kompatibel; provider dengan format lain
 * wajib memakai adapter sendiri, bukan adapter ini.
 */
class OpenAICompatibleAdapter(transport: JsonTransport) : BaseHttpProvider(transport) {

    override val type = ProviderType.OPENAI_COMPATIBLE

    override fun buildRequest(config: AIProviderConfig, request: AIRequest): PreparedRequest {
        val suffix = config.path?.takeIf { it.isNotBlank() } ?: "/chat/completions"
        val url = config.baseUrl.trimEnd('/') + (if (suffix.startsWith("/")) suffix else "/$suffix")
        val messages = buildList {
            request.systemInstruction?.let {
                add(JsonWriter.obj("role" to "system", "content" to it))
            }
            add(JsonWriter.obj("role" to "user", "content" to request.prompt))
        }.joinToString(",", "[", "]")

        val maxTokens = config.maxOutputTokensCap?.let { minOf(it, request.maxOutputTokens) } ?: request.maxOutputTokens
        val body = JsonWriter.obj(
            "model" to config.model,
            "messages" to messages,
            "temperature" to request.temperature,
            "max_tokens" to maxTokens
        )
        val headers = mapOf(config.authHeader to (config.authPrefix + (config.apiKey ?: "")))
        return PreparedRequest(url, headers, body)
    }

    override fun parseResponse(config: AIProviderConfig, body: String): ParsedResponse? {
        val root = JsonParser.parseOrNull(body) ?: return null
        val message = root.path("choices", 0, "message", "content")
        val text = message.asStringOrNull()
            ?: (message as? com.dooyappwork.konveksipro.ai.util.JsonNode.Arr)
                ?.items?.mapNotNull { it.path("text").asStringOrNull() }?.joinToString("")
            ?: return null
        if (text.isBlank()) return null
        val usage = root.path("usage")
        return ParsedResponse(
            text = text,
            inputTokens = usage.path("prompt_tokens").asIntOrNull() ?: 0,
            outputTokens = usage.path("completion_tokens").asIntOrNull() ?: 0
        )
    }

    override fun classifyHttpError(status: Int, body: String): FailureKind {
        val message = errorDetail(body)?.lowercase() ?: ""
        return when {
            status == 429 && (message.contains("quota") || message.contains("insufficient")) -> FailureKind.QUOTA_EXHAUSTED
            status == 429 -> FailureKind.RATE_LIMIT
            status == 402 || message.contains("insufficient_quota") -> FailureKind.QUOTA_EXHAUSTED
            status == 401 || status == 403 -> FailureKind.INVALID_KEY
            status in 500..599 -> FailureKind.SERVER_ERROR
            else -> FailureKind.fromHttpCode(status)
        }
    }

    override fun errorDetail(body: String?): String? {
        val root = JsonParser.parseOrNull(body ?: "") ?: return null
        return root.path("error", "message").asStringOrNull()
            ?: root.path("message").asStringOrNull()
    }
}
