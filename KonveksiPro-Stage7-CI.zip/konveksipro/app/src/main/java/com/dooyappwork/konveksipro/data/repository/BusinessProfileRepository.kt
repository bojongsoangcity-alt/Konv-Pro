package com.dooyappwork.konveksipro.data.repository

import androidx.room.withTransaction
import com.dooyappwork.konveksipro.data.local.KonveksiDatabase
import com.dooyappwork.konveksipro.data.local.entities.BusinessProfileEntity
import com.dooyappwork.konveksipro.data.preferences.SettingsRepository
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class BusinessProfileRepository(
    private val db: KonveksiDatabase,
    private val audit: AuditLogRepository,
    private val settings: SettingsRepository
) {
    fun observe(): Flow<BusinessProfileEntity?> = db.businessProfileDao().observe()

    suspend fun saveProfile(
        businessName: String,
        ownerName: String?,
        phone: String?,
        address: String?
    ) {
        require(businessName.isNotBlank()) { "Nama bisnis wajib diisi" }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        val existing = db.businessProfileDao().getFirst()
        val entity = if (existing == null) {
            BusinessProfileEntity(
                id = UUID.randomUUID().toString(),   // Business ID
                business_name = businessName.trim(),
                owner_name = ownerName?.trim()?.ifBlank { null },
                phone = phone?.trim()?.ifBlank { null },
                address = address?.trim()?.ifBlank { null },
                is_configured = true,
                created_at = now, updated_at = now, device_id = deviceId
            )
        } else {
            existing.copy(
                business_name = businessName.trim(),
                owner_name = ownerName?.trim()?.ifBlank { null },
                phone = phone?.trim()?.ifBlank { null },
                address = address?.trim()?.ifBlank { null },
                is_configured = true, updated_at = now, device_id = deviceId
            )
        }
        db.withTransaction {
            db.businessProfileDao().upsert(entity)
            audit.log(
                if (existing == null) "CREATE" else "UPDATE",
                "business_profile", entity.id, entity.business_name, deviceId
            )
        }
    }
}
