package com.dooyappwork.konveksipro.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.dooyappwork.konveksipro.domain.model.ProductionBatch

/**
 * Batch pekerjaan produksi (Tahap 3). Satu pesanan dapat menghasilkan beberapa batch
 * (satu per baris produk). Referensi disimpan sebagai id teks tanpa foreign key agar
 * histori produksi tidak rusak saat master data berubah (pola yang sama dengan order_items).
 */
@Entity(
    tableName = "production_batches",
    indices = [Index("order_id"), Index("status")]
)
data class ProductionBatchEntity(
    @PrimaryKey val id: String,              // UUID
    val order_id: String?,                   // pesanan sumber (boleh null utk produksi internal)
    val product_id: String?,                 // snapshot id produk (jika ada)
    val product_name: String,
    val qty: Long,
    val status: String,                      // ANTRE / PROSES / SELESAI
    val worker_id: String?,                  // pekerja yang ditugaskan
    val due_date: Long?,
    val started_at: Long?,
    val finished_at: Long?,
    val notes: String?,
    val created_at: Long,
    val updated_at: Long,
    val deleted_at: Long? = null,
    val device_id: String,
    val sync_status: String = "PENDING"
)

fun ProductionBatchEntity.toDomain() = ProductionBatch(
    id = id, orderId = order_id, orderCode = null, productId = product_id,
    productName = product_name, qty = qty, status = status,
    workerId = worker_id, workerName = null, dueDate = due_date,
    startedAt = started_at, finishedAt = finished_at, notes = notes,
    createdAt = created_at, updatedAt = updated_at
)
