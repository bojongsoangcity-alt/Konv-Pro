package com.dooyappwork.konveksipro.core.utils

import java.text.DateFormat
import java.util.Date

/**
 * Nilai uang disimpan sebagai INTEGER rupiah (keputusan desain database).
 * Format tampilan: Rp1.250.000 (pemisah ribuan titik, tanpa desimal).
 */
fun formatRupiah(amount: Long): String {
    val negative = amount < 0
    val digits = kotlin.math.abs(amount).toString()
    val sb = StringBuilder()
    digits.forEachIndexed { i, c ->
        sb.append(c)
        val remaining = digits.length - i - 1
        if (remaining > 0 && remaining % 3 == 0) sb.append('.')
    }
    return (if (negative) "-Rp" else "Rp") + sb.toString()
}

fun formatRupiah(amount: Int): String = formatRupiah(amount.toLong())

fun formatDateTime(epochMillis: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(epochMillis))
