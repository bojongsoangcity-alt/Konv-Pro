package com.dooyappwork.konveksipro.data.repository

import androidx.room.withTransaction
import com.dooyappwork.konveksipro.data.local.KonveksiDatabase
import com.dooyappwork.konveksipro.data.local.entities.MaterialEntity
import com.dooyappwork.konveksipro.data.local.entities.MaterialMovementEntity
import com.dooyappwork.konveksipro.data.local.entities.ProductEntity
import com.dooyappwork.konveksipro.data.local.entities.RecipeItemEntity
import com.dooyappwork.konveksipro.data.local.entities.SupplierEntity
import com.dooyappwork.konveksipro.data.local.entities.WorkerEntity
import com.dooyappwork.konveksipro.data.preferences.SettingsRepository
import kotlinx.coroutines.flow.Flow
import java.util.UUID

/**
 * Repository Katalog & Persediaan (Tahap 4): produk + resep bahan (BOM),
 * material + mutasi stok, supplier. Semua tulisan lewat transaksi + audit log.
 */
class CatalogRepository(
    private val db: KonveksiDatabase,
    private val audit: AuditLogRepository,
    private val settings: SettingsRepository
) {
    // ---------- Produk ----------
    fun observeProducts(): Flow<List<ProductEntity>> = db.productDao().observeAll()

    suspend fun saveProduct(
        id: String?, name: String, category: String?, sellPrice: Long, notes: String?,
        laborCost: Long = 0, overheadCost: Long = 0
    ): String {
        require(name.isNotBlank()) { "Nama produk wajib diisi" }
        require(sellPrice >= 0) { "Harga jual tidak boleh negatif" }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        val productId = id ?: UUID.randomUUID().toString()
        db.withTransaction {
            val existing = id?.let { db.productDao().getById(it) }
            db.productDao().upsert(
                ProductEntity(
                    id = productId, name = name.trim(), category = category?.trim()?.ifBlank { null },
                    sell_price = sellPrice,
                    labor_cost = laborCost, overhead_cost = overheadCost,
                    is_active = true, notes = notes?.trim()?.ifBlank { null },
                    created_at = existing?.created_at ?: now, updated_at = now, device_id = deviceId
                )
            )
            audit.log(if (id == null) "CREATE" else "UPDATE", "products", productId, name.trim(), deviceId)
        }
        return productId
    }

    suspend fun deleteProduct(id: String) {
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val rows = db.productDao().softDelete(id, System.currentTimeMillis())
            check(rows == 1) { "Produk tidak ditemukan" }
            audit.log("SOFT_DELETE", "products", id, null, deviceId)
        }
    }

    /** Simpan resep bahan (BOM): hapus lama, tulis baru - validasi kebutuhan > 0. */
    suspend fun saveRecipe(productId: String, rows: List<Pair<String, Double>>) {
        rows.forEach { (materialId, qty) ->
            require(materialId.isNotBlank()) { "Baris resep belum memilih material" }
            require(qty > 0) { "Kebutuhan material harus lebih dari 0" }
        }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            db.recipeDao().deleteByProduct(productId)
            db.recipeDao().insertAll(
                rows.map { (materialId, qty) ->
                    RecipeItemEntity(
                        id = UUID.randomUUID().toString(),
                        product_id = productId, material_id = materialId,
                        qty_per_unit = qty, created_at = now
                    )
                }
            )
            audit.log("UPDATE", "recipe_items", productId, "bom=${rows.size}", deviceId)
        }
    }

    suspend fun recipeOf(productId: String): List<RecipeItemEntity> = db.recipeDao().getByProduct(productId)

    // ---------- Material ----------
    fun observeMaterials(): Flow<List<MaterialEntity>> = db.materialDao().observeAll()

    suspend fun saveMaterial(
        id: String?, name: String, unit: String, stock: Double, minStock: Double,
        buyPrice: Long, supplierId: String?, notes: String?
    ): String {
        require(name.isNotBlank()) { "Nama material wajib diisi" }
        require(unit.isNotBlank()) { "Satuan material wajib diisi (mis. meter, pcs)" }
        require(stock >= 0) { "Stok tidak boleh negatif" }
        require(minStock >= 0) { "Stok minimum tidak boleh negatif" }
        require(buyPrice >= 0) { "Harga beli tidak boleh negatif" }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        val materialId = id ?: UUID.randomUUID().toString()
        db.withTransaction {
            val existing = id?.let { db.materialDao().getById(it) }
            db.materialDao().upsert(
                MaterialEntity(
                    id = materialId, name = name.trim(), unit = unit.trim(),
                    stock = stock, min_stock = minStock, buy_price = buyPrice,
                    supplier_id = supplierId, notes = notes?.trim()?.ifBlank { null },
                    created_at = existing?.created_at ?: now, updated_at = now, device_id = deviceId
                )
            )
            audit.log(if (id == null) "CREATE" else "UPDATE", "materials", materialId, name.trim(), deviceId)
        }
        return materialId
    }

    /** Mutasi stok: positif = barang masuk, negatif = keluar; hasil akhir tidak boleh minus. */
    suspend fun addStock(materialId: String, amount: Double) {
        require(amount != 0.0) { "Perubahan stok tidak boleh 0" }
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val current = db.materialDao().getById(materialId)
                ?: throw IllegalStateException("Material tidak ditemukan")
            val newStock = current.stock + amount
            check(newStock >= 0) { "Stok tidak boleh menjadi minus" }
            db.materialDao().addStock(materialId, amount, System.currentTimeMillis())
            // Tahap 7: setiap mutasi tercatat di buku besar (jejak bisa ditampilkan).
            db.materialMovementDao().insert(
                MaterialMovementEntity(
                    id = UUID.randomUUID().toString(),
                    material_id = materialId,
                    qty_delta = amount,
                    reason = "MANUAL",
                    note = null,
                    batch_id = null,
                    order_id = null,
                    created_at = System.currentTimeMillis(),
                    device_id = deviceId
                )
            )
            audit.log(
                if (amount > 0) "STOCK_IN" else "STOCK_OUT", "materials", materialId,
                "perubahan=$amount", deviceId
            )
        }
    }

    suspend fun deleteMaterial(id: String) {
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val rows = db.materialDao().softDelete(id, System.currentTimeMillis())
            check(rows == 1) { "Material tidak ditemukan" }
            audit.log("SOFT_DELETE", "materials", id, null, deviceId)
        }
    }

    // ---------- Supplier ----------
    fun observeSuppliers(): Flow<List<SupplierEntity>> = db.supplierDao().observeAll()

    suspend fun saveSupplier(id: String?, name: String, phone: String?, address: String?, notes: String?): String {
        require(name.isNotBlank()) { "Nama supplier wajib diisi" }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        val supplierId = id ?: UUID.randomUUID().toString()
        db.withTransaction {
            db.supplierDao().upsert(
                SupplierEntity(
                    id = supplierId, name = name.trim(), phone = phone?.trim()?.ifBlank { null },
                    address = address?.trim()?.ifBlank { null }, notes = notes?.trim()?.ifBlank { null },
                    created_at = now, updated_at = now, device_id = deviceId
                )
            )
            audit.log(if (id == null) "CREATE" else "UPDATE", "suppliers", supplierId, name.trim(), deviceId)
        }
        return supplierId
    }

    suspend fun deleteSupplier(id: String) {
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val rows = db.supplierDao().softDelete(id, System.currentTimeMillis())
            check(rows == 1) { "Supplier tidak ditemukan" }
            audit.log("SOFT_DELETE", "suppliers", id, null, deviceId)
        }
    }
}

/** Repository Supplier (Tahap 7) - melengkapi Master Data; pola sama dengan WorkersRepository. */
class SuppliersRepository(
    private val db: KonveksiDatabase,
    private val audit: AuditLogRepository,
    private val settings: SettingsRepository
) {
    fun observeSuppliers(): Flow<List<SupplierEntity>> = db.supplierDao().observeAll()

    suspend fun saveSupplier(id: String?, name: String, phone: String?, address: String?, notes: String?): String {
        require(name.isNotBlank()) { "Nama supplier wajib diisi" }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        val supplierId = id ?: UUID.randomUUID().toString()
        db.withTransaction {
            db.supplierDao().upsert(
                SupplierEntity(
                    id = supplierId, name = name.trim(), phone = phone?.trim()?.ifBlank { null },
                    address = address?.trim()?.ifBlank { null }, notes = notes?.trim()?.ifBlank { null },
                    created_at = now, updated_at = now, device_id = deviceId
                )
            )
            audit.log(if (id == null) "CREATE" else "UPDATE", "suppliers", supplierId, name.trim(), deviceId)
        }
        return supplierId
    }

    suspend fun deleteSupplier(id: String) {
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val rows = db.supplierDao().softDelete(id, System.currentTimeMillis())
            check(rows == 1) { "Supplier tidak ditemukan" }
            audit.log("SOFT_DELETE", "suppliers", id, null, deviceId)
        }
    }
}

/** Repository Pekerja (Tahap 4) - dipisah agar kebutuhan produksi jelas. */
class WorkersRepository(
    private val db: KonveksiDatabase,
    private val audit: AuditLogRepository,
    private val settings: SettingsRepository
) {
    fun observeWorkers(): Flow<List<WorkerEntity>> = db.workerDao().observeAll()

    suspend fun saveWorker(id: String?, name: String, role: String?, phone: String?, notes: String?): String {
        require(name.isNotBlank()) { "Nama pekerja wajib diisi" }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        val workerId = id ?: UUID.randomUUID().toString()
        db.withTransaction {
            db.workerDao().upsert(
                WorkerEntity(
                    id = workerId, name = name.trim(), role = role?.trim()?.ifBlank { null },
                    phone = phone?.trim()?.ifBlank { null }, notes = notes?.trim()?.ifBlank { null },
                    created_at = now, updated_at = now, device_id = deviceId
                )
            )
            audit.log(if (id == null) "CREATE" else "UPDATE", "workers", workerId, name.trim(), deviceId)
        }
        return workerId
    }

    suspend fun deleteWorker(id: String) {
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val rows = db.workerDao().softDelete(id, System.currentTimeMillis())
            check(rows == 1) { "Pekerja tidak ditemukan" }
            audit.log("SOFT_DELETE", "workers", id, null, deviceId)
        }
    }
}
