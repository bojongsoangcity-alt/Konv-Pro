package com.dooyappwork.konveksipro.feature.orders

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dooyappwork.konveksipro.core.ui.KonveksiTopBar
import com.dooyappwork.konveksipro.core.utils.AppContainer
import com.dooyappwork.konveksipro.domain.logic.OrderCalculator
import com.dooyappwork.konveksipro.domain.model.Customer
import com.dooyappwork.konveksipro.feature.containerFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OrderLineUi(
    val productName: String = "",
    val qty: String = "",
    val price: String = ""
)

data class OrderFormState(
    val customerId: String? = null,
    val customerName: String = "",
    val dueDays: String = "",
    val downPayment: String = "",
    val notes: String = "",
    val lines: List<OrderLineUi> = listOf(OrderLineUi()),
    val saving: Boolean = false,
    val error: String? = null
)

class OrderFormViewModel(private val container: AppContainer) : ViewModel() {
    private val _state = MutableStateFlow(OrderFormState())
    val state: StateFlow<OrderFormState> = _state.asStateFlow()

    val customers: StateFlow<List<Customer>> = container.customerRepository
        .observeCustomers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun update(transform: (OrderFormState) -> OrderFormState) {
        _state.value = transform(_state.value).copy(error = null)
    }

    fun save(onSuccess: () -> Unit) {
        val s = _state.value
        _state.value = s.copy(saving = true, error = null)
        viewModelScope.launch {
            try {
                val lines = s.lines.map {
                    OrderCalculator.LineInput(
                        productName = it.productName,
                        qty = it.qty.toLongOrNull() ?: 0,
                        unitPrice = it.price.toLongOrNull() ?: 0
                    )
                }
                val due = s.dueDays.trim().toLongOrNull()
                    ?.let { days -> System.currentTimeMillis() + days * 86_400_000L }
                container.orderRepository.create(
                    customerId = s.customerId,
                    customerName = s.customerName.ifBlank { "Walk-in" },
                    dueDate = due,
                    notes = s.notes,
                    downPayment = s.downPayment.toLongOrNull() ?: 0,
                    lines = lines
                )
                onSuccess()
            } catch (e: Exception) {
                _state.value = s.copy(saving = false, error = e.message ?: "Gagal menyimpan pesanan")
            }
        }
    }
}

@Composable
fun OrderFormScreen(
    onDone: () -> Unit,
    viewModel: OrderFormViewModel = viewModel(factory = containerFactory { OrderFormViewModel(it) })
) {
    val state by viewModel.state.collectAsState()
    val customers by viewModel.customers.collectAsState()
    var customerMenuOpen by remember { mutableStateOf(false) }

    fun updateLine(index: Int, transform: (OrderLineUi) -> OrderLineUi) {
        viewModel.update { s ->
            s.copy(lines = s.lines.mapIndexed { i, l -> if (i == index) transform(l) else l })
        }
    }

    Scaffold(topBar = { KonveksiTopBar("Pesanan Baru", "Batch produksi dibuat otomatis", onDone) }) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("Pelanggan", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            Box {
                OutlinedButton(onClick = { customerMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(state.customerName.ifBlank { "Pilih pelanggan / Walk-in" })
                }
                DropdownMenu(expanded = customerMenuOpen, onDismissRequest = { customerMenuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Walk-in (tanpa data pelanggan)") },
                        onClick = {
                            viewModel.update { it.copy(customerId = null, customerName = "Walk-in") }
                            customerMenuOpen = false
                        }
                    )
                    customers.forEach { c ->
                        DropdownMenuItem(
                            text = { Text(c.name) },
                            onClick = {
                                viewModel.update { it.copy(customerId = c.id, customerName = c.name) }
                                customerMenuOpen = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Baris pesanan", style = MaterialTheme.typography.titleSmall)
            state.lines.forEachIndexed { index, line ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        OutlinedTextField(
                            value = line.productName,
                            onValueChange = { v -> updateLine(index) { it.copy(productName = v) } },
                            label = { Text("Nama produk / jenis pajangan *") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = line.qty,
                                onValueChange = { v -> updateLine(index) { it.copy(qty = v.filter { c -> c.isDigit() }) } },
                                label = { Text("Qty") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = line.price,
                                onValueChange = { v -> updateLine(index) { it.copy(price = v.filter { c -> c.isDigit() }) } },
                                label = { Text("Harga satuan (Rp)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(2f)
                            )
                            IconButton(
                                onClick = {
                                    viewModel.update { s ->
                                        if (s.lines.size > 1) s.copy(lines = s.lines.filterIndexed { i, _ -> i != index }) else s
                                    }
                                },
                                enabled = state.lines.size > 1
                            ) {
                                Icon(Icons.Filled.Delete, contentDescription = "Hapus baris")
                            }
                        }
                    }
                }
            }
            TextButton(onClick = { viewModel.update { it.copy(lines = it.lines + OrderLineUi()) } }) {
                Text("+ Tambah baris")
            }

            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = state.downPayment,
                onValueChange = { v -> viewModel.update { it.copy(downPayment = v.filter { c -> c.isDigit() }) } },
                label = { Text("Uang muka / DP (Rp)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = state.dueDays,
                onValueChange = { v -> viewModel.update { it.copy(dueDays = v.filter { c -> c.isDigit() }) } },
                label = { Text("Tenggat pengerjaan (hari dari sekarang)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = state.notes,
                onValueChange = { v -> viewModel.update { it.copy(notes = v) } },
                label = { Text("Catatan") },
                modifier = Modifier.fillMaxWidth()
            )

            state.error?.let { err ->
                Spacer(Modifier.height(8.dp))
                Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { viewModel.save(onDone) },
                enabled = !state.saving,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (state.saving) "Menyimpan..." else "Simpan Pesanan")
            }
        }
    }
}
