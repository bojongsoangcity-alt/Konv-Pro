package com.dooyappwork.konveksipro.ai.transport

import com.dooyappwork.konveksipro.ai.model.FailureKind
import com.dooyappwork.konveksipro.ai.security.SecretRedactor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException
import java.net.SocketTimeoutException
import javax.net.ssl.SSLException

/** Hasil transport mentah. Tidak pernah memuat header request (berisi kredensial). */
sealed interface HttpOutcome {
    data class Response(val status: Int, val body: String) : HttpOutcome
    data class NetworkError(val kind: FailureKind, val safeDetail: String) : HttpOutcome
}

/** Kontrak transport agar adapter bisa diuji tanpa jaringan nyata. */
interface JsonTransport {
    suspend fun postJson(url: String, headers: Map<String, String>, body: String, timeoutMs: Long): HttpOutcome
}

/**
 * Transport HTTP ringan memakai HttpURLConnection (tanpa dependensi tambahan).
 * Aturan: header kredensial hanya dikirim, TIDAK pernah dicatat.
 */
class HttpJsonTransport : JsonTransport {

    override suspend fun postJson(
        url: String,
        headers: Map<String, String>,
        body: String,
        timeoutMs: Long
    ): HttpOutcome = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = timeoutMs.toInt().coerceIn(1_000, 60_000)
                readTimeout = timeoutMs.toInt().coerceIn(1_000, 60_000)
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                headers.forEach { (k, v) -> setRequestProperty(k, v) }
            }
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.let { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { it.readText() }
            } ?: ""
            HttpOutcome.Response(status, text)
        } catch (e: SocketTimeoutException) {
            HttpOutcome.NetworkError(FailureKind.TIMEOUT, SecretRedactor.safeDetail(e.message))
        } catch (e: UnknownHostException) {
            HttpOutcome.NetworkError(FailureKind.NO_NETWORK, "host tidak ditemukan")
        } catch (e: SSLException) {
            HttpOutcome.NetworkError(FailureKind.SERVER_ERROR, "TLS gagal: ${SecretRedactor.safeDetail(e.message)}")
        } catch (e: Exception) {
            HttpOutcome.NetworkError(
                FailureKind.NO_NETWORK,
                SecretRedactor.safeDetail("${e.javaClass.simpleName}: ${e.message}")
            )
        } finally {
            connection?.disconnect()
        }
    }
}
