package com.dooyappwork.konveksipro.ai

import com.dooyappwork.konveksipro.ai.security.SecretRedactor

/**
 * Membersihkan narasi dari provider: buang pagar markdown, sensor kredensial
 * yang mungkin terpantul, batasi panjang, dan pecah menjadi poin.
 */
class AIResponseParser(private val maxChars: Int = 1_600) {

    fun clean(raw: String): String {
        var text = raw.trim()
        text = text.removePrefix("```markdown").removePrefix("```md").removePrefix("```")
        if (text.endsWith("```")) text = text.dropLast(3)
        text = SecretRedactor.redact(text)
        return text.trim().take(maxChars)
    }

    fun toBullets(raw: String): List<String> =
        clean(raw)
            .lines()
            .map { it.trim().removePrefix("-").removePrefix("*").trim() }
            .filter { it.isNotEmpty() }
            .take(8)

    /** true jika jawaban memuat angka yang TIDAK ada pada fakta lokal (indikasi halusinasi). */
    fun introducesUnknownNumbers(narrative: String, knownNumbers: Set<String>): Boolean {
        val numbers = Regex("\\b\\d{1,3}(?:\\.\\d{3})*(?:,\\d+)?\\b")
            .findAll(narrative)
            .map { it.value }
            .toList()
        return numbers.any { n -> n.length > 1 && knownNumbers.none { it == n || it.contains(n) } }
    }
}
