package com.dooyappwork.konveksipro.feature.customers

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dooyappwork.konveksipro.core.ui.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomersScreen(
    onAddCustomer: () -> Unit,
    onBack: () -> Unit,
    viewModel: CustomersViewModel = viewModel(factory = com.dooyappwork.konveksipro.feature.containerFactory { CustomersViewModel(it) })
) {
    val state by viewModel.state.collectAsState()
    var pendingDelete by remember { mutableStateOf<com.dooyappwork.konveksipro.domain.model.Customer?>(null) }

    pendingDelete?.let { customer ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Hapus pelanggan?") },
            text = { Text("Data '${customer.name}' akan diarsipkan (soft delete). Riwayat transaksi tetap konsisten.") },
            confirmButton = {
                TextButton(onClick = { viewModel.delete(customer); pendingDelete = null }) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Batal") } }
        )
    }

    Scaffold(
        topBar = { KonveksiTopBar("Pelanggan", "Master data pelanggan", onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddCustomer,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Tambah") }
            )
        }
    ) { padding ->
        when {
            state.isLoading -> LoadingState(Modifier.padding(padding))
            state.error != null -> ErrorState(state.error ?: "", Modifier.padding(padding))
            state.customers.isEmpty() -> EmptyState(
                "Belum ada pelanggan.\nKetuk tombol Tambah untuk membuat data pertama.",
                Modifier.padding(padding)
            )
            else -> LazyColumn(Modifier.padding(padding).fillMaxSize()) {
                items(state.customers, key = { it.id }) { customer ->
                    Card(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Row(
                            Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(customer.name, fontWeight = FontWeight.SemiBold)
                                if (!customer.phone.isNullOrBlank()) {
                                    Text(
                                        customer.phone,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            IconButton(onClick = { pendingDelete = customer }) {
                                Icon(
                                    Icons.Filled.Delete,
                                    contentDescription = "Hapus",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
