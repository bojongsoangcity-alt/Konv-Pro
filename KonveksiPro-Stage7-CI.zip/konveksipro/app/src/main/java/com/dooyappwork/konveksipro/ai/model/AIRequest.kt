package com.dooyappwork.konveksipro.ai.model

/** Permintaan AI yang sudah dinormalisasi (dipakai semua adapter). */
data class AIRequest(
    val purpose: InsightKind,
    val prompt: String,
    val systemInstruction: String? = null,
    val maxOutputTokens: Int = 512,
    val temperature: Double = 0.2,
    val correlationId: String = ""
)
