package com.dooyappwork.konveksipro.feature.catalog

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dooyappwork.konveksipro.core.ui.*
import com.dooyappwork.konveksipro.core.utils.formatRupiah
import com.dooyappwork.konveksipro.data.local.entities.MaterialEntity
import com.dooyappwork.konveksipro.data.local.entities.SupplierEntity
import com.dooyappwork.konveksipro.data.local.entities.ProductEntity
import com.dooyappwork.konveksipro.data.local.entities.WorkerEntity

@Composable
private fun ErrorBar(message: String?, onTimeout: () -> Unit) {
    val msg = message
    LaunchedEffect(msg) {
        if (msg != null) { kotlinx.coroutines.delay(3000); onTimeout() }
    }
    if (msg != null) {
        Text(
            msg, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall
        )
    }
}

// ============================= PRODUK =============================

@Composable
fun ProductsScreen(onBack: () -> Unit, vm: CatalogViewModel = viewModel(factory = CatalogViewModel.factory())) {
    val products by vm.products.collectAsState()
    val message by vm.message.collectAsState()
    var editing by remember { mutableStateOf<ProductEntity?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<ProductEntity?>(null) }

    if (showForm) {
        ProductFormDialog(
            initial = editing,
            onDismiss = { showForm = false },
            onSave = { name, cat, price, labor, overhead, notes ->
                vm.saveProduct(editing?.id, name, cat, price, notes, labor, overhead)
                showForm = false
            }
        )
    }
    pendingDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Hapus produk?") },
            text = { Text("'${p.name}' diarsipkan. Pesanan lama tidak terpengaruh (nama produk tersimpan sebagai snapshot).") },
            confirmButton = {
                TextButton(onClick = { vm.deleteProduct(p); pendingDelete = null }) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Batal") } }
        )
    }

    Scaffold(
        topBar = { KonveksiTopBar("Produk", "Katalog & harga jual", onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { editing = null; showForm = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Produk") }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            ErrorBar(message) { vm.clearMessage() }
            if (products.isEmpty()) {
                EmptyState("Belum ada produk.\nTambahkan produk untuk mulai menghitung HPP material.", Modifier.padding(padding))
            } else {
                LazyColumn {
                    items(products, key = { it.id }) { p ->
                        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.SemiBold)
                                    val extra = p.labor_cost + p.overhead_cost
                                    Text(
                                        (p.category ?: "Tanpa kategori") + " • " + formatRupiah(p.sell_price) +
                                            if (extra > 0) " • Upah+ovh " + formatRupiah(extra) else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { editing = p; showForm = true }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Ubah")
                                }
                                IconButton(onClick = { pendingDelete = p }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductFormDialog(initial: ProductEntity?, onDismiss: () -> Unit, onSave: (String, String, String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "") }
    var price by remember { mutableStateOf(if (initial == null) "" else initial.sell_price.toString()) }
    var labor by remember { mutableStateOf(if (initial == null) "" else initial.labor_cost.toString()) }
    var overhead by remember { mutableStateOf(if (initial == null) "" else initial.overhead_cost.toString()) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Produk Baru" else "Ubah Produk") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama produk *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Kategori") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = price, onValueChange = { price = it.filter { c -> c.isDigit() } },
                    label = { Text("Harga jual (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "HPP per unit = material (dari resep bahan) + upah + overhead. Upah/overhead boleh dibiarkan 0.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = labor, onValueChange = { labor = it.filter { c -> c.isDigit() } },
                    label = { Text("Upah per unit (Rp, opsional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = overhead, onValueChange = { overhead = it.filter { c -> c.isDigit() } },
                    label = { Text("Overhead per unit (Rp, opsional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) error = "Nama produk wajib diisi"
                else onSave(name, category, price, labor, overhead, notes)
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

// ============================= MATERIAL =============================

@Composable
fun MaterialsScreen(onBack: () -> Unit, vm: CatalogViewModel = viewModel(factory = CatalogViewModel.factory())) {
    val materials by vm.materials.collectAsState()
    val movements by vm.movements.collectAsState()
    val message by vm.message.collectAsState()
    var editing by remember { mutableStateOf<MaterialEntity?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var stockTarget by remember { mutableStateOf<MaterialEntity?>(null) }
    var pendingDelete by remember { mutableStateOf<MaterialEntity?>(null) }
    var showLedger by remember { mutableStateOf(false) }

    if (showForm) {
        MaterialFormDialog(
            initial = editing,
            onDismiss = { showForm = false },
            onSave = { name, unit, stock, minStock, price, notes ->
                vm.saveMaterial(editing?.id, name, unit, stock, minStock, price, notes)
                showForm = false
            }
        )
    }
    stockTarget?.let { m ->
        StockMutationDialog(
            name = m.name, unit = m.unit,
            onDismiss = { stockTarget = null },
            onSave = { amount, income ->
                vm.addStock(m, amount, income)
                stockTarget = null
            }
        )
    }
    pendingDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Hapus material?") },
            text = { Text("'${m.name}' diarsipkan. Resep bahan yang mengarah ke material ini tetap tersimpan.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteMaterial(m); pendingDelete = null }) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Batal") } }
        )
    }

    if (showLedger) {
        StockLedgerDialog(movements = movements, materials = materials, onDismiss = { showLedger = false })
    }

    Scaffold(
        topBar = { KonveksiTopBar("Material", "Stok bahan & persediaan", onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { editing = null; showForm = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Material") }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            ErrorBar(message) { vm.clearMessage() }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = { showLedger = true }) { Text("Buku Stok") }
            }
            if (materials.isEmpty()) {
                EmptyState("Belum ada material.\nDaftarkan kain, aksesoris, dan bahan lain beserta stoknya.", Modifier.padding(padding))
            } else {
                LazyColumn {
                    items(materials, key = { it.id }) { m ->
                        val below = m.stock < m.min_stock
                        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(m.name, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "Stok ${m.stock} ${m.unit}" +
                                            " • Min ${m.min_stock} • Harga beli " + formatRupiah(m.buy_price),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (below) {
                                        Text(
                                            "Di bawah stok minimum",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                                TextButton(onClick = { stockTarget = m }) { Text("Mutasi") }
                                IconButton(onClick = { editing = m; showForm = true }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Ubah")
                                }
                                IconButton(onClick = { pendingDelete = m }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MaterialFormDialog(initial: MaterialEntity?, onDismiss: () -> Unit, onSave: (String, String, String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var unit by remember { mutableStateOf(initial?.unit ?: "") }
    var stock by remember { mutableStateOf(if (initial == null) "" else initial.stock.toString()) }
    var minStock by remember { mutableStateOf(if (initial == null) "" else initial.min_stock.toString()) }
    var price by remember { mutableStateOf(if (initial == null) "" else initial.buy_price.toString()) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Material Baru" else "Ubah Material") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama material *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Satuan * (meter/pcs/kg)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = stock, onValueChange = { stock = it }, label = { Text("Stok saat ini") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = minStock, onValueChange = { minStock = it }, label = { Text("Stok minimum") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = price, onValueChange = { price = it.filter { c -> c.isDigit() } },
                    label = { Text("Harga beli per satuan (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    name.isBlank() -> error = "Nama material wajib diisi"
                    unit.isBlank() -> error = "Satuan wajib diisi"
                    else -> onSave(name, unit, stock, minStock, price, notes)
                }
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun StockMutationDialog(name: String, unit: String, onDismiss: () -> Unit, onSave: (String, Boolean) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var income by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mutasi stok - $name") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = income, onClick = { income = true }, label = { Text("Masuk") })
                    FilterChip(selected = !income, onClick = { income = false }, label = { Text("Keluar") })
                }
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it },
                    label = { Text("Jumlah ($unit)") }, modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(amount, income) }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
private fun StockLedgerDialog(
    movements: List<com.dooyappwork.konveksipro.data.local.entities.MaterialMovementEntity>,
    materials: List<MaterialEntity>,
    onDismiss: () -> Unit
) {
    val nameById = remember(materials) { materials.associate { it.id to it.name } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Buku Stok (50 mutasi terakhir)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (movements.isEmpty()) {
                    Text("Belum ada mutasi tercatat.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                movements.forEach { m ->
                    Text(
                        (nameById[m.material_id] ?: m.material_id) +
                            " • " + (if (m.qty_delta >= 0) "+" else "") + m.qty_delta +
                            " • " + m.reason,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup") } }
    )
}

// ============================= SUPPLIER (TAHAP 7) =============================

@Composable
fun SuppliersScreen(onBack: () -> Unit, vm: CatalogViewModel = viewModel(factory = CatalogViewModel.factory())) {
    val suppliers by vm.suppliers.collectAsState()
    val message by vm.message.collectAsState()
    var editing by remember { mutableStateOf<SupplierEntity?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<SupplierEntity?>(null) }

    if (showForm) {
        SupplierFormDialog(
            initial = editing,
            onDismiss = { showForm = false },
            onSave = { name, phone, address, notes ->
                vm.saveSupplier(editing?.id, name, phone, address, notes)
                showForm = false
            }
        )
    }
    pendingDelete?.let { s ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Hapus supplier?") },
            text = { Text("'${s.name}' diarsipkan. Material yang menunjuk ke supplier ini tetap tersimpan.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteSupplier(s); pendingDelete = null }) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Batal") } }
        )
    }

    Scaffold(
        topBar = { KonveksiTopBar("Supplier", "Pemasok material", onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { editing = null; showForm = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Supplier") }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            ErrorBar(message) { vm.clearMessage() }
            if (suppliers.isEmpty()) {
                EmptyState("Belum ada supplier.\nDaftarkan pemasok material utama Anda.", Modifier.padding(padding))
            } else {
                LazyColumn {
                    items(suppliers, key = { it.id }) { s ->
                        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(s.name, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        (s.phone ?: "Tanpa telepon") + (s.address?.let { " • $it" } ?: ""),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { editing = s; showForm = true }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Ubah")
                                }
                                IconButton(onClick = { pendingDelete = s }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SupplierFormDialog(initial: SupplierEntity?, onDismiss: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var address by remember { mutableStateOf(initial?.address ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Supplier Baru" else "Ubah Supplier") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama supplier *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = phone, onValueChange = { phone = it }, label = { Text("Telepon") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Alamat") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) error = "Nama supplier wajib diisi"
                else onSave(name, phone, address, notes)
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

// ============================= PEKERJA =============================

@Composable
fun WorkersScreen(onBack: () -> Unit, vm: CatalogViewModel = viewModel(factory = CatalogViewModel.factory())) {
    val workers by vm.workers.collectAsState()
    val message by vm.message.collectAsState()
    var editing by remember { mutableStateOf<WorkerEntity?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<WorkerEntity?>(null) }

    if (showForm) {
        WorkerFormDialog(
            initial = editing,
            onDismiss = { showForm = false },
            onSave = { name, role, phone, notes ->
                vm.saveWorker(editing?.id, name, role, phone, notes)
                showForm = false
            }
        )
    }
    pendingDelete?.let { w ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Hapus pekerja?") },
            text = { Text("'${w.name}' diarsipkan. Riwayat produksi tetap tersimpan.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteWorker(w); pendingDelete = null }) {
                    Text("Hapus", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Batal") } }
        )
    }

    Scaffold(
        topBar = { KonveksiTopBar("Pekerja", "Tenaga kerja produksi", onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { editing = null; showForm = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Pekerja") }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            ErrorBar(message) { vm.clearMessage() }
            if (workers.isEmpty()) {
                EmptyState("Belum ada pekerja.\nDaftarkan tenaga kerja agar batch produksi bisa ditugaskan.", Modifier.padding(padding))
            } else {
                LazyColumn {
                    items(workers, key = { it.id }) { w ->
                        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(w.name, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        (w.role ?: "Tanpa posisi") + (w.phone?.let { " • $it" } ?: ""),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { editing = w; showForm = true }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Ubah")
                                }
                                IconButton(onClick = { pendingDelete = w }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkerFormDialog(initial: WorkerEntity?, onDismiss: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var role by remember { mutableStateOf(initial?.role ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Pekerja Baru" else "Ubah Pekerja") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama pekerja *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Posisi (Cutting/Sewing/QC)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = phone, onValueChange = { phone = it },
                    label = { Text("Telepon") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Catatan") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) error = "Nama pekerja wajib diisi"
                else onSave(name, role, phone, notes)
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

// ============================= PROFIL BISNIS =============================

@Composable
fun BusinessProfileScreen(onDone: () -> Unit, vm: CatalogViewModel = viewModel(factory = CatalogViewModel.factory())) {
    val profile by vm.profile.collectAsState()
    var name by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    // Pre-fill dari data tersimpan (sekali saja per entry layar).
    LaunchedEffect(profile?.id) {
        profile?.let {
            name = it.business_name
            owner = it.owner_name ?: ""
            phone = it.phone ?: ""
            address = it.address ?: ""
        }
    }

    Scaffold(topBar = { KonveksiTopBar("Profil Bisnis", "Identitas usaha pada laporan", onDone) }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama usaha *") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = owner, onValueChange = { owner = it }, label = { Text("Nama pemilik") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = phone, onValueChange = { phone = it }, label = { Text("Telepon") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Alamat") }, modifier = Modifier.fillMaxWidth())
            error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    if (name.isBlank()) error = "Nama usaha wajib diisi"
                    else { vm.saveProfile(name, owner, phone, address); onDone() }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Simpan Profil") }
            Spacer(Modifier.height(16.dp))
            Text(
                if (profile != null) "Perubahan langsung terpakai pada identitas laporan usaha."
                else "Data ini dipakai pada laporan dan identitas dokumen usaha.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
