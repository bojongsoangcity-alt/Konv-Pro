package com.dooyappwork.konveksipro.core.theme

import androidx.compose.ui.graphics.Color

/**
 * Palet brand KonveksiPro - disetujui di STAGE 0 (diambil dari logo KonveksiPro).
 * Kontras terverifikasi (WCAG):
 *  - Putih di atas Navy900  = 15.78:1 (AA normal)
 *  - Navy900 di atas Light  = 14.28:1 (AA normal)
 *  - Putih di atas Blue800  = 5.75:1  (AA normal) -> onPrimary memakai putih di light theme
 *  - NavyInk di atas ElectricBlue = 4.67:1 (AA normal) -> teks normal di atas aksen biru
 *  - Navy900 di atas Orange = 5.59:1  (AA normal) -> PENTING: jangan pakai putih di atas oranye (2.82:1 FAIL)
 */
val Navy900 = Color(0xFF0E2244)        // Primary brand (navy)
val Navy800 = Color(0xFF11284E)        // Surface gelap
val NavyInk = Color(0xFF061C33)        // Teks di atas electric blue
val ElectricBlue = Color(0xFF1E88E5)   // Aksen utama
val Blue800 = Color(0xFF1565C0)        // Primary pada tema terang (kontras aman)
val BlueTint = Color(0xFFA9CBFA)       // Primary pada tema gelap
val BlueContainerLight = Color(0xFFD6E9FC)
val Orange500 = Color(0xFFFF6D00)      // Aksen sekunder
val OrangeTint = Color(0xFFFF9E40)     // Oranye pada tema gelap
val OrangeContainerLight = Color(0xFFFFE2CC)
val LightSurface = Color(0xFFF0F4F8)   // Background terang bersih
val LightBackground = Color(0xFFE7EEF6)
val SurfaceVariantLight = Color(0xFFDCE6F2)
val OnSurfaceVariantLight = Color(0xFF41546E)
val DarkSurface = Color(0xFF0F2138)
val DarkBackground = Color(0xFF0B1830)
val DarkSurfaceVariant = Color(0xFF1A2F4A)
val OnSurfaceVariantDark = Color(0xFFB4C3D8)
val TextOnDark = Color(0xFFE6EDF7)
val ErrorRed = Color(0xFFBA1A1A)
