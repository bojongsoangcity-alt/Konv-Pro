package com.dooyappwork.konveksipro.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.dooyappwork.konveksipro.domain.model.OrderItem

/** Baris pesanan. Tidak memakai foreign key ke produk agar pesanan lama tetap utuh saat katalog berubah. */
@Entity(
    tableName = "order_items",
    indices = [Index("order_id")]
)
data class OrderItemEntity(
    @PrimaryKey val id: String,              // UUID
    val order_id: String,
    val product_name: String,                // snapshot teks
    val qty: Long,
    val unit_price: Long,                    // rupiah per unit
    val note: String?,
    val created_at: Long
)

fun OrderItemEntity.toDomain() = OrderItem(
    id = id, orderId = order_id, productName = product_name,
    qty = qty, unitPrice = unit_price, note = note, createdAt = created_at
)
