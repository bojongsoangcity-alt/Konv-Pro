package com.dooyappwork.konveksipro.data.repository

import androidx.room.withTransaction
import com.dooyappwork.konveksipro.data.local.KonveksiDatabase
import com.dooyappwork.konveksipro.data.local.entities.ProductionBatchEntity
import com.dooyappwork.konveksipro.data.local.entities.toDomain
import com.dooyappwork.konveksipro.data.preferences.SettingsRepository
import com.dooyappwork.konveksipro.domain.model.ProductionBatch
import com.dooyappwork.konveksipro.domain.model.ProductionStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

/**
 * Repository Produksi (Tahap 3): batch ANTRE -> PROSES -> SELESAI.
 * Batch pesanan dibuat otomatis oleh OrderRepository; di sini pengguna menjalankan,
 * menugaskan pekerja, menyelesaikan, dan membuat produksi internal (stok rutin).
 */
class ProductionRepository(
    private val db: KonveksiDatabase,
    private val audit: AuditLogRepository,
    private val settings: SettingsRepository
) {
    fun observeBatches(): Flow<List<ProductionBatch>> =
        db.productionDao().observeAll().map { list -> list.map { it.toDomain() } }

    fun observeActiveCount(): Flow<Int> = db.productionDao().observeActiveCount()

    /** Buat batch produksi internal (tanpa pesanan), mis. penambahan stok rutin. */
    suspend fun createInternal(productName: String, qty: Long, dueDate: Long?): String {
        require(productName.isNotBlank()) { "Nama produk wajib diisi" }
        require(qty > 0) { "Jumlah produksi harus lebih dari 0" }
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        val id = UUID.randomUUID().toString()
        db.withTransaction {
            db.productionDao().insertBatches(
                listOf(
                    ProductionBatchEntity(
                        id = id, order_id = null, product_id = null,
                        product_name = productName.trim(), qty = qty,
                        status = ProductionStatus.ANTRE, worker_id = null,
                        due_date = dueDate, started_at = null, finished_at = null,
                        notes = "Produksi internal",
                        created_at = now, updated_at = now, device_id = deviceId
                    )
                )
            )
            audit.log("CREATE", "production_batches", id, "internal", deviceId)
        }
        return id
    }

    /** Tetapkan / ganti pekerja pada batch (batch selesai tidak bisa diubah). */
    suspend fun assignWorker(batchId: String, workerId: String?, workerName: String?) {
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val rows = db.productionDao().assignWorker(batchId, workerId, now)
            check(rows == 1) { "Batch tidak ditemukan atau sudah selesai" }
            audit.log("UPDATE", "production_batches", batchId, "pekerja=${workerName ?: "-"}", deviceId)
        }
    }

    suspend fun start(batchId: String) {
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val rows = db.productionDao().markStarted(batchId, now)
            check(rows == 1) { "Batch hanya bisa dimulai dari status Antre" }
            audit.log("UPDATE", "production_batches", batchId, "status=PROSES", deviceId)
        }
    }

    suspend fun finish(batchId: String) {
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val rows = db.productionDao().markFinished(batchId, now)
            check(rows == 1) { "Batch hanya bisa diselesaikan dari status Proses" }
            audit.log("UPDATE", "production_batches", batchId, "status=SELESAI", deviceId)
        }
    }

    /**
     * Tandai seluruh batch pesanan selesai lalu naikkan status pesanan ke SELESAI.
     * Dipakai tombol "Selesaikan Produksi" pada detail pesanan berstatus Diproduksi.
     */
    suspend fun finishOrder(orderId: String) {
        val now = System.currentTimeMillis()
        val deviceId = settings.getInstallationId()
        db.withTransaction {
            val order = db.orderDao().getById(orderId)
                ?: throw IllegalStateException("Pesanan tidak ditemukan")
            check(order.status == "DIPRODUKSI") {
                "Produksi hanya bisa diselesaikan pada pesanan berstatus Diproduksi"
            }
            val rows = db.productionDao().finishByOrder(orderId, now)
            check(rows > 0) { "Tidak ada batch produksi untuk pesanan ini" }
            db.orderDao().updateStatus(orderId, "SELESAI", now)
            audit.log("UPDATE", "orders", orderId, "produksi_selesai", deviceId)
        }
    }
}
