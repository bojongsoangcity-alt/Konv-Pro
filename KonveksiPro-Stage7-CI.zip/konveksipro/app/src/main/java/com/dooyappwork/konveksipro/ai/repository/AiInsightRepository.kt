package com.dooyappwork.konveksipro.ai.repository

import com.dooyappwork.konveksipro.ai.data.AiInsightDao
import com.dooyappwork.konveksipro.ai.data.AiInsightEntity
import com.dooyappwork.konveksipro.ai.model.InsightReport
import com.dooyappwork.konveksipro.data.preferences.SettingsRepository
import com.dooyappwork.konveksipro.ai.util.JsonWriter
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class AiInsightRepository(
    private val dao: AiInsightDao,
    private val settings: SettingsRepository
) {
    fun observeRecent(limit: Int = 20): Flow<List<AiInsightEntity>> = dao.observeRecent(limit)
    fun observeCount(): Flow<Int> = dao.observeCount()

    suspend fun save(report: InsightReport, narrative: String?, providerId: String?, tokens: Int) {
        val metrics = report.metrics.joinToString(",", "[", "]") { m ->
            JsonWriter.obj("label" to m.label, "value" to m.value)
        }
        dao.insert(
            AiInsightEntity(
                id = UUID.randomUUID().toString(),
                kind = report.kind.name,
                source = if (narrative.isNullOrBlank()) "LOCAL" else "EXTERNAL",
                provider_id = providerId,
                headline = report.headline,
                narrative = narrative,
                metrics_json = metrics,
                tokens = tokens,
                created_at = System.currentTimeMillis(),
                device_id = settings.getInstallationId()
            )
        )
    }

    suspend fun pruneOlderThan(days: Int = 90): Int =
        dao.deleteOlderThan(System.currentTimeMillis() - days * 86_400_000L)
}
