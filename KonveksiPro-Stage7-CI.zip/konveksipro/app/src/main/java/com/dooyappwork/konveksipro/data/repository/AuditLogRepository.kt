package com.dooyappwork.konveksipro.data.repository

import com.dooyappwork.konveksipro.data.local.KonveksiDatabase
import com.dooyappwork.konveksipro.data.local.entities.AuditLogEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class AuditLogRepository(private val db: KonveksiDatabase) {

    fun observeRecent(limit: Int = 20): Flow<List<AuditLogEntity>> =
        db.auditLogDao().observeRecent(limit)

    suspend fun log(
        action: String,
        entityType: String,
        entityId: String?,
        detail: String?,
        deviceId: String
    ) {
        db.auditLogDao().insert(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                actor = "owner",
                action = action,
                entity_type = entityType,
                entity_id = entityId,
                detail = detail,
                device_id = deviceId,
                created_at = System.currentTimeMillis()
            )
        )
    }
}
