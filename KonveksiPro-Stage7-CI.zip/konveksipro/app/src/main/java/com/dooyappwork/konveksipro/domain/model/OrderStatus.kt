package com.dooyappwork.konveksipro.domain.model

/**
 * Konstanta status pesanan / pembayaran / produksi.
 * Disimpan sebagai TEXT di Room (pola sama dengan sync_status pada entitas lama).
 * Tidak ada enum Room baru agar migrasi tetap sederhana dan tampilan mudah diterjemahkan.
 */

object OrderStatus {
    const val BARU = "BARU"
    const val DIPRODUKSI = "DIPRODUKSI"
    const val SELESAI = "SELESAI"
    const val DIBATALKAN = "DIBATALKAN"

    fun label(status: String): String = when (status) {
        BARU -> "Baru"
        DIPRODUKSI -> "Diproduksi"
        SELESAI -> "Selesai"
        DIBATALKAN -> "Dibatalkan"
        else -> status
    }
}

object PaymentStatus {
    const val BELUM_LUNAS = "BELUM_LUNAS"
    const val LUNAS = "LUNAS"

    fun label(status: String): String = if (status == LUNAS) "Lunas" else "Belum lunas"
}

object ProductionStatus {
    const val ANTRE = "ANTRE"
    const val PROSES = "PROSES"
    const val SELESAI = "SELESAI"

    fun label(status: String): String = when (status) {
        ANTRE -> "Antre"
        PROSES -> "Proses"
        SELESAI -> "Selesai"
        else -> status
    }
}
