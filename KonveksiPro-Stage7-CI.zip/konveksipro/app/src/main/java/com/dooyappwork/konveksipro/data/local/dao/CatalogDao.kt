package com.dooyappwork.konveksipro.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dooyappwork.konveksipro.data.local.entities.MaterialEntity
import com.dooyappwork.konveksipro.data.local.entities.MaterialMovementEntity
import com.dooyappwork.konveksipro.data.local.entities.ProductEntity
import com.dooyappwork.konveksipro.data.local.entities.RecipeItemEntity
import com.dooyappwork.konveksipro.data.local.entities.SupplierEntity
import com.dooyappwork.konveksipro.data.local.entities.WorkerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE deleted_at IS NULL ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id AND deleted_at IS NULL")
    suspend fun getById(id: String): ProductEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(product: ProductEntity)

    @Query("UPDATE products SET deleted_at = :now, updated_at = :now, sync_status = 'PENDING' WHERE id = :id")
    suspend fun softDelete(id: String, now: Long): Int

    @Query("SELECT COUNT(*) FROM products WHERE deleted_at IS NULL AND is_active = 1")
    suspend fun countActive(): Int

    /** Total upah + overhead per unit seluruh produk aktif (pelengkap HPP Tahap 7). */
    @Query("SELECT COALESCE(SUM(labor_cost + overhead_cost), 0) FROM products WHERE deleted_at IS NULL AND is_active = 1")
    suspend fun sumActiveLaborOverhead(): Long

    @Query("SELECT COUNT(*) FROM products p WHERE p.deleted_at IS NULL AND p.is_active = 1 AND NOT EXISTS (SELECT 1 FROM recipe_items r WHERE r.product_id = p.id)")
    suspend fun countWithoutRecipe(): Int

    @Query("SELECT COALESCE(SUM(sell_price), 0) FROM products WHERE deleted_at IS NULL AND is_active = 1")
    suspend fun sumActiveSellPrice(): Long

    /** Total biaya material seluruh produk aktif (basis margin portofolio). */
    @Query("SELECT COALESCE(SUM(cost), 0) FROM (SELECT COALESCE((SELECT SUM(ROUND(r.qty_per_unit * m.buy_price)) FROM recipe_items r JOIN materials m ON m.id = r.material_id WHERE r.product_id = p.id), 0) AS cost FROM products p WHERE p.deleted_at IS NULL AND p.is_active = 1)")
    suspend fun sumActiveMaterialCost(): Long

    /** Produk aktif dengan margin material terendah (nama + margin %, untuk analisis HPP). */
    @Query("SELECT p.name FROM products p WHERE p.deleted_at IS NULL AND p.is_active = 1 AND EXISTS (SELECT 1 FROM recipe_items r WHERE r.product_id = p.id) ORDER BY (p.sell_price - COALESCE((SELECT SUM(ROUND(r.qty_per_unit * m.buy_price)) FROM recipe_items r JOIN materials m ON m.id = r.material_id WHERE r.product_id = p.id), 0)) * 100.0 / p.sell_price LIMIT :limit")
    suspend fun lowestMarginNames(limit: Int): List<String>
}

@Dao
interface RecipeDao {
    @Query("SELECT * FROM recipe_items WHERE product_id = :productId")
    suspend fun getByProduct(productId: String): List<RecipeItemEntity>

    @Insert
    suspend fun insertAll(items: List<RecipeItemEntity>)

    @Query("DELETE FROM recipe_items WHERE product_id = :productId")
    suspend fun deleteByProduct(productId: String): Int
}

@Dao
interface MaterialDao {
    @Query("SELECT * FROM materials WHERE deleted_at IS NULL ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<MaterialEntity>>

    @Query("SELECT * FROM materials WHERE id = :id AND deleted_at IS NULL")
    suspend fun getById(id: String): MaterialEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(material: MaterialEntity)

    @Query("UPDATE materials SET stock = stock + :amount, updated_at = :now, sync_status = 'PENDING' WHERE id = :id")
    suspend fun addStock(id: String, amount: Double, now: Long): Int

    @Query("UPDATE materials SET deleted_at = :now, updated_at = :now, sync_status = 'PENDING' WHERE id = :id")
    suspend fun softDelete(id: String, now: Long): Int

    @Query("SELECT COUNT(*) FROM materials WHERE deleted_at IS NULL")
    suspend fun countActive(): Int

    @Query("SELECT COUNT(*) FROM materials WHERE deleted_at IS NULL AND stock < min_stock")
    suspend fun countBelowMinimum(): Int

    @Query("SELECT COUNT(*) FROM materials WHERE deleted_at IS NULL AND stock < min_stock")
    fun observeBelowMinimum(): Flow<Int>

    @Query("SELECT COALESCE(SUM(ROUND(stock * buy_price)), 0) FROM materials WHERE deleted_at IS NULL")
    suspend fun sumStockValue(): Long

    @Query("SELECT COUNT(*) FROM materials WHERE deleted_at IS NULL AND (supplier_id IS NULL OR supplier_id = '')")
    suspend fun countWithoutSupplier(): Int

    /** Nama material dengan sisa stok relatif paling tipis (untuk narasi analisis). */
    @Query("SELECT name FROM materials WHERE deleted_at IS NULL AND min_stock > 0 ORDER BY (stock - min_stock) LIMIT :limit")
    suspend fun thinnestStockNames(limit: Int): List<String>
}

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers WHERE deleted_at IS NULL ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<SupplierEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(supplier: SupplierEntity)

    @Query("UPDATE suppliers SET deleted_at = :now, updated_at = :now, sync_status = 'PENDING' WHERE id = :id")
    suspend fun softDelete(id: String, now: Long): Int

    @Query("SELECT COUNT(*) FROM suppliers WHERE deleted_at IS NULL")
    suspend fun countActive(): Int
}

@Dao
interface WorkerDao {
    @Query("SELECT * FROM workers WHERE deleted_at IS NULL ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<WorkerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(worker: WorkerEntity)

    @Query("UPDATE workers SET deleted_at = :now, updated_at = :now, sync_status = 'PENDING' WHERE id = :id")
    suspend fun softDelete(id: String, now: Long): Int

    @Query("SELECT COUNT(*) FROM workers WHERE deleted_at IS NULL")
    suspend fun countActive(): Int
}

@Dao
interface MaterialMovementDao {
    @Insert
    suspend fun insert(movement: MaterialMovementEntity)

    @Query("SELECT * FROM material_movements ORDER BY created_at DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<MaterialMovementEntity>>

    @Query("SELECT COUNT(*) FROM material_movements WHERE created_at >= :since")
    suspend fun countSince(since: Long): Int
}
