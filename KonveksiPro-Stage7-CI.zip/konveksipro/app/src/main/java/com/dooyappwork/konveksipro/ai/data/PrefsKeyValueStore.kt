package com.dooyappwork.konveksipro.ai.data

import android.content.SharedPreferences

/** Implementasi Android untuk pencatatan pemakaian AI (file prefs terpisah). */
class PrefsKeyValueStore(private val prefs: SharedPreferences) : KeyValueStore {
    override fun getString(key: String): String? = prefs.getString(key, null)
    override fun putString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }
    override fun remove(key: String) {
        prefs.edit().remove(key).apply()
    }
}
