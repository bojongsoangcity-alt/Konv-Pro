# LAPORAN TAHAP 7 — KonveksiPro 0.6.1-stage7

Tanggal: 2026-11-05. Basis: kode Tahap 3–6 (0.6.0-stage6, Room v4) — dikembangkan **incremental**;
tidak ada berkas fitur lama yang dibuat ulang.

---

## 0. Checkpoint audit (sebelum perubahan)

| Item | Kondisi terverifikasi |
|---|---|
| Database | Room v4 (12 tabel), migrasi 1→2→3→4 semuanya aditif |
| Sisa pekerjaan terdokumentasi (STAGE3_6_REPORT) | Supplier nonaktif, mutasi stok tanpa buku besar, HPP hanya material, label diagnostik masih 0.2.0 |
| Harness verifikasi | `verify/VerifyMain.kt` + kotlinc di ruang kerja |

---

## 1. Database (Room v4 → v5, `MIGRATION_4_5` — tanpa DROP)

| Perubahan | Isi |
|---|---|
| Tabel baru `material_movements` | Buku besar mutasi stok: material, qty_delta (+masuk/−keluar), alasan (MANUAL/PRODUCTION/KOREKSI), catatan, batch_id, order_id, waktu, device_id; indeks material_id & created_at |
| `ALTER TABLE products ADD COLUMN labor_cost INTEGER NOT NULL DEFAULT 0` | Upah per unit |
| `ALTER TABLE products ADD COLUMN overhead_cost INTEGER NOT NULL DEFAULT 0` | Overhead per unit |

Baris produk lama otomatis bernilai 0 (HPP material-only) — data tidak pernah diubah isinya.

## 2. Fitur baru

1. **Buku besar stok**: setiap mutasi (masuk/keluar) kini menulis baris `material_movements`
   dalam transaksi yang sama dengan perubahan stok; layar Material menambah tombol **Buku Stok**
   (50 mutasi terakhir: nama material, delta bertanda, alasan).
2. **HPP lengkap**: produk kini punya upah & overhead per unit (opsional, default 0);
   `CostCalculator.totalUnitCost(material, labor, overhead)` dan margin terhadap HPP total.
   Form produk menyatakan eksplisit: "HPP per unit = material (dari resep bahan) + upah + overhead".
3. **Modul Supplier aktif**: layar CRUD penuh (`SuppliersScreen`) + rute `suppliers` +
   menu Master Data diaktifkan (sebelumnya kartu nonaktif "Tahap berikutnya").
4. **Analisis COSTING diperbarui**: melaporkan upah+overhead apa adanya — terisi → ditampilkan;
   nol → dinyatakan jujur "belum diisi, HPP baru mencakup material" (tetap tanpa angka karangan).
5. **Label versi**: `versionCode 4`, `versionName 0.6.1-stage7`; halaman diagnostik & Pengaturan ikut.

## 3. Berkas

**Baru (3)**: `MaterialMovementEntity.kt`, `SuppliersRepository.kt` (di dalam CatalogRepository.kt
sebagai class terpisah), `STAGE7_REPORT.md`. **Dimodifikasi (12)**: `CatalogEntities.kt`
(+2 kolom), `CatalogDao.kt` (+`MaterialMovementDao`, +`sumActiveLaborOverhead`),
`KonveksiDatabase.kt` (v5 + MIGRATION_4_5), `CatalogRepository.kt` (ledger + upah/overhead),
`CostCalculator.kt`, `BusinessSnapshot.kt` (+field Tahap 7), `BusinessSnapshotRepository.kt`,
`LocalInsightEngine.kt` (COSTING), `AppContainer.kt` (+migrasi, +suppliersRepository),
`Destinations.kt` & `NavGraph.kt` (+rute supplier), `MasterDataScreen.kt` (menu aktif),
`CatalogViewModel.kt` & `CatalogScreens.kt` (supplier, buku stok, form produk),
`AiDiagnosticsViewModel.kt`, `SettingsScreen.kt`, `app/build.gradle.kts`, `verify/VerifyMain.kt`.

**Tidak disentuh**: seluruh modul pesanan, produksi, pelanggan, AI inti Tahap 2, tema, manifest.

## 4. Verifikasi & rollback

- Harness `verify/VerifyMain.kt` diperluas: HPP total (material+upah+overhead), margin total,
  COSTING terisi vs belum diisi. Jalankan: `kotlinc domain ai/model ai/local verify/VerifyMain.kt -d out && kotlin -cp out verify.VerifyMainKt`.
- Rollback: zip Tahap 3–6 tetap ada; migrasi v5 hanya CREATE TABLE + ADD COLUMN, data lama utuh.
- Risiko tersisa: lapisan Compose/Room belum dikompilasi compiler Android (sandbox tanpa SDK) —
  verifikasi final tetap `./gradlew :app:test :app:assembleDebug` di mesin developer.

## 5. Tambahan: perbaikan build nyata (assembleDebug)

Ditemukan saat kompilasi Android PERTAMA yang sesungguhnya (Tahap 7), semuanya sudah diperbaiki:
1. AGP 9.5 menolak plugin `org.jetbrains.kotlin.android` (Kotlin built-in) -> dihapus dari app & root build.gradle.kts; plugin `kotlin.compose` dipertahankan (wajib sejak Kotlin 2.0).
2. Ikon dipindah ke set material-icons-core yang dijamin ada (Person, Star, Build, List, Home, CheckCircle, Refresh, Place, Lock, Add, Edit, Delete, Inbox); PersonAdd -> Add.
3. Bug laten diperbaiki: `observeLateCount(now)` (bind variable Room), duplikat import MaterialMovementEntity, import AiInsightEntity salah paket, `containerFactory` meneruskan `container` (bukan Application), nama field `profile?.business_name` (snake_case), `CatalogViewModel.action` tanpa parameter sukses, AutoAwesome -> Star.
4. `gradle wrapper` dibuat agar `./gradlew` jalan di CI/mesin developer; workflow CI: `.github/workflows/build-apk.yml`.
