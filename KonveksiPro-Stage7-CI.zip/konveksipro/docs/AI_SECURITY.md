# KonveksiPro — Risiko Keamanan API Key (Developer-Managed AI)

Dokumen ini untuk **developer DooY AppWork**, bukan pengguna akhir.

## 1. Fakta dasar yang harus diterima

API key yang ditanamkan pada APK **dapat diekstrak**. `BuildConfig.AI_CONFIG` adalah
konstanta `String` di `classes.dex`. Siapa pun yang memegang APK dapat:

- menjalankan `strings` / `jadx` / `apktool` pada APK,
- membaca array `DEX` hasil dekompilasi,
- menyadap trafik HTTPS perangkat yang sudah di-root (MITM).

R8/ProGuard **tidak** mengenkripsi string; `-keep` pada paket `ai.**` (lihat
`proguard-rules.pro`) justru mempermudah pembacaan nama kelas. Ini keputusan sadar:
diagnostik lapangan lebih penting daripada keuntungan obfuscation yang kecil.
**Jangan pernah mengklaim API key "aman sepenuhnya".**

## 2. Mitigasi yang SUDAH diterapkan di kode

| Risiko | Mitigasi | Lokasi |
|---|---|---|
| Key tampil di log/anr | `SecretRedactor` menyensor `AIza…`, `sk-…`, `Bearer …`, `api_key=` sebelum log/error | `ai/security/SecretRedactor.kt` |
| Key di `toString()` objek | `AIProviderConfig.describe()/toString()` hanya menampilkan jumlah karakter | `ai/config/AIProviderConfig.kt` |
| Key di URL (proxy log) | Gemini memakai header `x-goog-api-key`, bukan query string | `ai/provider/GeminiAdapter.kt` |
| Key ikut backup | Key tidak ada di data aplikasi; prefs `ai_usage` dikecualikan | `res/xml/backup_rules.xml` |
| Key dari UI pengguna | Tidak ada layar/field input key; konfigurasi hanya dari build | `feature/settings` |
| Pengguna mengubah provider | `DeveloperAIConfig` dibaca sekali dari `BuildConfig`, tanpa setter | `core/utils/AppContainer.kt` |
| Key bocor lewat pesan error provider | `safeDetail` selalu melewati `SecretRedactor`, dipotong 200 char | `ai/provider/BaseHttpProvider.kt` |
| Key terkirim ke provider lain | Key hanya dipakai adapter milik provider itu sendiri | `ai/provider/*` |

## 3. Sisa risiko (belum dan tidak dapat ditutup di sisi klien)

1. **Ekstraksi statis dari APK** — tanpa server perantara, key ada di perangkat. Tidak ada solusi klien murni.
2. **Penyalahgunaan kuota** — jika key bocor, pihak lain memakai kuota Anda. Batas keras harus diatur di dashboard provider (Google AI Studio / OpenRouter), bukan hanya di aplikasi.
3. **Root / MITM** — aplikasi tidak memakai certificate pinning pada tahap ini (menambah biaya pemeliharaan). Header key tetap terlihat pada perangkat yang di-root.
4. **Kuota gratis berubah** — harga/model/policy provider dapat berubah sewaktu-waktu; `ai.limits.*` hanya rem internal, bukan jaminan biaya.
5. **Kebijakan distributor** — key yang diekstrak dan disalahgunakan dapat menyebabkan pemblokiran akun developer.

## 4. Rekomendasi operasional (wajib untuk rilis publik)

- Gunakan **kunci khusus aplikasi** (bukan kunci akun utama), agar bisa dicabut tanpa mengganggu layanan lain.
- Set **kuota harian keras** di sisi provider (mis. 50 request/hari) — ini pertahanan yang sebenarnya.
- Isi `ai.limits.maxCostUsdPerDay=0` selama hanya memakai tier gratis.
- Rotasi key setiap rilis besar; simpan hanya di `local.properties`/CI secret.
- Jika kebocoran terbukti: cabut key di provider, terbitkan build baru. Jangan menambal dengan obfuscation.
- Untuk perlindungan sungguhan di masa depan: pindahkan pemanggilan AI ke **proxy milik DooY AppWork** (berbiaya operasional — melanggar target Rp0, sehingga ditunda dan harus disetujui pemilik produk).

## 5. Yang TIDAK boleh dilakukan

- Menulis key di `strings.xml`, aset, HTML/WebView, atau komentar kode.
- Menampilkan key (walau sebagian) di UI/diagnostik. Diagnostik hanya menampilkan `•••••• (n karakter)`.
- Menambahkan fitur BYOK atau menu "Atur API Key" untuk pengguna.
- Mengklaim enkripsi/obfuscation sebagai perlindungan penuh.
