# Cara Mendapatkan APK lewat GitHub Actions (±10 menit, tanpa install apa pun)

## Langkah

1. **Siapkan akun & repositori**
   - Masuk ke github.com (daftar gratis di github.com/join bila belum punya).
   - Klik ikon **+** (kanan atas) → **New repository**.
   - Repository name: `konveksipro` • pilih **Public** (Actions gratis tanpa batas;
     di dalam kode TIDAK ada kunci rahasia — konfigurasi AI diisi terpisah) atau Private (juga bisa).
   - Klik **Create repository**.

2. **Unggah isi proyek**
   - Ekstrak `KonveksiPro-Stage7.zip` di komputer Anda.
   - Di halaman repositori yang baru dibuat, klik tautan **"uploading an existing file"**.
   - **Buka folder `konveksipro` hasil ekstraksi, lalu SERET SEMUA ISINYA** (app, docs, gradle,
     verify, .github, build file, dll) — bukan foldernya.
   - GitHub web maksimal **100 berkas per unggahan**: jika diminta, unggah setengah dulu →
     **Commit changes** → lalu seret sisanya lagi.
   - Jika folder `.github` tidak ikut terseret (folder tersembunyi), biarkan — dibuat di langkah 3.

3. **Tambahkan workflow (kalau .github tidak ikut terunggah)**
   - Di repositori: **Add file → Create new file**.
   - Ketik nama: `.github/workflows/build-apk.yml` (GitHub otomatis membuat foldernya).
   - Tempel isi berkas `.github/workflows/build-apk.yml` dari hasil ekstraksi → **Commit changes**.

4. **Jalankan & ambil APK**
   - Buka tab **Actions** → pilih **Build APK** → tunggu ±10 menit (titik hijau = berhasil).
   - Klik run tersebut → di bagian **Artifacts** unduh **KonveksiPro-debug-apk**.
   - Ekstrak → dapatkan `app-debug.apk` → salin ke HP → ketuk → izinkan
     "Instal dari sumber tidak dikenal".

## Kalau gagal

- Workflow tidak berjalan sama sekali → pastikan berkas ada di
  `.github/workflows/build-apk.yml` pada branch `main`; atau jalankan manual:
  Actions → Build APK → **Run workflow**.
- Error "gradlew not found" → berkas proyek tersarang satu level terlalu dalam; pindahkan
  isinya ke root repositori (workflow ini sebenarnya sudah mendeteksi folder `konveksipro/`).
- Build gagal dengan log error → salin log dari tab Actions dan minta bantuan analisis
  (tempel ke chat AI ini).
