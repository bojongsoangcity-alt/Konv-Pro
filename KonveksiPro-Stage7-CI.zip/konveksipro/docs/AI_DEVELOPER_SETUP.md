# Cara Developer Memasukkan API Key Sebelum Build

## 1. Siapkan file (sekali per mesin)

```bash
cd konveksipro
cp local.properties.example local.properties
```
`local.properties` sudah ada di `.gitignore`. **Jangan commit.**

## 2. Isi nilai sebenarnya

```properties
ai.externalEnabled=true
ai.primary=gemini_main
ai.fallback=openrouter_fallback

ai.provider.gemini_main.type=GEMINI
ai.provider.gemini_main.baseUrl=https://generativelanguage.googleapis.com/v1beta
ai.provider.gemini_main.model=gemini-2.0-flash
ai.provider.gemini_main.key=AIza...KUNCI_ANDA
ai.provider.gemini_main.enabled=true
```

## 3. Build

```bash
./gradlew :app:assembleDebug
# release
./gradlew :app:assembleRelease
```

Gradle membaca `local.properties` → menyusun JSON → `buildConfigField("String","AI_CONFIG", ...)`.
Hasil akhirnya: `BuildConfig.AI_CONFIG` berisi seluruh konfigurasi.

## 4. CI/CD (GitHub Actions contoh)

```yaml
- name: Build release
  run: ./gradlew :app:assembleRelease \
    -Pai.externalEnabled=true \
    -Pai.primary=gemini_main \
    -Pai.provider.gemini_main.type=GEMINI \
    -Pai.provider.gemini_main.baseUrl=https://generativelanguage.googleapis.com/v1beta \
    -Pai.provider.gemini_main.model=gemini-2.0-flash \
    -Pai.provider.gemini_main.key=${{ secrets.KONVEKSI_AI_KEY }}
```
Simpan kunci di **Repository Secrets**, jangan di YAML.

## 5. Menambah provider / model

Satu provider = satu kelompok kunci `ai.provider.<id>.*`.

```properties
ai.provider.gemini_lite.type=GEMINI
ai.provider.gemini_lite.model=gemini-2.0-flash-lite
ai.provider.gemini_lite.key=...
ai.provider.gemini_lite.enabled=true
```

Urutan percobaan: `ai.primary` → `ai.fallback` (dipisah koma) → analisis lokal.

## 6. Diagnostik

Build dengan `dev.diagnostics=true` untuk menampilkan tombol **Diagnostik AI** di Pengaturan.
Halaman itu hanya menampilkan status, rantai provider, alasan provider tidak dipakai, dan
pemakaian harian — **tanpa API key**, tanpa kemampuan mengubah konfigurasi.
Pada build produksi (flag `false`) rute diagnostik **tidak didaftarkan sama sekali**.
