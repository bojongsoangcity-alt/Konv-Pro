# Stage 2 — Implementasi Sistem AI KonveksiPro (Developer-Managed)

Basis: `KonveksiPro-Stage1.zip` (Stage 1: Room v1, 3 tabel, Compose, navigasi
`dashboard/master/customers`). **Tidak ada modul AI pada Stage 1** — audit grep
`gemini|openai|apikey` = 0 hasil. Stage 2 menambahkan sistem AI, bukan mengganti apa pun.

## Perubahan database (migrasi, bukan reset)
- v1 → v2: `MIGRATION_1_2` menambah tabel `ai_insights` + 2 index.
- Tabel lama (`business_profile`, `customers`, `audit_logs`) tidak disentuh.
- Tanpa `fallbackToDestructiveMigration()`.

## Daftar berkas

### Baru — inti AI (`ai/`)
InsightKind, FailureKind, ProviderResult, AIRequest, InsightReport,
AIProviderConfig, DeveloperAIConfig, AiConfigLoader,
SecretRedactor, SensitiveDataFilter, Json, HttpJsonTransport,
AIProvider, BaseHttpProvider, GeminiAdapter, OpenAICompatibleAdapter,
CustomProviderAdapter, ProviderRegistry, ProviderSelector, ProviderHealthChecker,
BusinessSnapshot, LocalInsightEngine, InsightPromptBuilder,
KeyValueStore, InMemoryKeyValueStore, PrefsKeyValueStore, AIUsageTracker, AIQuotaManager,
AIResponseParser, AIRequestManager, AiInsightEntity, AiInsightDao,
AiInsightRepository, BusinessSnapshotRepository.

### Baru — UI
feature/ai/AiAssistantScreen.kt, feature/ai/AiAssistantViewModel.kt,
feature/settings/SettingsScreen.kt, feature/settings/SettingsViewModel.kt,
feature/dev/AiDiagnosticsScreen.kt, feature/dev/AiDiagnosticsViewModel.kt,
res/xml/backup_rules.xml, res/xml/data_extraction_rules.xml,
local.properties.example, docs/*.

### Dimodifikasi
app/build.gradle.kts (AI_CONFIG, DEV_DIAGNOSTICS, R8, packaging),
app/src/main/AndroidManifest.xml (INTERNET, backup rules),
app/proguard-rules.pro, gradle.properties (catatan), .gitignore,
KonveksiDatabase.kt (v2 + migrasi), AppContainer.kt (perakitan AI),
SettingsRepository.kt (consent, aditif), CustomerDao.kt + AuditLogDao.kt (query agregat, aditif),
Destinations.kt + NavGraph.kt (rute AI/settings/diagnostik),
DashboardScreen.kt (tombol Asisten AI + Pengaturan),
app/src/test/.../AiCoreUnitTest.kt (12 test).

## Yang belum dikerjakan (jujur)
- Modul pesanan/produksi/persediaan/HPP belum ada → analisis terkait ditandai
  "data belum tersedia", bukan hasil fabrikasi.
- Tidak ada pemanggilan API nyata dalam pengujian ini: sandbox tidak punya kredensial
  milik DooY AppWork. Yang diuji: kontrak request/response, klasifikasi error,
  fallback, kuota, penyaringan rahasia.
