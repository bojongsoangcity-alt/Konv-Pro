# LAPORAN TAHAP 3–6 — KonveksiPro 0.6.0-stage6

Tanggal: 2026-11-04. Basis: `KonveksiPro-Stage2.zip` (95 berkas) — dibuka, diaudit, lalu
dikembangkan **secara incremental** sesuai Master Instruction (tidak ada pembuatan ulang).

---

## 0. Checkpoint audit (sebelum perubahan)

| Item | Kondisi terverifikasi |
|---|---|
| Arsitektur | Compose + manual DI (`AppContainer`), Room v2 (3 tabel v1 + `ai_insights`), `MIGRATION_1_2` |
| Navigasi | `dashboard → master → customers → customer_form / ai_assistant / settings(/diagnostics)` |
| AI | `AIRequestManager` + `LocalInsightEngine` (hanya Analisis Usaha yang `dataReady`) |
| Pesanan/produksi/stok/HPP | **Belum ada** — tabel & modulnya memang belum dibuat pada Tahap 1–2 |
| Konstanta versi | `versionCode 2`, `versionName 0.2.0-stage2` |

Potensi konflik yang ditemukan dan cara penanganannya:
- `combine()` maksimal 5 flow → dashboard memakai combine bertingkat (agregat operasional digabung dulu).
- Label kartu Master Data lama menunjuk "Stage 2" → diperbarui; semua menu kini aktif kecuali Supplier.
- Uji Tahap 2 yang mengasumsikan `ORDER.dataReady == false` → diperbarui (Tahap 3 membuat datanya nyata).

Checkpoint/rollback: tahap lama tetap utuh di zip sebelumnya (Stage 1, Stage 2). Migrasi v3 dan v4
hanya `CREATE TABLE/INDEX` — tanpa `DROP`, tanpa `fallbackToDestructiveMigration`, jadi data v1/v2
tidak pernah tersentuh. Rollback = pakai zip sebelumnya; data tetap kompatibel karena tabel baru
tidak mengubah tabel lama.

---

## 1. TAHAP 3 — Modul Pesanan + Produksi

### Database (Room v2 → v3, `MIGRATION_2_3`)
| Tabel | Isi | Catatan |
|---|---|---|
| `orders` | pesanan: kode `ORD-00001`, pelanggan (id + snapshot nama), status, tanggal & tenggat, total, DP, pembayaran, status bayar, notes, soft delete, device_id, sync_status | indeks: order_code, customer_id, status, due_date |
| `order_items` | baris produk: nama (snapshot teks), qty, harga satuan | tanpa FK ke katalog agar histori tak rusak |
| `production_batches` | batch kerja: ANTRE → PROSES → SELESAI, pekerja, tenggat, mulai/selesai | indeks: order_id, status |

### Berkas baru
- `domain/model/OrderStatus.kt` — konstanta status pesanan/bayar/produksi + label Indonesia.
- `domain/model/Order.kt` — model domain Order, OrderItem, ProductionBatch.
- `domain/logic/OrderCalculator.kt` — validasi baris/DP, total, sisa tagihan, aturan transisi status (murni Kotlin, teruji).
- `data/local/entities/OrderEntity.kt`, `OrderItemEntity.kt`, `ProductionBatchEntity.kt`.
- `data/local/dao/OrderDao.kt` — `OrderDao` + `ProductionDao` (query agregat dashboard & analisis ditambah, query lama tak disentuh).
- `data/repository/OrderRepository.kt`, `ProductionRepository.kt`.
- `feature/orders/OrdersViewModel.kt`, `OrdersScreen.kt` (list + chip status), `OrderFormScreen.kt`
  (multi-baris dinamis, pilih pelanggan/Walk-in, DP, tenggat), `OrderDetailScreen.kt`
  (rincian, catat pembayaran dengan validasi sisa tagihan, batalkan, hapus, selesaikan produksi).
- `feature/production/ProductionScreen.kt` + `ProductionViewModel` (mulai/selesai batch,
  tugaskan pekerja, batch internal, dialog penugasan).

### Aturan bisnis yang ditegakkan (di repository, bukan hanya UI)
1. Membuat pesanan = satu transaksi: order + item + **batch produksi otomatis per baris produk** + audit log.
2. Transisi status tervalidasi: BARU→DIPRODUKSI/DIBATALKAN, DIPRODUKSI→SELESAI/DIBATALKAN; sisanya ditolak.
3. Pembayaran tak boleh melebihi sisa tagihan; status LUNAS otomatis saat lunas.
4. DP > total, qty ≤ 0, harga negatif, pesanan tanpa baris → ditolak dengan pesan Indonesia yang jelas.
5. Produksi pesanan hanya bisa diselesaikan dari status DIPRODUKSI; batch ANTRE tidak bisa langsung SELESAI.
6. Semua tulisan data lewat `withTransaction` + `audit_logs` (CREATE/UPDATE/PAYMENT/SOFT_DELETE).

---

## 2. TAHAP 4 — Katalog + Persediaan Material + HPP Material

### Database (Room v3 → v4, `MIGRATION_3_4`)
| Tabel | Isi |
|---|---|
| `products` | katalog: nama, kategori, harga jual, aktif |
| `recipe_items` | BOM: kebutuhan material per 1 unit jadi (Double, boleh pecahan) |
| `materials` | stok: satuan, stok, stok minimum, harga beli, supplier |
| `suppliers` | data supplier |
| `workers` | pekerja + posisi |

### Berkas baru
- `domain/logic/CostCalculator.kt` — HPP material per unit = Σ(qty_per_unit × harga beli), margin & margin % (murni Kotlin, teruji).
- `data/local/entities/CatalogEntities.kt`, `data/local/dao/CatalogDao.kt` (ProductDao/RecipeDao/MaterialDao/SupplierDao/WorkerDao).
- `data/repository/CatalogRepository.kt` + `WorkersRepository`.
- `feature/catalog/CatalogViewModel.kt`, `CatalogScreens.kt`:
  `ProductsScreen`, `MaterialsScreen` (mutasi stok masuk/keluar yang menolak stok minus,
  tanda "Di bawah stok minimum"), `WorkersScreen`, `BusinessProfileScreen` (pre-fill dari data tersimpan).

### Kejujuran HPP
HPP pada tahap ini = **biaya material saja** (BOM × harga beli). Upah dan overhead belum termasuk;
batasan ini tertulis eksplisit pada catatan Analisis HPP — tidak ada angka yang menyaru lengkap.

---

## 3. TAHAP 5 — Integrasi analisis lokal + verifikasi

### Integrasi (semua fitur AI Tahap 2 kini memakai data nyata)
- `BusinessSnapshot` diperluas (field opsional bernilai default → pemanggil & uji lama tetap kompilasi).
- `BusinessSnapshotRepository` mengambil agregat baru: pesanan aktif/telat/baru/30 hari/belum lunas/piutang,
  batch antre/proses/selesai/tanpa pekerja, material di bawah minimum/nilai stok/tanpa supplier,
  produk aktif/tanpa resep, pekerja, supplier. Tetap **agregat saja** — tidak ada PII ke AI eksternal.
- `LocalInsightEngine`: 7 analisis penuh (Usaha, Pesanan, Produksi, Persediaan, HPP, Material, Pekerja)
  berbasis aturan + skor 0–100 + temuan + rekomendasi. Data kosong = angka nol sungguhan, bukan hasil karangan.
- `InsightKind.dataReady` → `true` untuk semua (tabelnya kini ada).
- Dashboard: kartu Pesanan/Produksi/Piutang/Barang Jadi/Stok Min. kini hidup dari Flow Room
  (sebelumnya "0" statis dengan komentar jujur). Navigasi + Master Data menu baru terhubung semua.

### Hasil verifikasi di sandbox (bukan klaim)
| Pengujian | Hasil |
|---|---|
| Kompilasi nyata `kotlinc` (domain + ai/model + ai/local + berkas verifikasi) | **exit 0** |
| Eksekusi nyata 31 assertion runtime (`VerifyMain.kt`): kalkulasi pesanan, HPP, transisi status, 7 analisis pada data kaya & data kosong, deteksi telat/tanpa pekerja/piutang | **31/31 LULUS** |
| Uji unit Tahap 2 (12 JUnit) dipertahankan; asersi `dataReady` diperbarui sesuai modul baru | ikut proyek |
| Kompilasi lapisan Android/Compose (screens, ViewModel, Room codegen) | ⚠️ **belum** — sandbox tanpa Android SDK/AGP |

---

## 4. TAHAP 6 — Finalisasi rilis

- `versionCode 3`, `versionName 0.6.0-stage6`.
- Biaya tetap **Rp0**: semua data lokal (Room), tanpa server, tanpa API wajib; AI eksternal tetap
  developer-managed (BuildConfig.AI_CONFIG), default `maxCostUsdPerDay=0`, consent pengguna tetap dipakai.
- Keamanan tidak berubah: tidak ada kunci di source; snapshot AI tetap tanpa PII; audit log untuk
  semua modul baru.

### Langkah rilis di mesin developer (wajib, tidak bisa digantikan sandbox)
```bash
unzip KonveksiPro-Stage6.zip && cd konveksipro
./gradlew :app:test          # 12 unit test AI + formatter
./gradlew :app:assembleDebug # APK uji: app/build/outputs/apk/debug/
cp local.properties.example local.properties   # isi API key AI bila dipakai
./gradlew :app:assembleRelease                 # minify + shrink aktif
# Signing:
keytool -genkey -v -keystore konveksipro.jks -alias konveksipro -keyalg RSA -keysize 2048 -validity 10000
# tambahkan signingConfigs pada app/build.gradle.kts (storeFile, storePassword, keyAlias, keyPassword)
./gradlew :app:assembleRelease
```

### Risiko yang tersisa (jujur)
1. Lapisan UI/Room belum pernah dikompilasi compiler Android — kemungkinan kecil kesalahan ketik
   hanya akan terlihat saat `assembleDebug` pertama di Android Studio.
2. `nextOrderCode` menghitung dari jumlah baris (termasuk terhapus) — aman untuk single-device;
   sinkronisasi multi-perangkat (Bag. 14) tetap pekerjaan masa depan.
3. HPP belum memasukkan upah/overhead; batch internal belum mengurangi stok material otomatis
   (mutasi stok masih manual — disengaja agar tak ada pengurangan stok yang tak diminta pengguna).
4. Risiko API key Tahap 2 (ekstraksi statis, R8 bukan enkripsi, tanpa cert pinning) tetap berlaku.

---

## 5. Struktur berkas yang berubah

**Baru (24 berkas)**: 2 domain model + 2 domain logic, 3 entitas pesanan + 1 berkas entitas katalog
(5 tabel), 2 berkas DAO baru, 4 repository, 6 berkas UI (orders ×3, production ×1, catalog ×2),
`VerifyMain.kt`, laporan ini.

**Dimodifikasi (11 berkas)**: `KonveksiDatabase.kt` (v4 + MIGRATION_2_3/3_4), `AppContainer.kt`
(+4 repository, +2 migrasi), `Destinations.kt` (+8 rute), `NavGraph.kt` (+8 tujuan),
`DashboardScreen.kt` & `DashboardViewModel.kt` (kartu hidup), `MasterDataScreen.kt` (menu aktif),
`InsightKind.kt`, `BusinessSnapshot.kt`, `LocalInsightEngine.kt` (7 analisis),
`BusinessSnapshotRepository.kt`, `app/build.gradle.kts` (versi), `SettingsScreen.kt` (label versi),
`AiCoreUnitTest.kt` (uji dataReady diperbarui).

**Tidak disentuh**: seluruh berkas AI Tahap 2 lainnya, pelanggan, audit log, tema, manifest, proguard.
