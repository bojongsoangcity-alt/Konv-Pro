# Skema Database KonveksiPro

## v1 (Stage 1)
- `business_profile` — id, business_name, owner_name, phone, address, is_configured, created_at, updated_at, deleted_at, device_id, sync_status
- `customers` — id, name, phone, email, address, notes, created_at, updated_at, deleted_at, device_id, sync_status (index: name)
- `audit_logs` — id, actor, action, entity_type, entity_id, detail, device_id, created_at (index: created_at, entity_type)

## v2 (Stage 2) — hanya menambah
- `ai_insights` — id TEXT PK, kind TEXT, source TEXT (LOCAL/EXTERNAL), provider_id TEXT NULL,
  headline TEXT, narrative TEXT NULL, metrics_json TEXT, tokens INTEGER, created_at INTEGER,
  device_id TEXT (index: created_at, kind)

Catatan: tabel ini **tidak** menyimpan prompt mentah, API key, atau data pelanggan.
