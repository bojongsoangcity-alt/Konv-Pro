package verify

import com.dooyappwork.konveksipro.ai.local.BusinessSnapshot
import com.dooyappwork.konveksipro.ai.local.LocalInsightEngine
import com.dooyappwork.konveksipro.ai.model.InsightKind
import com.dooyappwork.konveksipro.domain.logic.CostCalculator
import com.dooyappwork.konveksipro.domain.logic.OrderCalculator
import com.dooyappwork.konveksipro.domain.model.OrderStatus

/**
 * Verifikasi runtime TANPA perangkat Android (Tahap 5).
 * Dijalankan sungguhan di sandbox: kotlinc (kompilasi) + java (eksekusi).
 * Angka yang diperiksa berasal dari kalkulasi/engine, bukan hasil karangan.
 */

var passed = 0

fun check(name: String, cond: Boolean) {
    if (!cond) throw IllegalStateException("GAGAL: $name")
    passed++
    println("  OK  $name")
}

fun throws(name: String, block: () -> Unit) {
    val threw = try { block(); false } catch (e: Exception) { true }
    check(name, threw)
}

fun rupiah(v: Long) = "Rp$v"

fun main() {
    println("== Verifikasi Tahap 3-6: kalkulasi & analisis lokal ==")

    // --- Kalkulator pesanan ---
    val lines = listOf(
        OrderCalculator.LineInput("Kaos polo", 10, 35000),
        OrderCalculator.LineInput("Topi", 5, 15000)
    )
    check("total 10x35000 + 5x15000 = 425000", OrderCalculator.total(lines) == 425000L)
    check("receivable(425000, 100000, 50000) = 275000",
        OrderCalculator.receivable(425000, 100000, 50000) == 275000L)
    check("receivable tidak pernah negatif", OrderCalculator.receivable(100, 200, 300) == 0L)
    throws("baris qty=0 ditolak") {
        OrderCalculator.validate(listOf(OrderCalculator.LineInput("x", 0, 1000)), 0)
    }
    throws("DP melebihi total ditolak") {
        OrderCalculator.validate(listOf(OrderCalculator.LineInput("x", 1, 1000)), 2000)
    }
    throws("daftar baris kosong ditolak") { OrderCalculator.validate(emptyList(), 0) }
    check("transisi BARU->DIPRODUKSI sah",
        OrderCalculator.canTransition(OrderStatus.BARU, OrderStatus.DIPRODUKSI))
    check("transisi BARU->SELESAI ditolak",
        !OrderCalculator.canTransition(OrderStatus.BARU, OrderStatus.SELESAI))
    check("transisi SELESAI->apa pun ditolak",
        !OrderCalculator.canTransition(OrderStatus.SELESAI, OrderStatus.BARU))

    // --- Kalkulator HPP ---
    val bom = listOf(CostCalculator.BomRow(2.5, 40000), CostCalculator.BomRow(1.0, 15000))
    check("HPP material 2.5x40000 + 1x15000 = 115000", CostCalculator.materialCost(bom) == 115000L)
    check("HPP total 115000 + upah 20000 + overhead 5000 = 140000",
        CostCalculator.totalUnitCost(115000, 20000, 5000) == 140000L)
    check("margin total 150000-140000 = 10000", CostCalculator.margin(150000, 140000) == 10000L)
    val pct = CostCalculator.marginPercent(150000, 140000)
    check("margin % ~6.67", pct != null && Math.abs(pct - 6.67) < 0.1)
    check("margin % tak terdefinisi saat harga 0 (null, bukan nol)",
        CostCalculator.marginPercent(0, 100) == null)

    // --- Engine analisis lokal: senario data kaya ---
    val rich = BusinessSnapshot(
        businessName = "Konveksi Berkah",
        isProfileConfigured = true,
        customersTotal = 12,
        customersWithoutContact = 2,
        customersAddedLast30Days = 3,
        activityCountLast30Days = 40,
        ordersActive = 4,
        ordersLate = 1,
        ordersNew = 2,
        ordersCreatedLast30Days = 5,
        ordersUnpaid = 2,
        lastOrderAt = 1L,
        receivable = 350000,
        productionAntre = 3,
        productionProses = 2,
        productionFinishedLast30Days = 6,
        productionWithoutWorker = 1,
        materialsTotal = 8,
        materialsBelowMinimum = 2,
        materialStockValue = 2500000,
        materialsWithoutSupplier = 1,
        productsActive = 5,
        productsWithoutRecipe = 1,
        workersTotal = 3,
        suppliersTotal = 2,
        productsLaborOverheadValue = 120000
    )
    val engine = LocalInsightEngine()
    InsightKind.entries.forEach { kind ->
        val r = engine.analyze(kind, rich, ::rupiah)
        check("${kind.name}: dataReady & metrik & temuan terisi", r.dataReady && r.metrics.isNotEmpty() && r.findings.isNotEmpty())
        val s = r.score
        check("${kind.name}: skor dalam rentang 0-100", s != null && s in 0..100)
    }
    val orderReport = engine.analyze(InsightKind.ORDER, rich, ::rupiah)
    check("ORDER: pesanan telat terdeteksi", orderReport.findings.any { it.contains("melewati tenggat") })
    check("ORDER: piutang dipakai apa adanya", orderReport.metrics.any { it.value == "Rp350000" })
    val prodReport = engine.analyze(InsightKind.PRODUCTION, rich, ::rupiah)
    check("PRODUCTION: batch tanpa pekerja terdeteksi",
        prodReport.findings.any { it.contains("belum diberi pekerja") })
    val invReport = engine.analyze(InsightKind.INVENTORY, rich, ::rupiah)
    check("INVENTORY: nilai stok 2500000 tampil",
        invReport.metrics.any { it.value == "Rp2500000" })
    check("BUSINESS: skor kaya-data < 100 karena ada temuan",
        (engine.analyze(InsightKind.BUSINESS, rich, ::rupiah).score ?: 0) < 100)
    val costRich = engine.analyze(InsightKind.COSTING, rich, ::rupiah)
    check("COSTING (Tahap 7): upah+overhead dilaporkan apa adanya",
        costRich.findings.any { it.contains("Upah + overhead per unit sudah diisi") })
    val richNoLabor = rich.copy(productsLaborOverheadValue = 0)
    check("COSTING: upah/overhead 0 = jujur belum diisi",
        engine.analyze(InsightKind.COSTING, richNoLabor, ::rupiah)
            .findings.any { it.contains("belum diisi") })

    // --- Engine analisis lokal: senario data kosong (tidak boleh mengarang) ---
    val empty = BusinessSnapshot.EMPTY
    InsightKind.entries.forEach { kind ->
        val r = engine.analyze(kind, empty, ::rupiah)
        check("${kind.name} (kosong): tetap dataReady, metrik nol sungguhan",
            r.dataReady && r.metrics.isNotEmpty())
    }
    val emptyOrder = engine.analyze(InsightKind.ORDER, empty, ::rupiah)
    check("ORDER (kosong): menyatakan tidak ada pesanan berjalan",
        emptyOrder.findings.any { it.contains("Tidak ada pesanan berjalan") })
    val emptyCost = engine.analyze(InsightKind.COSTING, empty, ::rupiah)
    check("COSTING (kosong): jujur belum bisa hitung HPP",
        emptyCost.findings.any { it.contains("Belum ada produk") })

    println()
    println("HASIL: $passed assertion LULUS (0 gagal)")
}
